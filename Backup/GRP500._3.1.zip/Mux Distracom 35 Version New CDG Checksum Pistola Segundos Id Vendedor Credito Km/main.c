/*
*********************************************************************************************************
*                                           GRP550/700 CODE
*
*                             (c) Copyright 2013; Sistemas Insepet LTDA
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                               GRP550/700 CODE
*
*                                             CYPRESS PSoC5LP
*                                                with the
*                                            CY8C5969AXI-LP035
*
* Filename      : main.c
* Version       : V1.00
* Programmer(s) : 
                  
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/

#include <device.h>
#include <math.h>
#include "Protocolo.h"
#include "VariablesG.h"
#include "Print.h"
#include "LCD.h"
#include "ibutton.h"
#include "I2C.h"
#include "EstructuraProtocolo.h"

/*
*********************************************************************************************************
*                                             DECLARACION DE FUNCIONES
*********************************************************************************************************
*/
uint8 letras[26]={0x25,0x42,0x31,0x27,0x1D,0x28,0x29,0x2A,0x22,0x2B,0x2C,0x2D,0x35,0x34,0x23,0x24,0x1B,0x1E,0x26,0x1F,0x21,0x32,0x1C,0x30,0x20,0x2F};
uint16 LargoTrama=0;
uint8 msn_Vendedor[20]="Vendedor Sin Sistema";
uint8 versionmux[10]="Ver.  2.05";
uint8 CerrarTurno[4];
uint8 Checkibutton1;
uint8 Checkibutton2;
uint8 Checkventa1;
uint8 Checkventa2;
uint8 respuestaTX1;
uint8 respuestaTX2;
uint8 impresion1;
uint8 impresion2;
CY_ISR(animacion2);
CY_ISR(animacion);
CY_ISR(Rf);

/*
************************************************************************************************************
*                                         void polling_recibe_RF()
*
* Description : Procesa datos del CDG
*               
*
* Argument(s) : uint32 Rx_CDG	
*
* Return(s)   : none
*
* Caller(s)   : En cualquier momento que reciba un dato del CDG
*
* Note(s)     : none.
************************************************************************************************************
*/

void polling_recibe_RF(void){
	unsigned int Estado1, Estado2;
	uint8 Checksum,index;
    uint32 i;
    uint8 table[256] = { 
    0, 94,188,226, 97, 63,221,131,194,156,126, 32,163,253, 31, 65,
    157,195, 33,127,252,162, 64, 30, 95,  1,227,189, 62, 96,130,220,
    35,125,159,193, 66, 28,254,160,225,191, 93,  3,128,222, 60, 98,
    190,224,  2, 92,223,129, 99, 61,124, 34,192,158, 29, 67,161,255,
    70, 24,250,164, 39,121,155,197,132,218, 56,102,229,187, 89,  7,
    219,133,103, 57,186,228,  6, 88, 25, 71,165,251,120, 38,196,154,
    101, 59,217,135,  4, 90,184,230,167,249, 27, 69,198,152,122, 36,
    248,166, 68, 26,153,199, 37,123, 58,100,134,216, 91,  5,231,185,
    140,210, 48,110,237,179, 81, 15, 78, 16,242,172, 47,113,147,205,
    17, 79,173,243,112, 46,204,146,211,141,111, 49,178,236, 14, 80,
    175,241, 19, 77,206,144,114, 44,109, 51,209,143, 12, 82,176,238,
    50,108,142,208, 83, 13,239,177,240,174, 76, 18,145,207, 45,115,
    202,148,118, 40,171,245, 23, 73,  8, 86,180,234,105, 55,213,139,
    87,  9,235,181, 54,104,138,212,149,203, 41,119,244,170, 72, 22,
    233,183, 85, 11,136,214, 52,106, 43,117,151,201, 74, 20,246,168,
    116, 42,200,150, 21, 75,169,247,182,232, 10, 84,215,137,107, 53}; 
	if(PC_GetRxBufferSize() >= 1){
		Estado1=PC_GetRxBufferSize();
		CyDelayUs(2000);
		Estado2=PC_GetRxBufferSize();
		if(Estado1==Estado2){
			LargoTrama=0;
			while(PC_GetRxBufferSize()>0){
        		Rx_CDG[LargoTrama]=PC_ReadRxData();
        		LargoTrama++;
        	}
        	PC_ClearRxBuffer();
			Checksum=0;
			for(i=0;i<(LargoTrama-1);i++){
                index = (uint8)(Checksum ^ Rx_CDG[i]);
                Checksum = table[index];
			}
			if(Checksum==Rx_CDG[LargoTrama-1]){
				if((Rx_CDG[0]=='C') && (Rx_CDG[1]=='D') && (Rx_CDG[2]=='G')){
					for(i=1;i<=10;i++){
						if(DirMuxDef[i]==Rx_CDG[i+2]){
							if(i==10){
                                count_rf=0;//Reinicia el contador para saber que el rf esta recibiendo
	                            if(Rx_CDG[13]==lado.a.dir){//Byte posicion surtidor
	                                flujo_pos_surt=1;
	                                flujo_Pro_CDG=Rx_CDG[14];//Byte Estado surtidor
	                            }else if(Rx_CDG[13]==lado.b.dir){
	                                flujo_pos_surt=2;
	                                flujo_Pro_CDG=Rx_CDG[14];//Byte Estado surtidor
	                            }
							}
						}else{
							i=11;
						}
					}
				}	
			}
			PC_ClearRxBuffer();
			Estado1=0;
			Estado2=0;
		}
	}
}

/*
************************************************************************************************************
*                                         void polling_procesa_CDG()
*
* Description : Procesa datos del CDG
*               
*
* Argument(s) : 	
*
* Return(s)   : none
*
* Caller(s)   : En cualquier momento que reciba un dato del CDG
*
* Note(s)     : none.
************************************************************************************************************
*/

void polling_procesa_CDG(void){
	uint8 ventapen[2];
    uint32 i,x,w;
    switch(flujo_pos_surt){
        case 0:
        
        break;
        
        case 1://lado.a.dir
            switch(flujo_Pro_CDG){
    		    case 0x00:
    			    
        		break;
        		
        		case 0xC0://El CDG va a enviar una configuracion Inicial al MUX
                	programarEquipo();
					flujo_envia_CDG=3;//Para enviar que se recibio coreectamente la trama
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
                    if(Buffer_LCD1.Estado_Mux==0xA5){
                        Buffer_LCD1.Estado_Mux=0xA1;
                    }
        		break;
        		
        		case 0xC1://El CDG pregunta en que estado esta el Mux, si en espera, sube manija, fin venta, turnos,ect 
        			flujo_envia_CDG=1;
					flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
        		break;
        		
        		case 0xC2://El CDG Autoriza a que envie datos el Mux
					if(Buffer_LCD1.Estado_Mux==0xA6){//Ventas en contado
						envioventa(producto1,lado.a.dir);
                    	flujo_envia_CDG=2;//enviar datos
					}else if(Buffer_LCD1.Estado_Mux==0xB1 || Buffer_LCD1.Estado_Mux==0xF7 || Buffer_LCD1.Estado_Mux==0xFD || Buffer_LCD1.Estado_Mux==0xA8){//Id Contado Control o Credito o Credito canastilla o Reconocimiento de producto o Venta finalizada en canastilla
						envioid(lado.a.dir,Buffer_LCD1.Estado_Mux);
						flujo_envia_CDG=2;//enviar datos
					}else if(Buffer_LCD1.Estado_Mux==0xE1 || Buffer_LCD1.Estado_Mux==0xE2){//id Apertura o cierre de Turno
                        Buffer_LCD1.recepcionrf=1;//Bandera que indica que ya se tomaron los datos de turno
						envioturno(lado.a.dir);
						flujo_envia_CDG=2;//enviar datos
					}
        		break;
				
                case 0xC4://El CDG requiere cerrar el turno obligatoriamente en el Mux
                    Tx_CDG[1]='M';
					Tx_CDG[2]='U';
					Tx_CDG[3]='X';
        			for(i=1;i<=10;i++){
        				Tx_CDG[i+3]=DirMuxDef[i];
        			}
					Tx_CDG[14]=lado.a.dir;//Posicion del surtidor
					Tx_CDG[15]=0xC3;//Estado de trama correcta
					checksum(15);
					for(x=1;x<=15;x++){
        				PC_PutChar(Tx_CDG[x]);
        			}
					PC_PutChar(ResultadoCheck);//Checksum
        			PC_PutChar(0xFE);//Final de trama 2
        			PC_PutChar(0xFF);//Final de trama 1
                    isr_3_Stop();
	                Timer_Animacion_Stop();
                    set_imagen(1,8);	//esperando 1
					DatosTurno();
					flujo_LCD=33;		//Caso 33
					for(x=0;x<=FechaInicialTurno[0];x++){
						FechaFinalTurno[x]=FechaInicialTurno[x];
					}
					isr_3_StartEx(animacion);
		         	Timer_Animacion_Start();
		         	count_protector=0;
					Buffer_LCD1.Estado_Mux=0xE2;//Autorizacion para cierre de Turno
					Buffer_LCD1.BanImpFin=0x02;//Para evitar conflictos mas adelante
					Buffer_LCD1.AutorizacionCierreTurno=0x02;//Para evitar conflictos mas adelante
                    set_imagen(2,8);
                    flujo_LCD2=100; 
			        count_protector2=0;
		         	Timer_Animacion2_Start();
                    isr_4_StartEx(animacion2);
					PC_ClearRxBuffer();
                    LCD_1_ClearRxBuffer();
                    LCD_2_ClearRxBuffer();
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
                break;
                    
				case 0xC5://El CDG Autoriza la Transaccion al Mux
					if(Buffer_LCD1.Estado_Mux==0xB1 || Buffer_LCD1.Estado_Mux==0xE6 || Buffer_LCD1.Estado_Mux==0xF1){//Id Contado Control o Credito o Traslados o Calibracion
						if(Buffer_LCD1.Estado_Mux==0xB1){
							Buffer_LCD1.AutorizacionControl=0x01;
						}else if(Buffer_LCD1.Estado_Mux==0xE6 || Buffer_LCD1.Estado_Mux==0xF1){
							Buffer_LCD1.AutorizacionTrasCali=0x01;
						}
						if(Rx_CDG[15]=='D'){
							Buffer_LCD1.PresetAutControl='D';
						}else if(Rx_CDG[15]=='V'){
							Buffer_LCD1.PresetAutControl='V';	
						}
						if(Rx_CDG[16]=='F'){
							Buffer_LCD1.FullAutControl='F';
						}else{
							Buffer_LCD1.FullAutControl=0x00;
						}
						for(x=0;x<50;x++){//Mensaje a publicar en LCD
							Buffer_LCD1.MensajePublicar[x]=Rx_CDG[17+x];
						}
						w=Rx_CDG[67]&0x0F;//Version de Digitos
						Buffer_LCD1.ValorTanqueoControl[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD1.ValorTanqueoControl[x]=Rx_CDG[x+67];//Maximo valor a Tanquear
						}
						Buffer_LCD1.NumManguera[1]=Rx_CDG[w+68]&0x0F;//Manguera 1
						Buffer_LCD1.PPUClienteID1[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD1.PPUClienteID1[x]=Rx_CDG[x+w+68]&0x0F;//PPU Manguera 1 Cliente ID
						}
						Buffer_LCD1.PPUClienteContado1[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD1.PPUClienteContado1[x]=Rx_CDG[x+(w*2)+68]&0x0F;//PPU Manguera 1 Cliente Contado
						}
						Buffer_LCD1.NumManguera[2]=Rx_CDG[(w*3)+69]&0x0F;//Manguera 2
						Buffer_LCD1.PPUClienteID2[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD1.PPUClienteID2[x]=Rx_CDG[x+(w*3)+69]&0x0F;//PPU Manguera 2 Cliente ID
						}
						Buffer_LCD1.PPUClienteContado2[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD1.PPUClienteContado2[x]=Rx_CDG[x+(w*4)+69]&0x0F;//PPU Manguera 2 Cliente Contado
						}
						Buffer_LCD1.NumManguera[3]=Rx_CDG[(w*5)+70]&0x0F ;//Manguera 3
						Buffer_LCD1.PPUClienteID3[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD1.PPUClienteID3[x]=Rx_CDG[x+(w*5)+70]&0x0F;//PPU Manguera 3 Cliente ID
						}
						Buffer_LCD1.PPUClienteContado3[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD1.PPUClienteContado3[x]=Rx_CDG[x+(w*6)+70]&0x0F;//PPU Manguera 3 Cliente Contado
						}
						Buffer_LCD1.NombreCliente[0]=40;//Nombre Cliente
						for(x=1;x<=Buffer_LCD1.NombreCliente[0];x++){
							Buffer_LCD1.NombreCliente[x]=Rx_CDG[x+(w*7)+70];
						}
						Buffer_LCD1.NitCliente[0]=10;//Nit Cliente
						for(x=1;x<=Buffer_LCD1.NitCliente[0];x++){
							Buffer_LCD1.NitCliente[x]=Rx_CDG[x+((w*7)+40)+70];
						}
						Buffer_LCD1.DireccionCliente[0]=40;//Direccion Cliente
						for(x=1;x<=Buffer_LCD1.DireccionCliente[0];x++){
							Buffer_LCD1.DireccionCliente[x]=Rx_CDG[x+((w*7)+50)+70];
						}
						Buffer_LCD1.TelCliente[0]=12;//Telefono Cliente
						for(x=1;x<=Buffer_LCD1.TelCliente[0];x++){
							Buffer_LCD1.TelCliente[x]=Rx_CDG[x+((w*7)+90)+70];
						}
						Buffer_LCD1.PlacaCliente[0]=10;//Placa Cliente
						for(x=1;x<=Buffer_LCD1.PlacaCliente[0];x++){
							Buffer_LCD1.PlacaCliente[x]=Rx_CDG[x+((w*7)+102)+70];
						}
						Buffer_LCD1.FechaCliente[0]=8;//Fecha Cliente
						for(x=1;x<=Buffer_LCD1.FechaCliente[0];x++){
							Buffer_LCD1.FechaCliente[x]=Rx_CDG[x+((w*7)+112)+70];
						}
                        Buffer_LCD1.Estado_Mux=0xA7;
					}else if(Buffer_LCD1.Estado_Mux==0xE1){//Apertura de Turno
						NombreVendedor[0]=20;
						for(x=0;x<=NombreVendedor[0];x++){
							NombreVendedor[x+1]=Rx_CDG[15+x];
						}
						CedulaVendedor[0]=10;
						for(x=0;x<=CedulaVendedor[0];x++){
							CedulaVendedor[x+1]=Rx_CDG[35+x];
						}
                        Buffer_LCD1.Estado_Mux=0xA1;
			        	Buffer_LCD1.AutorizacionApertTurno=0x01;
					}else if(Buffer_LCD1.Estado_Mux==0xE2){//Cierre de turno
                        Buffer_LCD1.Estado_Mux=0xA1;
						Buffer_LCD1.AutorizacionCierreTurno=0x01;
					}else if(Buffer_LCD1.Estado_Mux==0xF7){//Id Credito Canastilla
						Buffer_LCD1.AutorizacionCreditoCanasta=0x01;
						for(x=0;x<50;x++){//Mensaje a publicar en LCD
							Buffer_LCD1.MensajePublicar[x]=Rx_CDG[15+x];
						}
						for(x=0;x<=(Rx_CDG[65]&0x0f);x++){                   
							Buffer_LCD1.ValorCupoCanasta[x]=Rx_CDG[x+65];
						}
						Buffer_LCD1.ValorCupoCanastaOri=0;
						for(x=(Buffer_LCD1.ValorCupoCanasta[0]&0x0f);x>=1;x--){
							Buffer_LCD1.ValorCupoCanastaOri+=((uint32)(Buffer_LCD1.ValorCupoCanasta[x]&0x0f)*pow(10,(Buffer_LCD1.ValorCupoCanasta[0]-x)));
						}
                        Buffer_LCD1.Estado_Mux=0xAB;
					}
					flujo_envia_CDG=3;//Para enviar que se recibio correctamente la trama
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
				break;
	
				case 0xC6://El CDG No Autoriza la Transaccion del Mux
					if(Buffer_LCD1.Estado_Mux==0xB1 || Buffer_LCD1.Estado_Mux==0xE6 || Buffer_LCD1.Estado_Mux==0xF1){//Id Contado Control o credito o Traslados o Calibracion
						if(Buffer_LCD1.Estado_Mux==0xB1){
							Buffer_LCD1.AutorizacionControl=0x00;
						}else if(Buffer_LCD1.Estado_Mux==0xE6 || Buffer_LCD1.Estado_Mux==0xF1){
							Buffer_LCD1.AutorizacionTrasCali=0x00;
						}
						for(i=0;i<50;i++){
							Buffer_LCD1.MensajePublicar[i]=Rx_CDG[i+15];
						}
                        Buffer_LCD1.Estado_Mux=0xA1;
					}else if(Buffer_LCD1.Estado_Mux==0xE1){//Apertura de Turno
			        	Buffer_LCD1.AutorizacionApertTurno=0x00;
						for(i=0;i<50;i++){
							Buffer_LCD1.MensajePublicar[i]=Rx_CDG[i+15];
						}
                        Buffer_LCD1.Estado_Mux=0xA1;
					}else if(Buffer_LCD1.Estado_Mux==0xE2){//Cierre de turno
						Buffer_LCD1.AutorizacionCierreTurno=0x00;
						for(i=0;i<50;i++){
							Buffer_LCD1.MensajePublicar[i]=Rx_CDG[i+15];
						}
                        Buffer_LCD1.Estado_Mux=0xA1;
					}else if(Buffer_LCD1.Estado_Mux==0xF7){//Id Credito Canastilla
						Buffer_LCD1.AutorizacionCreditoCanasta=0x00;
						for(i=0;i<50;i++){
							Buffer_LCD1.MensajePublicar[i]=Rx_CDG[i+15];
						}
                        Buffer_LCD1.Estado_Mux=0xA1;
					}
					flujo_envia_CDG=3;//Para enviar que se recibio correctamente la trama
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
				break;
				
				case 0xC7://El CDG Resetea el estado del Mux a A1 Espera
                    respuestaTX1=0;
					if(Buffer_LCD1.Estado_Mux==0xA6){//Fin de venta combustible
                        if(Buffer_LCD1.VentasPendientesE>0){
                            Buffer_LCD1.VentasPendientesE--;
                            ventapen[0]=1;
						    ventapen[1]=Buffer_LCD1.VentasPendientesE;
						    write_eeprom(214,ventapen);
                        }else{
                            if(Buffer_LCD1.VentasPendientesR>0){
                                Buffer_LCD1.VentasPendientesR--;
                            }
                        }
					}else if(Buffer_LCD1.Estado_Mux==0xA8){//Fin de venta canastilla
						Buffer_LCD1.AutorizacionVentaCanasta=0x01;
					}else if(Buffer_LCD1.Estado_Mux==0xA9){
                        Buffer_LCD1.impresionultimaventa=0x01;
                        impresion1=0;
                        respuestaTX1=0xD0;
                        flujo_envia_CDG=4;//Para enviar que se reseteo correctamente la venta
    					flujo_Pro_CDG = 0x00;
                        Buffer_LCD1.Estado_Mux=0xA1;
                        break;
                    }else if(Buffer_LCD1.Estado_Mux==0xAA){
                        Buffer_LCD1.impresionultimaventa=0x01;
                        impresion1=0;
                        respuestaTX1=0xD0;
                        flujo_envia_CDG=4;//Para enviar que se reseteo correctamente la venta
    					flujo_Pro_CDG = 0x00;
                        Buffer_LCD1.Estado_Mux=0xA1;
                        break;
                    }
					Buffer_LCD1.Estado_Mux=0xA1;
					if(Buffer_LCD1.VentasPendientesE>0 || Buffer_LCD1.VentasPendientesR>0){//Se verifica si hay ventas pendientes por entregar
						Checkventa1=1;
					}
                    respuestaTX1=0xD0;
                    flujo_envia_CDG=4;//Para enviar que se reseteo correctamente la venta
					flujo_Pro_CDG = 0x00;
				break;
					
				case 0xC8://El CDG Envia Formato de impresion al Mux
                    respuestaTX1=0;
					for(x=1;x<=1500;x++){
						if(Rx_CDG[15]==0xA2){
							print_logo(print1[1]);
                            respuestaTX1=0xD1;
							flujo_envia_CDG=4;//Para enviar que se recibio correctamente la trama de encabezado de impresion
                            break;
						}else if(Rx_CDG[x+15]==0xA0){
							Buffer_LCD1.BanImpFin=0x01;//Bandera para sacar del estado espera al mux
							respuestaTX1=0xD2;
                            flujo_envia_CDG=4;//Para enviar que se recibio correctamente la trama de impresion de cuerpo
                            break;
						}else if(Rx_CDG[x+15]==0xA1){
							write_psoc1(print1[1],0x1D);
							write_psoc1(print1[1],0x56);
							write_psoc1(print1[1],0x31);
							respuestaTX1=0xD3;
                            flujo_envia_CDG=4;//Para enviar que se recibio correctamente la trama de fin de recibo
                            break;
						}
                        write_psoc1(print1[1],Rx_CDG[x+14]);
					}
					flujo_Pro_CDG = 0x00;
				break;
				
				case 0xC9://El CDG Envia PPU Autorizados al Mux
					w=Rx_CDG[15]&0x0F;//Version de Digitos
					Buffer_LCD1.NumManguera[1]=Rx_CDG[16]&0x0F;//Manguera 1
					Buffer_LCD1.PPUClienteContado1[0]=w;
					for(x=1;x<=w;x++){
						Buffer_LCD1.PPUClienteContado1[x]=Rx_CDG[x+16]&0x0F;//PPU Manguera 1 Cliente Contado
					}
					Buffer_LCD1.NumManguera[2]=Rx_CDG[w+17]&0x0F;//Manguera 2
					Buffer_LCD1.PPUClienteContado2[0]=w;
					for(x=1;x<=w;x++){
						Buffer_LCD1.PPUClienteContado2[x]=Rx_CDG[x+w+17]&0x0F;//PPU Manguera 2 Cliente Contado
					}
					Buffer_LCD1.NumManguera[3]=Rx_CDG[(w*2)+18]&0x0F ;//Manguera 3
					Buffer_LCD1.PPUClienteContado3[0]=w;
					for(x=1;x<=w;x++){
						Buffer_LCD1.PPUClienteContado3[x]=Rx_CDG[x+(w*2)+18]&0x0F;//PPU Manguera 3 Cliente Contado
					}
					programarPPUContado(1);
					flujo_envia_CDG=3;//Para enviar que se recibio correctamente la trama
					flujo_Pro_CDG = 0x00;
				break;
					
				case 0xCA://El CDG Envia informacion de la lectura de codigo de barras
					Buffer_LCD1.ReconocimientoProducto=0x01;
					if(Buffer_LCD1.ProductoCanasta==1){
						Buffer_LCD1.NombreProducto1Canasta[0]=20;
						for(x=1;x<=20;x++){
							Buffer_LCD1.NombreProducto1Canasta[x]=Rx_CDG[14+x];
						}
						Buffer_LCD1.ValorProducto1Canasta[0]=7;
						for(x=1;x<=7;x++){
							Buffer_LCD1.ValorProducto1Canasta[x]=Rx_CDG[34+x];
						}
						Buffer_LCD1.CantProducto1Canasta[0]=1;
						Buffer_LCD1.CantProducto1Canasta[1]=1;
						Buffer_LCD1.ValorProducto1Orig=0;
						for(x=Buffer_LCD1.ValorProducto1Canasta[0];x>=1;x--){
							Buffer_LCD1.ValorProducto1Orig+=((uint32)(Buffer_LCD1.ValorProducto1Canasta[x]&0x0f)*pow(10,(Buffer_LCD1.ValorProducto1Canasta[0]-x)));
						}
						if(Buffer_LCD1.ValorProducto1Orig==0){
							Buffer_LCD1.CodigoProductoCanasta1[0]=0;
							Buffer_LCD1.CantProducto1Canasta[0]=0;
						}
					}else if(Buffer_LCD1.ProductoCanasta==2){
						Buffer_LCD1.NombreProducto2Canasta[0]=20;
						for(x=1;x<=20;x++){
							Buffer_LCD1.NombreProducto2Canasta[x]=Rx_CDG[14+x];
						}
						Buffer_LCD1.ValorProducto2Canasta[0]=7;
						for(x=1;x<=7;x++){
							Buffer_LCD1.ValorProducto2Canasta[x]=Rx_CDG[34+x];
						}
						Buffer_LCD1.CantProducto2Canasta[0]=1;
						Buffer_LCD1.CantProducto2Canasta[1]=1;
						Buffer_LCD1.ValorProducto2Orig=0;
						for(x=Buffer_LCD1.ValorProducto2Canasta[0];x>=1;x--){
							Buffer_LCD1.ValorProducto2Orig+=((uint32)(Buffer_LCD1.ValorProducto2Canasta[x]&0x0f)*pow(10,(Buffer_LCD1.ValorProducto2Canasta[0]-x)));
						}
						if(Buffer_LCD1.ValorProducto2Orig==0){
							Buffer_LCD1.CodigoProductoCanasta2[0]=0;
							Buffer_LCD1.CantProducto2Canasta[0]=0;
						}
					}if(Buffer_LCD1.ProductoCanasta==3){
						Buffer_LCD1.NombreProducto3Canasta[0]=20;
						for(x=1;x<=20;x++){
							Buffer_LCD1.NombreProducto3Canasta[x]=Rx_CDG[14+x];
						}
						Buffer_LCD1.ValorProducto3Canasta[0]=7;
						for(x=1;x<=7;x++){
							Buffer_LCD1.ValorProducto3Canasta[x]=Rx_CDG[34+x];
						}
						Buffer_LCD1.CantProducto3Canasta[0]=1;
						Buffer_LCD1.CantProducto3Canasta[1]=1;
						Buffer_LCD1.ValorProducto3Orig=0;
						for(x=Buffer_LCD1.ValorProducto3Canasta[0];x>=1;x--){
							Buffer_LCD1.ValorProducto3Orig+=((uint32)(Buffer_LCD1.ValorProducto3Canasta[x]&0x0f)*pow(10,(Buffer_LCD1.ValorProducto3Canasta[0]-x)));
						}
						if(Buffer_LCD1.ValorProducto3Orig==0){
							Buffer_LCD1.CodigoProductoCanasta3[0]=0;
							Buffer_LCD1.CantProducto3Canasta[0]=0;
						}
					}if(Buffer_LCD1.ProductoCanasta==4){
						Buffer_LCD1.NombreProducto4Canasta[0]=20;
						for(x=1;x<=20;x++){
							Buffer_LCD1.NombreProducto4Canasta[x]=Rx_CDG[14+x];
						}
						Buffer_LCD1.ValorProducto4Canasta[0]=7;
						for(x=1;x<=7;x++){
							Buffer_LCD1.ValorProducto4Canasta[x]=Rx_CDG[34+x];
						}
						Buffer_LCD1.CantProducto4Canasta[0]=1;
						Buffer_LCD1.CantProducto4Canasta[1]=1;
						Buffer_LCD1.ValorProducto4Orig=0;
						for(x=Buffer_LCD1.ValorProducto4Canasta[0];x>=1;x--){
							Buffer_LCD1.ValorProducto4Orig+=((uint32)(Buffer_LCD1.ValorProducto4Canasta[x]&0x0f)*pow(10,(Buffer_LCD1.ValorProducto4Canasta[0]-x)));
						}
						if(Buffer_LCD1.ValorProducto4Orig==0){
							Buffer_LCD1.CodigoProductoCanasta4[0]=0;
							Buffer_LCD1.CantProducto4Canasta[0]=0;
						}
					}
					flujo_envia_CDG=3;//Para enviar que se recibio correctamente la trama
					flujo_Pro_CDG = 0x00;
				break;
        	}
        break;
        
        case 2://lado.b.dir
            switch(flujo_Pro_CDG){
    		    case 0x00:
    			    
        		break;
        		
        		case 0xC0://El CDG va a enviar una configuracion Inicial al MUX
                	programarEquipo();
					flujo_envia_CDG=3;//Para enviar que se recibio coreectamente la trama
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
                    if(Buffer_LCD2.Estado_Mux==0xA5){
                        Buffer_LCD2.Estado_Mux=0xA1;
                    }
        		break;
        		
        		case 0xC1://El CDG pregunta en que estado esta el Mux, si en espera, sube manija, fin venta, turnos,ect 
        			flujo_envia_CDG=1;
					flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
        		break;
        		
        		case 0xC2://El CDG Autoriza a que envie datos el Mux
					if(Buffer_LCD2.Estado_Mux==0xA6){//Ventas en contado
						envioventa(producto2,lado.b.dir);
                    	flujo_envia_CDG=2;//enviar datos
					}else if(Buffer_LCD2.Estado_Mux==0xB1 || Buffer_LCD2.Estado_Mux==0xF7 || Buffer_LCD2.Estado_Mux==0xFD || Buffer_LCD2.Estado_Mux==0xA8){//Id Contado Control o Credito o Credito canastilla o Reconocimiento de producto o Venta finalizada en canastilla
						envioid(lado.b.dir,Buffer_LCD2.Estado_Mux);
						flujo_envia_CDG=2;//enviar datos
					}else if(Buffer_LCD2.Estado_Mux==0xE1 || Buffer_LCD2.Estado_Mux==0xE2){//id Apertura o cierre de Turno
                        Buffer_LCD2.recepcionrf=1;//Bandera que indica que ya se tomaron los datos de turno
						envioturno(lado.b.dir);
						flujo_envia_CDG=2;//enviar datos
					}	
        		break;
				
                case 0xC4://El CDG requiere cerrar el turno obligatoriamente en el Mux
                    Tx_CDG[1]='M';
					Tx_CDG[2]='U';
					Tx_CDG[3]='X';
        			for(i=1;i<=10;i++){
        				Tx_CDG[i+3]=DirMuxDef[i];
        			}
					Tx_CDG[14]=lado.b.dir;//Posicion del surtidor
					Tx_CDG[15]=0xC3;//Estado de trama correcta
					checksum(15);
					for(x=1;x<=15;x++){
        				PC_PutChar(Tx_CDG[x]);
        			}
					PC_PutChar(ResultadoCheck);//Checksum
        			PC_PutChar(0xFE);//Final de trama 2
        			PC_PutChar(0xFF);//Final de trama 1
                    isr_4_Stop();
	                Timer_Animacion2_Stop();
                    set_imagen(2,8);	//esperando 1
					DatosTurno();
					flujo_LCD2=33;		//Caso 33
					for(x=0;x<=FechaInicialTurno[0];x++){
						FechaFinalTurno[x]=FechaInicialTurno[x];
					}
					isr_4_StartEx(animacion2);
		         	Timer_Animacion2_Start();
		         	count_protector2=0;
					Buffer_LCD2.Estado_Mux=0xE2;//Autorizacion para cierre de Turno
					Buffer_LCD2.BanImpFin=0x02;//Para evitar conflictos mas adelante
					Buffer_LCD2.AutorizacionCierreTurno=0x02;//Para evitar conflictos mas adelante
                    set_imagen(1,8);
                    flujo_LCD=100; 
			        count_protector=0;
		         	Timer_Animacion_Start();
                    isr_3_StartEx(animacion);
                    LCD_1_ClearRxBuffer();
                    LCD_2_ClearRxBuffer();
					PC_ClearRxBuffer();
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
                break;
                    
				case 0xC5://El CDG Autoriza la Transaccion al Mux
					if(Buffer_LCD2.Estado_Mux==0xB1 || Buffer_LCD2.Estado_Mux==0xE6 || Buffer_LCD2.Estado_Mux==0xF1){//Id Contado Control o Credito o Traslados o Calibracion
						if(Buffer_LCD2.Estado_Mux==0xB1){
							Buffer_LCD2.AutorizacionControl=0x01;
						}else if(Buffer_LCD2.Estado_Mux==0xE6 || Buffer_LCD2.Estado_Mux==0xF1){
							Buffer_LCD2.AutorizacionTrasCali=0x01;
						}
						if(Rx_CDG[15]=='D'){
							Buffer_LCD2.PresetAutControl='D';
						}else if(Rx_CDG[15]=='V'){
							Buffer_LCD2.PresetAutControl='V';	
						}
						if(Rx_CDG[16]=='F'){
							Buffer_LCD2.FullAutControl='F';
						}else{
							Buffer_LCD2.FullAutControl=0x00;
						}
						for(x=0;x<50;x++){//Mensaje a publicar en LCD
							Buffer_LCD2.MensajePublicar[x]=Rx_CDG[17+x];
						}
						w=Rx_CDG[67]&0x0F;//Version de Digitos
						Buffer_LCD2.ValorTanqueoControl[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD2.ValorTanqueoControl[x]=Rx_CDG[x+67];//Maximo valor a Tanquear
						}
						Buffer_LCD2.NumManguera[1]=Rx_CDG[w+68]&0x0F;//Manguera 1
						Buffer_LCD2.PPUClienteID1[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD2.PPUClienteID1[x]=Rx_CDG[x+w+68]&0x0F;//PPU Manguera 1 Cliente ID
						}
						Buffer_LCD2.PPUClienteContado1[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD2.PPUClienteContado1[x]=Rx_CDG[x+(w*2)+68]&0x0F;//PPU Manguera 1 Cliente Contado
						}
						Buffer_LCD2.NumManguera[2]=Rx_CDG[(w*3)+69]&0x0F;//Manguera 2
						Buffer_LCD2.PPUClienteID2[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD2.PPUClienteID2[x]=Rx_CDG[x+(w*3)+69]&0x0F;//PPU Manguera 2 Cliente ID
						}
						Buffer_LCD2.PPUClienteContado2[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD2.PPUClienteContado2[x]=Rx_CDG[x+(w*4)+69]&0x0F;//PPU Manguera 2 Cliente Contado
						}
						Buffer_LCD2.NumManguera[3]=Rx_CDG[(w*5)+70]&0x0F ;//Manguera 3
						Buffer_LCD2.PPUClienteID3[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD2.PPUClienteID3[x]=Rx_CDG[x+(w*5)+70]&0x0F;//PPU Manguera 3 Cliente ID
						}
						Buffer_LCD2.PPUClienteContado3[0]=w;
						for(x=1;x<=w;x++){
							Buffer_LCD2.PPUClienteContado3[x]=Rx_CDG[x+(w*6)+70]&0x0F;//PPU Manguera 3 Cliente Contado
						}
						Buffer_LCD2.NombreCliente[0]=40;//Nombre Cliente
						for(x=1;x<=Buffer_LCD2.NombreCliente[0];x++){
							Buffer_LCD2.NombreCliente[x]=Rx_CDG[x+(w*7)+70];
						}
						Buffer_LCD2.NitCliente[0]=10;//Nit Cliente
						for(x=1;x<=Buffer_LCD2.NitCliente[0];x++){
							Buffer_LCD2.NitCliente[x]=Rx_CDG[x+((w*7)+40)+70];
						}
						Buffer_LCD2.DireccionCliente[0]=40;//Direccion Cliente
						for(x=1;x<=Buffer_LCD2.DireccionCliente[0];x++){
							Buffer_LCD2.DireccionCliente[x]=Rx_CDG[x+((w*7)+50)+70];
						}
						Buffer_LCD2.TelCliente[0]=12;//Telefono Cliente
						for(x=1;x<=Buffer_LCD2.TelCliente[0];x++){
							Buffer_LCD2.TelCliente[x]=Rx_CDG[x+((w*7)+90)+70];
						}
						Buffer_LCD2.PlacaCliente[0]=10;//Placa Cliente
						for(x=1;x<=Buffer_LCD2.PlacaCliente[0];x++){
							Buffer_LCD2.PlacaCliente[x]=Rx_CDG[x+((w*7)+102)+70];
						}
						Buffer_LCD2.FechaCliente[0]=8;//Fecha Cliente
						for(x=1;x<=Buffer_LCD2.FechaCliente[0];x++){
							Buffer_LCD2.FechaCliente[x]=Rx_CDG[x+((w*7)+112)+70];
						}
                        Buffer_LCD2.Estado_Mux=0xA7;
					}else if(Buffer_LCD2.Estado_Mux==0xE1){//Apertura de Turno
						NombreVendedor[0]=20;
						for(x=0;x<=NombreVendedor[0];x++){
							NombreVendedor[x+1]=Rx_CDG[15+x];
						}
						CedulaVendedor[0]=10;
						for(x=0;x<=CedulaVendedor[0];x++){
							CedulaVendedor[x+1]=Rx_CDG[35+x];
						}
                        Buffer_LCD2.Estado_Mux=0xA1;
			        	Buffer_LCD2.AutorizacionApertTurno=0x01;
					}else if(Buffer_LCD2.Estado_Mux==0xE2){//Cierre de turno
                        Buffer_LCD2.Estado_Mux=0xA1;
						Buffer_LCD2.AutorizacionCierreTurno=0x01;
					}else if(Buffer_LCD2.Estado_Mux==0xF7){//Id Credito Canastilla
						Buffer_LCD2.AutorizacionCreditoCanasta=0x01;
						for(x=0;x<50;x++){//Mensaje a publicar en LCD
							Buffer_LCD2.MensajePublicar[x]=Rx_CDG[15+x];
						}
						for(x=0;x<=(Rx_CDG[65]&0x0f);x++){                   
							Buffer_LCD2.ValorCupoCanasta[x]=Rx_CDG[x+65];
						}
						Buffer_LCD2.ValorCupoCanastaOri=0;
						for(x=(Buffer_LCD2.ValorCupoCanasta[0]&0x0f);x>=1;x--){
							Buffer_LCD2.ValorCupoCanastaOri+=((uint32)(Buffer_LCD2.ValorCupoCanasta[x]&0x0f)*pow(10,(Buffer_LCD2.ValorCupoCanasta[0]-x)));
						}
                        Buffer_LCD2.Estado_Mux=0xAB;
					}
					flujo_envia_CDG=3;//Para enviar que se recibio correctamente la trama
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
				break;
	
				case 0xC6://El CDG No Autoriza la Transaccion del Mux
					if(Buffer_LCD2.Estado_Mux==0xB1 || Buffer_LCD2.Estado_Mux==0xE6 || Buffer_LCD2.Estado_Mux==0xF1){//Id Contado Control o credito o Traslados o Calibracion
						if(Buffer_LCD2.Estado_Mux==0xB1){
							Buffer_LCD2.AutorizacionControl=0x00;
						}else if(Buffer_LCD2.Estado_Mux==0xE6 || Buffer_LCD2.Estado_Mux==0xF1){
							Buffer_LCD2.AutorizacionTrasCali=0x00;
						}
						for(i=0;i<50;i++){
							Buffer_LCD2.MensajePublicar[i]=Rx_CDG[i+15];
						}
                        Buffer_LCD2.Estado_Mux=0xA1;
					}else if(Buffer_LCD2.Estado_Mux==0xE1){//Apertura de Turno
			        	Buffer_LCD2.AutorizacionApertTurno=0x00;
						for(i=0;i<50;i++){
							Buffer_LCD2.MensajePublicar[i]=Rx_CDG[i+15];
						}
                        Buffer_LCD2.Estado_Mux=0xA1;
					}else if(Buffer_LCD2.Estado_Mux==0xE2){//Cierre de turno
						Buffer_LCD2.AutorizacionCierreTurno=0x00;
						for(i=0;i<50;i++){
							Buffer_LCD2.MensajePublicar[i]=Rx_CDG[i+15];
						}
                        Buffer_LCD2.Estado_Mux=0xA1;
					}else if(Buffer_LCD2.Estado_Mux==0xF7){//Id Credito Canastilla
						Buffer_LCD2.AutorizacionCreditoCanasta=0x00;
						for(i=0;i<50;i++){
							Buffer_LCD2.MensajePublicar[i]=Rx_CDG[i+15];
						}
                        Buffer_LCD2.Estado_Mux=0xA1;
					}
					flujo_envia_CDG=3;//Para enviar que se recibio correctamente la trama
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
				break;
				
				case 0xC7://El CDG Resetea el estado del Mux a A1 Espera
                    respuestaTX2=0;
					if(Buffer_LCD2.Estado_Mux==0xA6){//Fin de venta combustible
                        if(Buffer_LCD2.VentasPendientesE>0){
                            Buffer_LCD2.VentasPendientesE--;
    						ventapen[0]=1;
    						ventapen[1]=Buffer_LCD2.VentasPendientesE;
    						write_eeprom(216,ventapen);
                        }else{
                            if(Buffer_LCD2.VentasPendientesR>0){
                                Buffer_LCD2.VentasPendientesR--;
                            }
                        }
					}else if(Buffer_LCD2.Estado_Mux==0xA8){//Fin de venta canastilla
						Buffer_LCD2.AutorizacionVentaCanasta=0x01;
					}else if(Buffer_LCD2.Estado_Mux==0xA9){
                        Buffer_LCD2.impresionultimaventa=0x01;
                        impresion2=0;
                        respuestaTX2=0xD0;
                        flujo_envia_CDG=4;//Para enviar que se reseteo correctamente la venta
    					flujo_Pro_CDG = 0x00;
                        Buffer_LCD2.Estado_Mux=0xA1;
                        break;
                    }else if(Buffer_LCD2.Estado_Mux==0xAA){
                        Buffer_LCD2.impresionultimaventa=0x01;
                        impresion2=0;
                        respuestaTX2=0xD0;
                        flujo_envia_CDG=4;//Para enviar que se reseteo correctamente la venta
    					flujo_Pro_CDG = 0x00;
                        Buffer_LCD2.Estado_Mux=0xA1;
                        break;
                    }
					Buffer_LCD2.Estado_Mux=0xA1;
					if(Buffer_LCD2.VentasPendientesE>0 || Buffer_LCD2.VentasPendientesR>0){//Se verifica si hay ventas pendientes por entregar
						Checkventa2=1;
					}
                    respuestaTX2=0xD0;
                    flujo_envia_CDG=4;//Para enviar que se reseteo correctamente la venta
					flujo_Pro_CDG = 0x00;
				break;
					
				case 0xC8://El CDG Envia Formato de impresion al Mux 
                    respuestaTX2=0;
					for(x=1;x<=1500;x++){
						if(Rx_CDG[15]==0xA2){
							print_logo(print2[1]);
                            respuestaTX2=0xD1;
							flujo_envia_CDG=4;//Para enviar que se recibio correctamente la trama de fin de recibo
                            break;
						}else if(Rx_CDG[x+15]==0xA0){
							Buffer_LCD2.BanImpFin=0x01;//Bandera para sacar del estado espera al mux
							respuestaTX2=0xD2;
                            flujo_envia_CDG=4;//Para enviar que se recibio correctamente la trama de fin de recibo
                            break;
                        }else if(Rx_CDG[x+15]==0xA1){
							write_psoc1(print2[1],0x1D);
							write_psoc1(print2[1],0x56);
							write_psoc1(print2[1],0x31);
							respuestaTX2=0xD3;
                            flujo_envia_CDG=4;//Para enviar que se recibio correctamente la trama de fin de recibo
                            break;
						}
                        write_psoc1(print2[1],Rx_CDG[x+14]);
					}
					flujo_Pro_CDG = 0x00;
				break;
				
				case 0xC9://El CDG Envia PPU Autorizados al Mux
					w=Rx_CDG[15]&0x0F;//Version de Digitos
					Buffer_LCD2.NumManguera[1]=Rx_CDG[16]&0x0F;//Manguera 1
					Buffer_LCD2.PPUClienteContado1[0]=w;
					for(x=1;x<=w;x++){
						Buffer_LCD2.PPUClienteContado1[x]=Rx_CDG[x+16]&0x0F;//PPU Manguera 1 Cliente Contado
					}
					Buffer_LCD2.NumManguera[2]=Rx_CDG[w+17]&0x0F;//Manguera 2
					Buffer_LCD2.PPUClienteContado2[0]=w;
					for(x=1;x<=w;x++){
						Buffer_LCD2.PPUClienteContado2[x]=Rx_CDG[x+w+17]&0x0F;//PPU Manguera 2 Cliente Contado
					}
					Buffer_LCD2.NumManguera[3]=Rx_CDG[(w*2)+18]&0x0F ;//Manguera 3
					Buffer_LCD2.PPUClienteContado3[0]=w;
					for(x=1;x<=w;x++){
						Buffer_LCD2.PPUClienteContado3[x]=Rx_CDG[x+(w*2)+18]&0x0F;//PPU Manguera 3 Cliente Contado
					}
					programarPPUContado(2);
					flujo_envia_CDG=3;//Para enviar que se recibio coreectamente la trama
					flujo_Pro_CDG = 0x00;
				break;
					
				case 0xCA://El CDG Envia informacion de la lectura de codigo de barras
					Buffer_LCD2.ReconocimientoProducto=0x01;
					if(Buffer_LCD2.ProductoCanasta==1){
						Buffer_LCD2.NombreProducto1Canasta[0]=20;
						for(x=1;x<=20;x++){
							Buffer_LCD2.NombreProducto1Canasta[x]=Rx_CDG[14+x];
						}
						Buffer_LCD2.ValorProducto1Canasta[0]=7;
						for(x=1;x<=7;x++){
							Buffer_LCD2.ValorProducto1Canasta[x]=Rx_CDG[34+x];
						}
						Buffer_LCD2.CantProducto1Canasta[0]=1;
						Buffer_LCD2.CantProducto1Canasta[1]=1;
						Buffer_LCD2.ValorProducto1Orig=0;
						for(x=Buffer_LCD2.ValorProducto1Canasta[0];x>=1;x--){
							Buffer_LCD2.ValorProducto1Orig+=((uint32)(Buffer_LCD2.ValorProducto1Canasta[x]&0x0f)*pow(10,(Buffer_LCD2.ValorProducto1Canasta[0]-x)));
						}
						if(Buffer_LCD2.ValorProducto1Orig==0){
							Buffer_LCD2.CodigoProductoCanasta1[0]=0;
							Buffer_LCD2.CantProducto1Canasta[0]=0;
						}
					}else if(Buffer_LCD2.ProductoCanasta==2){
						Buffer_LCD2.NombreProducto2Canasta[0]=20;
						for(x=1;x<=20;x++){
							Buffer_LCD2.NombreProducto2Canasta[x]=Rx_CDG[14+x];
						}
						Buffer_LCD2.ValorProducto2Canasta[0]=7;
						for(x=1;x<=7;x++){
							Buffer_LCD2.ValorProducto2Canasta[x]=Rx_CDG[34+x];
						}
						Buffer_LCD2.CantProducto2Canasta[0]=1;
						Buffer_LCD2.CantProducto2Canasta[1]=1;
						Buffer_LCD2.ValorProducto2Orig=0;
						for(x=Buffer_LCD2.ValorProducto2Canasta[0];x>=1;x--){
							Buffer_LCD2.ValorProducto2Orig+=((uint32)(Buffer_LCD2.ValorProducto2Canasta[x]&0x0f)*pow(10,(Buffer_LCD2.ValorProducto2Canasta[0]-x)));
						}
						if(Buffer_LCD2.ValorProducto2Orig==0){
							Buffer_LCD2.CodigoProductoCanasta2[0]=0;
							Buffer_LCD2.CantProducto2Canasta[0]=0;
						}
					}if(Buffer_LCD2.ProductoCanasta==3){
						Buffer_LCD2.NombreProducto3Canasta[0]=20;
						for(x=1;x<=20;x++){
							Buffer_LCD2.NombreProducto3Canasta[x]=Rx_CDG[14+x];
						}
						Buffer_LCD2.ValorProducto3Canasta[0]=7;
						for(x=1;x<=7;x++){
							Buffer_LCD2.ValorProducto3Canasta[x]=Rx_CDG[34+x];
						}
						Buffer_LCD2.CantProducto3Canasta[0]=1;
						Buffer_LCD2.CantProducto3Canasta[1]=1;
						Buffer_LCD2.ValorProducto3Orig=0;
						for(x=Buffer_LCD2.ValorProducto3Canasta[0];x>=1;x--){
							Buffer_LCD2.ValorProducto3Orig+=((uint32)(Buffer_LCD2.ValorProducto3Canasta[x]&0x0f)*pow(10,(Buffer_LCD2.ValorProducto3Canasta[0]-x)));
						}
						if(Buffer_LCD2.ValorProducto3Orig==0){
							Buffer_LCD2.CodigoProductoCanasta3[0]=0;
							Buffer_LCD2.CantProducto3Canasta[0]=0;
						}
					}if(Buffer_LCD2.ProductoCanasta==4){
						Buffer_LCD2.NombreProducto4Canasta[0]=20;
						for(x=1;x<=20;x++){
							Buffer_LCD2.NombreProducto4Canasta[x]=Rx_CDG[14+x];
						}
						Buffer_LCD2.ValorProducto4Canasta[0]=7;
						for(x=1;x<=7;x++){
							Buffer_LCD2.ValorProducto4Canasta[x]=Rx_CDG[34+x];
						}
						Buffer_LCD2.CantProducto4Canasta[0]=1;
						Buffer_LCD2.CantProducto4Canasta[1]=1;
						Buffer_LCD2.ValorProducto4Orig=0;
						for(x=Buffer_LCD2.ValorProducto4Canasta[0];x>=1;x--){
							Buffer_LCD2.ValorProducto4Orig+=((uint32)(Buffer_LCD2.ValorProducto4Canasta[x]&0x0f)*pow(10,(Buffer_LCD2.ValorProducto4Canasta[0]-x)));
						}
						if(Buffer_LCD2.ValorProducto4Orig==0){
							Buffer_LCD2.CodigoProductoCanasta4[0]=0;
							Buffer_LCD2.CantProducto4Canasta[0]=0;
						}
					}
					flujo_envia_CDG=3;//Para enviar que se recibio correctamente la trama
					flujo_Pro_CDG = 0x00;
				break;
        	}
		break;
    }
}

/*
************************************************************************************************************
*                                         void polling_envia_CDG()
*
* Description : Envia datos al CDG
*               
*
* Argument(s) : 	
*
* Return(s)   : none
*
* Caller(s)   : En cualquier momento que pregunte un dato del CDG
*
* Note(s)     : none.
************************************************************************************************************
*/

void polling_envia_CDG(void){
    uint32 j,x;
    switch(flujo_pos_surt){
        case 0:
        
        break;
        
        case 1://lado.a.dir
            switch(flujo_envia_CDG){
        		case 0:
        		
        		break;
        		
        		case 1://Envia el Estado en el que se encuentra actualmente el Mux
					Tx_CDG[1]='M';
					Tx_CDG[2]='U';
					Tx_CDG[3]='X';
        			for(j=1;j<=10;j++){
        				Tx_CDG[j+3]=DirMuxDef[j];
        			}
					Tx_CDG[14]=lado.a.dir;//Posicion del surtidor
					Tx_CDG[15]=Buffer_LCD1.Estado_Mux;//Estado en el que se encuentra el Mux
					checksum(15);
					for(x=1;x<=15;x++){
        				PC_PutChar(Tx_CDG[x]);
        			}
					PC_PutChar(ResultadoCheck);//Checksum
        			PC_PutChar(0xFE);//Final de trama 2
					PC_PutChar(0xFF);//Final de trama 
        			PC_ClearRxBuffer();
        			flujo_envia_CDG=0;//Para evitar conflictos de que siempre este enviando
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
                    flujo_pos_surt=0;//Para evitar conflictos de que siempre este enviando
        		break;
        			
				case 2://Envia datos requeridos
					checksum(Tx_CDG[15]-1);
					for(x=1;x<Tx_CDG[15];x++){
        				PC_PutChar(Tx_CDG[x]);
        			}
					PC_PutChar(ResultadoCheck);//Checksum
        			PC_PutChar(0xFE);//Final de trama 2
        			PC_PutChar(0xFF);//Final de trama 1
                    PC_ClearRxBuffer();
        			flujo_envia_CDG=0;//Para evitar conflictos de que siempre este enviando
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de estar enviando a cada rato
                    flujo_pos_surt=0;//Para evitar conflictos de que siempre este enviando
				break;
					
				case 3://Envia que recibio la trama correcta
					Tx_CDG[1]='M';
					Tx_CDG[2]='U';
					Tx_CDG[3]='X';
        			for(j=1;j<=10;j++){
        				Tx_CDG[j+3]=DirMuxDef[j];
        			}
					Tx_CDG[14]=lado.a.dir;//Posicion del surtidor
					Tx_CDG[15]=0xC3;//Estado de trama correcta
					checksum(15);
					for(x=1;x<=15;x++){
        				PC_PutChar(Tx_CDG[x]);
        			}
					PC_PutChar(ResultadoCheck);//Checksum
        			PC_PutChar(0xFE);//Final de trama 2
        			PC_PutChar(0xFF);//Final de trama 1
        			PC_ClearRxBuffer();
        			flujo_envia_CDG=0;//Para evitar conflictos de que siempre este enviando
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
                    flujo_pos_surt=0;//Para evitar conflictos de que siempre este enviando
				break;
					
				case 4://Envia que recibio la trama correcta de impresion
					Tx_CDG[1]='M';
					Tx_CDG[2]='U';
					Tx_CDG[3]='X';
        			for(j=1;j<=10;j++){
        				Tx_CDG[j+3]=DirMuxDef[j];
        			}
					Tx_CDG[14]=lado.a.dir;//Posicion del surtidor
					Tx_CDG[15]=respuestaTX1;//Trama impresa correcta
					checksum(15);
					for(x=1;x<=15;x++){
        				PC_PutChar(Tx_CDG[x]);
        			}
					PC_PutChar(ResultadoCheck);//Checksum
        			PC_PutChar(0xFE);//Final de trama 2
        			PC_PutChar(0xFF);//Final de trama 1
        			PC_ClearRxBuffer();
                    respuestaTX1=0;
        			flujo_envia_CDG=0;//Para evitar conflictos de que siempre este enviando
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
                    flujo_pos_surt=0;//Para evitar conflictos de que siempre este enviando
				break;
        	}
        break;
        
        case 2://lado.b.dir
            switch(flujo_envia_CDG){
        		case 0:
        		
        		break;
        		
        		case 1://Envia el Estado en el que se encuentra actualmente el Mux
        			Tx_CDG[1]='M';
					Tx_CDG[2]='U';
					Tx_CDG[3]='X';
        			for(j=1;j<=10;j++){
        				Tx_CDG[j+3]=DirMuxDef[j];
        			}
					Tx_CDG[14]=lado.b.dir;//Posicion del surtidor
					Tx_CDG[15]=Buffer_LCD2.Estado_Mux;//Estado en el que se encuentra el Mux
					checksum(15);
					for(x=1;x<=15;x++){
        				PC_PutChar(Tx_CDG[x]);
        			}
					PC_PutChar(ResultadoCheck);//Checksum
        			PC_PutChar(0xFE);//Final de trama 2
        			PC_PutChar(0xFF);//Final de trama 1
        			PC_ClearRxBuffer();
        			flujo_envia_CDG=0;//Para evitar conflictos de que siempre este enviando
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
                    flujo_pos_surt=0;//Para evitar conflictos de que siempre este enviando
        		break;
        			
				case 2://Envia datos requeridos
					checksum(Tx_CDG[15]-1);
					for(x=1;x<Tx_CDG[15];x++){
        				PC_PutChar(Tx_CDG[x]);
        			}
					PC_PutChar(ResultadoCheck);//Checksum
        			PC_PutChar(0xFE);//Final de trama 2
        			PC_PutChar(0xFF);//Final de trama 1
                    PC_ClearRxBuffer();
        			flujo_envia_CDG=0;//Para evitar conflictos de que siempre este enviando
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de estar enviando a cada rato
                    flujo_pos_surt=0;//Para evitar conflictos de que siempre este enviando
				break;
					
				case 3://Envia que recibio la trama correcta
					Tx_CDG[1]='M';
					Tx_CDG[2]='U';
					Tx_CDG[3]='X';
        			for(j=1;j<=10;j++){
        				Tx_CDG[j+3]=DirMuxDef[j];
        			}
					Tx_CDG[14]=lado.b.dir;//Posicion del surtidor
					Tx_CDG[15]=0xC3;//Estado de trama correcta
					checksum(15);
					for(x=1;x<=15;x++){
        				PC_PutChar(Tx_CDG[x]);
        			}
					PC_PutChar(ResultadoCheck);//Checksum
        			PC_PutChar(0xFE);//Final de trama 2
        			PC_PutChar(0xFF);//Final de trama 1
        			PC_ClearRxBuffer();
        			flujo_envia_CDG=0;//Para evitar conflictos de que siempre este enviando
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
                    flujo_pos_surt=0;//Para evitar conflictos de que siempre este enviando
				break;
					
				case 4://Envia que recibio la trama correcta de impresion
					Tx_CDG[1]='M';
					Tx_CDG[2]='U';
					Tx_CDG[3]='X';
        			for(j=1;j<=10;j++){
        				Tx_CDG[j+3]=DirMuxDef[j];
        			}
					Tx_CDG[14]=lado.b.dir;//Posicion del surtidor
					Tx_CDG[15]=respuestaTX2;//Trama impresa correcta
					checksum(15);
					for(x=1;x<=15;x++){
        				PC_PutChar(Tx_CDG[x]);
        			}
					PC_PutChar(ResultadoCheck);//Checksum
        			PC_PutChar(0xFE);//Final de trama 2
        			PC_PutChar(0xFF);//Final de trama 1
        			PC_ClearRxBuffer();
                    respuestaTX2=0;
        			flujo_envia_CDG=0;//Para evitar conflictos de que siempre este enviando
        			flujo_Pro_CDG=0x00;//Para evitar conflictos de que siempre este enviando
                    flujo_pos_surt=0;//Para evitar conflictos de que siempre este enviando
				break;
        	}
        break;
    }
}

/*
************************************************************************************************************
*                                         void Direccion_Mux
*
* Description : Se digita la direccion del Mux, solo la primera vez que se conecta el Mux
*               
*
* Argument(s) : 
*
* Return(s)   : none
*
* Caller(s)   : Al momento de prender el Mux
*
* Note(s)     : none.
************************************************************************************************************
*/

void Direccion_Mux(void){
    uint32 x,i;
	leer_eeprom(276,11);
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			DirMuxDef[x]=buffer_i2c[x];
		}
		DireccionMux=1;
	}else{
		DireccionMux=0;
		set_imagen(1,37);	//digite numero
	}
	
	while(DireccionMux==0){	
		switch(flujo_DirMux){
			case 0:	
				if(LCD_1_GetRxBufferSize()==8){
			        if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
			            if(teclas1<=9){
			                if(LCD_1_rxBuffer[3]<=9){
			                    teclas1++;
			                    DirMuxPrueba[teclas1]=LCD_1_rxBuffer[3]+0x30;
								write_LCD(1,(LCD_1_rxBuffer[3]+0x30),teclas1,0x05,0x00,0x40,0x00);
			                }
			                if(LCD_1_rxBuffer[3]==0x0A){            	//Comando de 0
			                    teclas1++;
			                    DirMuxPrueba[teclas1]=0x30;
			                    write_LCD(1,0x30,teclas1,0x05,0x00,0x40,0x00);
			                }                   
			            }
			            if(LCD_1_rxBuffer[3]==0x0B){					//DEL
			                if(teclas1==0){								//Si no ha presionado nada regresa al menu anterior
			                    set_imagen(1,37);	//digite numero
			                    flujo_DirMux=0;
			                }
			                else{
			                    write_LCD(1,0x20,(teclas1),0x05,0x00,0x40,0x00);			//Si ya presiono borra el dato	
			                    if(DirMuxPrueba[teclas1]==0x2C){
			                        comas1=0;
			                    }
			                    teclas1--;
			                }
			            }
			            if(LCD_1_rxBuffer[3]==0x0C){					//ENT
			                if(teclas1>=1){	//Animacion --> Menu Principal --> Combustibles --> Contado --> Dinero --> Suba la Manija
								DirMuxPrueba[0]=teclas1;
			                    flujo_DirMux=1; 
								teclas1=0;//Inicializa el contador de teclas
			                    set_imagen(1,37);	//digite numero				
			                }
			            }
			        }
			        CyDelay(100);            
			        LCD_1_ClearRxBuffer();
			    }

			break;
				
			case 1:
				if(LCD_1_GetRxBufferSize()==8){
			        if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
			            if(teclas1<=9){
			                if(LCD_1_rxBuffer[3]<=9){
			                    teclas1++;
			                    DirMuxDef[teclas1]=LCD_1_rxBuffer[3]+0x30;
								write_LCD(1,(LCD_1_rxBuffer[3]+0x30),teclas1,0x05,0x00,0x40,0x00);
			                }
			                if(LCD_1_rxBuffer[3]==0x0A){            	//Comando de 0
			                    teclas1++;
			                    DirMuxDef[teclas1]=0x30;
			                    write_LCD(1,0x30,teclas1,0x05,0x00,0x40,0x00);
			                }                   
			            }
			            if(LCD_1_rxBuffer[3]==0x0B){					//DEL
			                if(teclas1==0){								//Si no ha presionado nada regresa al menu anterior
			                    set_imagen(1,37);	//digite numero
			                    flujo_DirMux=1;
			                }
			                else{
			                    write_LCD(1,0x20,(teclas1),0x05,0x00,0x40,0x00);			//Si ya presiono borra el dato	
			                    if(DirMuxDef[teclas1]==0x2C){
			                        comas1=0;
			                    }
			                    teclas1--;
			                }
			            }
			            if(LCD_1_rxBuffer[3]==0x0C){					//ENT
			                if(teclas1>=1){	//Animacion --> Menu Principal --> Combustibles --> Contado --> Dinero --> Suba la Manija
								DirMuxDef[0]=teclas1;
			                    flujo_DirMux=2;				
			                }
			            }
			        }
			        CyDelay(100);            
			        LCD_1_ClearRxBuffer();
			    }
			break;
				
			case 2:
				for(i=0;i<=10;i++){
					if(DirMuxDef[i]==DirMuxPrueba[i]){
						flujo_DirMux=3;
					}else{
						DireccionMux=0;
						set_imagen(1,16);	//mensaje fuel control
						uint8 msn[15]="Codigo No Valid";
						for(i=0;i<=5;i++){
							write_LCD(1,(msn[i]),i,0x80,0x00,0x20,0x00);
						}
						for(i=6;i<=14;i++){
							write_LCD(1,(msn[i]),i-5,0x00,0x01,0x20,0x00);
						}
						flujo_DirMux=0;
						teclas1=0;
						CyDelay(1000);
						for(i=0;i<=10;i++){	//Para Borrar Datos digitados
							DirMuxDef[i]=0;
						}
						for(i=0;i<=10;i++){	//Para Borrar Datos digitados
							DirMuxPrueba[i]=0;
						}
						set_imagen(1,37);	//digite numero
						i=11;
					}
				}	
			break;
				
			case 3:
				write_eeprom(276,DirMuxDef);
				DireccionMux=1;
			break;
		}
	}
	set_imagen(1,59);	//mensaje fuel control positivo
	for(i=1;i<=3;i++){
		write_LCD(1,(DirMuxDef[i]),i,0xB4,0x00,0x20,0x00);//Coloca el serial del MUX (3 primeros Digitos)
	}
	for(i=1;i<=7;i++){
		write_LCD(1,(DirMuxDef[i+3]),i,0x00,0x01,0x20,0x00);//Coloca el serial del MUX (7 ultimos Digitos)
	}
	CyDelay(1500);
}

/*
*********************************************************************************************************
*                                         init( void )
*
* Description : Verifica el serial, inicia los perosfericos, la version y los datos de la estación.
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : main()
*
* Note(s)     : none.
*********************************************************************************************************
*/
void init(void){
    uint32 x;
	/****Inicio de perisfericos****/
    CyGlobalIntEnable;
    Surtidor_EnableRxInt();
    PC_EnableRxInt();
    I2C_1_Start();
    Surtidor_Start();
    Pistola_Start();
    LCD_1_Start();
    LCD_2_Start();
    Pistola_EnableRxInt();
    LCD_1_EnableRxInt();
    LCD_2_EnableRxInt();
    PC_Start();
    VDAC8_3_Start();
    CyDelay(5);	
	
	/****Lectura de variables en memoria eeprom****/
	
	leer_eeprom(0,31);						//Nombre estacion
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			rventa.nombre[x]=buffer_i2c[x];
		}
	}else{
		uint8 mens1[16]="SISTEMAS INSEPET";
		rventa.nombre[0]=16;
		for(x=1;x<=16;x++){
			rventa.nombre[x]=mens1[x-1];
		}
	}
	
	leer_eeprom(64,31);						//Direccion estacion
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			rventa.direccion[x]=buffer_i2c[x];
		}
	}else{
		uint8 mens3[25]="Cra. 90 #17B 75 Bodega 21";
		rventa.direccion[0]=25;
		for(x=1;x<=25;x++){
			rventa.direccion[x]=mens3[x-1];
		}
	}
	
	leer_eeprom(31,31);					//Lema 1
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			rventa.lema1[x]=buffer_i2c[x];
		}	
	}else{
		uint8 mens5[17]="Bogota - Colombia";
		rventa.lema1[0]=17;
		for(x=1;x<=17;x++){
			rventa.lema1[x]=mens5[x-1];
		}
	}
	
	leer_eeprom(95,31);					//Lema 2
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			rventa.lema2[x]=buffer_i2c[x];
		}
	}else{
		uint8 mens6[22]="Calidad en el Servicio";
		rventa.lema2[0]=22;
		for(x=1;x<=22;x++){
			rventa.lema2[x]=mens6[x-1];
		}
	}
    
    leer_eeprom(655,8);                 //Preset P1
    if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			Buffer_LCD1.P1[x]=buffer_i2c[x];
            Buffer_LCD2.P1[x]=buffer_i2c[x];
		}
	}else{
		for(x=0;x<=7;x++){
			Buffer_LCD1.P1[x]=0;
            Buffer_LCD2.P1[x]=0;
		}
	}
    
    leer_eeprom(663,8);                 //Preset P2
    if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			Buffer_LCD1.P2[x]=buffer_i2c[x];
            Buffer_LCD2.P2[x]=buffer_i2c[x];
		}
	}else{
		for(x=0;x<=7;x++){
			Buffer_LCD1.P2[x]=0;
            Buffer_LCD2.P2[x]=0;
		}
	}
    
    leer_eeprom(983,8);                 //Preset P3
    if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			Buffer_LCD1.P3[x]=buffer_i2c[x];
            Buffer_LCD2.P3[x]=buffer_i2c[x];
		}
	}else{
		for(x=0;x<=7;x++){
			Buffer_LCD1.P3[x]=0;
            Buffer_LCD2.P3[x]=0;
		}
	}
    
	leer_eeprom(192,2);
	if(buffer_i2c[0]==1){
		 lado.c.versdig=(buffer_i2c[1]&0x07);
	}else{
		lado.c.versdig=5;
	}
	
	leer_eeprom(194,2);
	if(buffer_i2c[0]==1){
		corriente=buffer_i2c[1];
	}else{
		corriente=1;
	}
	
	leer_eeprom(196,2);
	if(buffer_i2c[0]==1){
		extra=buffer_i2c[1];
	}else{
		extra=0;
	}
	
	leer_eeprom(198,2);
	if(buffer_i2c[0]==1){
		diesel=buffer_i2c[1];
	}else{
		diesel=0;
	}
	
	leer_eeprom(200,2);
	if(buffer_i2c[0]==1){
		corriente2=buffer_i2c[1];
	}else{
		corriente2=1;
	}
	
	leer_eeprom(202,2);
	if(buffer_i2c[0]==1){
		extra2=buffer_i2c[1];
	}else{
		extra2=0;
	}
	
	leer_eeprom(204,2);
	if(buffer_i2c[0]==1){
		diesel2=buffer_i2c[1];
	}else{
		diesel2=0;
	}
	
	leer_eeprom(206,2);
	if(buffer_i2c[0]==1){
		 ppux10=(buffer_i2c[1]&0x0f);
	}else{
		ppux10=0;
	}
	
	leer_eeprom(208,2);
	if(buffer_i2c[0]==1){
		 Placa_Contado=buffer_i2c[1];
	}else{
		Placa_Contado=0x01;//Placa Obligatoria (No 0x00)
	}
	
	leer_eeprom(210,2);
	if(buffer_i2c[0]==1){
		 decimalD=(buffer_i2c[1]&0x0f);
	}else{
		decimalD=0;
	}
	
	leer_eeprom(212,2);
	if(buffer_i2c[0]==1){
		 decimalV=(buffer_i2c[1]&0x0f);
	}else{
		decimalV=3;
	}
	
	leer_eeprom(256,2);
	if(buffer_i2c[0]==1){
		 lado.d.turno=(buffer_i2c[1]&0x0f);
	}else{
		lado.d.turno=0;
	}
	
	leer_eeprom(258,18);
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			IdentVendedor[x]=buffer_i2c[x];
		}
	}else{
		IdentVendedor[0]=0;
	}
	
	leer_eeprom(214,2);
	if(buffer_i2c[0]==1){
		Buffer_LCD1.VentasPendientesE=buffer_i2c[1];
	}else{
		Buffer_LCD1.VentasPendientesE=0;
	}
	Buffer_LCD1.VentasPendientesR=0;
    
	leer_eeprom(216,2);
	if(buffer_i2c[0]==1){
		Buffer_LCD2.VentasPendientesE=buffer_i2c[1];
	}else{
		Buffer_LCD2.VentasPendientesE=0;
	}
	Buffer_LCD2.VentasPendientesR=0;
    
	print1[1]=1;
	print2[1]=2;
    versurt=6;//declarando cualquier valor en antiguo version de surtidor
    isr_5_StartEx(Rf);  
	Timer_Rf_Start();
    count_rf=0;
}

/*
*********************************************************************************************************
*                                         init_surt( void )
*
* Description : Busca las posiciones del surtidor y las graba en lado.a.dir y lado.b.dir
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : main()
*
* Note(s)     : Falta generar codigo para los casos 1 y 2
*********************************************************************************************************
*/
void init_surt(void){
	uint8 seguir=0;
    uint32 x;
	while(seguir==0){
		switch(ver_pos()){
			case 0:
														//mostrar error de comunicacion	
			break;
			
			case 1:
														//Una de las pos no responde
			break;
			
			case 2:
			CyDelay(100);
			if(get_estado(lado.a.dir)==6){	
				if(get_estado(lado.b.dir)==6){
					seguir=2;							//Las dos pos contestaron
				}
			}	
			break;
		}
	}
	leer_eeprom(128,8);	//PPU Lado1 manguera 1
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			Buffer_LCD1.PPUClienteContado1[x]=buffer_i2c[x];
		}
		Buffer_LCD1.NumManguera[1]=1;
	}
	leer_eeprom(136,8);	//PPU Lado1 manguera 2
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			Buffer_LCD1.PPUClienteContado2[x]=buffer_i2c[x];
		}
		Buffer_LCD1.NumManguera[2]=2;
	}
	leer_eeprom(144,8);	//PPU Lado1 manguera 3
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			Buffer_LCD1.PPUClienteContado3[x]=buffer_i2c[x];
		}
		Buffer_LCD1.NumManguera[3]=3;
	}
	if(Buffer_LCD1.NumManguera[1]!=0){
		programarPPUContado(1);
	}
	leer_eeprom(159,8);	//PPU Lado2 manguera 1
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			Buffer_LCD2.PPUClienteContado1[x]=buffer_i2c[x];
		}
		Buffer_LCD2.NumManguera[1]=1;
	}
	leer_eeprom(167,8);	//PPU Lado2 manguera 2
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			Buffer_LCD2.PPUClienteContado2[x]=buffer_i2c[x];
		}
		Buffer_LCD2.NumManguera[2]=2;
	}
	leer_eeprom(175,8);	//PPU Lado2 manguera 3
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			Buffer_LCD2.PPUClienteContado3[x]=buffer_i2c[x];
		}
		Buffer_LCD2.NumManguera[3]=3;
	}
	if(Buffer_LCD2.NumManguera[1]!=0){
		programarPPUContado(2);
	}
	for(x=1;x<=3;x++){
		Buffer_LCD1.NumManguera[x]=0;
		Buffer_LCD2.NumManguera[x]=0;
	}
	
	if(Buffer_LCD1.VentasPendientesE>0){
		set_imagen(1,39);//Recuperando ventas
		RecuperarVentas(lado.a.dir,2);
		Buffer_LCD1.Estado_Mux = 0xA6;//Estado ventas
	}else{
		Buffer_LCD1.Estado_Mux = 0xA1;//Estado inicial de Espera
	}
	if(Buffer_LCD2.VentasPendientesE>0){
		set_imagen(2,39);//Recuperando ventas
		RecuperarVentas(lado.b.dir,2);
		Buffer_LCD2.Estado_Mux = 0xA6;//Estado ventas
	}else{
		Buffer_LCD2.Estado_Mux = 0xA1;//Estado inicial de Espera
	}
}

/*
************************************************************************************************************
*                                         void error_op()
*
* Description : Muestra en la pantalla el mensaje de operación incorrecta y regresa al inicio del Flujo LCD
*               
*
* Argument(s) : uint8 lcd, para elegir cual pantalla entra en esta función
*
* Return(s)   : none
*
* Caller(s)   : Desde cualquier momento de la operacion donde ocurra un error por parte del usuario
*
* Note(s)     : none.
************************************************************************************************************
*/
void error_op(uint8 lcd){
	if(lcd==1){
	    set_imagen(1,3);
	    flujo_LCD=100;
		count_protector=1;
	    isr_3_StartEx(animacion);  
	    Timer_Animacion_Start();
	}
	else{
	    set_imagen(2,3);
	    flujo_LCD2=100;
		count_protector2=1;
	    isr_4_StartEx(animacion2);  
	    Timer_Animacion2_Start();	
	}
}


/*
***********************************************************************************************************
*                                         void polling_LCD1(void)
*
* Description : Ejecuta las diferentes funciones que se pueden realizar desde la pantalla 1
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : Se ejecuta dentro del ciclo infinito del main()
*
* Note(s)     : none.
***********************************************************************************************************
*/

void polling_LCD1(void){
    uint32 i,x,z,j,w;
	switch(flujo_LCD){
		case 100://Inicio de protector
	        if(count_protector>=7){//Espera a que pasen 2.5 seg aprox e inicia la pantalla
	            flujo_LCD=0;							 
	            isr_3_Stop(); 
	            Timer_Animacion_Stop(); 
	            count_protector=0;
	        }
        break;
		
		case 0:	//Protector de Pantalla
			isr_3_StartEx(animacion);
			Timer_Animacion_Start();
	        count_protector=0;
	        flujo_LCD=1;//Caso 1
		break;
		
		case 1:	//Esperando a presionar la pantalla
			if(LCD_1_GetRxBufferSize()==8){
	            flujo_LCD=2;	//Caso 2
	            LCD_1_ClearRxBuffer(); 
	            isr_3_Stop();
	            Timer_Animacion_Stop();			
	            set_imagen(1,51);
			}
		break;
		
		case 2://Pasa a pantalla inicial de opciones y limpia el buffer
			flujo_LCD=3;	//Caso 3
		 	CyDelay(20);
         	LCD_1_ClearRxBuffer();
		break;
		
		case 3:	//Menu Principal
	        if(LCD_1_GetRxBufferSize()==8){	 
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                switch(LCD_1_rxBuffer[3]){
	                    case 0x3F:					//Combustibles
							if(lado.d.turno==1){//Solo si esta abierto el turno
								set_imagen(1,25);	//contado contado control credito
								flujo_LCD=4;		//Caso 4
							}
	                    break;                
	                    
						case 0x44:				//Turno
							set_imagen(1,22);	//APERTURA CIERRE ARQUEO1a
							flujo_LCD=27;		//Caso 27
	                    break;
													
						case 0x43:				//Calibracion
							if(lado.d.turno==1){		//Solo si esta abierto el turno
							  	set_imagen(1,8);	//esperando 1
								flujo_LCD=26;		//Caso 26
								resetvariables(1);
								Buffer_LCD1.TipodeVenta='5';
								Buffer_LCD1.Estado_Mux=0xE6;//Calibracion
								Buffer_LCD1.AutorizacionTrasCali=0x02;//Para evitar conflictos
								isr_3_StartEx(animacion);
								Timer_Animacion_Start();
								count_protector=0;
							}
	                    break;
						
	                    case 0x42:				//Traslados
							if(lado.d.turno==1){		//Solo si esta abierto el turno
							  	set_imagen(1,8);	//esperando 1
								flujo_LCD=26;		//Caso 26
								resetvariables(1);
								Buffer_LCD1.TipodeVenta='6';
								Buffer_LCD1.Estado_Mux=0xF1;//Autorizacion para Traslados
								Buffer_LCD1.AutorizacionTrasCali=0x02;//Para evitar conflictos
								isr_3_StartEx(animacion);
								Timer_Animacion_Start();
								count_protector=0;
							}
	                    break;
							
						case 0x40:				//Canastilla
							if(lado.d.turno==1){		//Solo si esta abierto el turno
		                      	set_imagen(1,71);	//CONTADO CREDITO
								flujo_LCD=35;		//Caso 35
							}
	                    break;
                            
                        case 0x58:              //P1
                            if(lado.d.turno==1 && Buffer_LCD1.P1[0]>0){
                                resetvariables(1);
                                Buffer_LCD1.preset&=0xFC;
    							Buffer_LCD1.preset|=2;
                                flujo_LCD=7;      	//Caso 7
    	                        set_imagen(1,63);	//SUBA la manija
    							Buffer_LCD1.PresetProgramado='D';
                                Buffer_LCD1.TipodeVenta='0';
    							for(i=0;i<=Buffer_LCD1.P1[0];i++){
    								Buffer_LCD1.valor[i]=Buffer_LCD1.P1[i];
    								Buffer_LCD1.ValorPreset[i]=Buffer_LCD1.P1[i];
    							}
                            }
                        break;
                            
                        case 0x59:              //P2
                            if(lado.d.turno==1 && Buffer_LCD1.P2[0]>0){
                                resetvariables(1);
                                Buffer_LCD1.preset&=0xFC;
    							Buffer_LCD1.preset|=2;
                                flujo_LCD=7;      	//Caso 7
    	                        set_imagen(1,63);	//SUBA la manija
    							Buffer_LCD1.PresetProgramado='D';
                                Buffer_LCD1.TipodeVenta='0';
    							for(i=0;i<=Buffer_LCD1.P2[0];i++){
    								Buffer_LCD1.valor[i]=Buffer_LCD1.P2[i];
    								Buffer_LCD1.ValorPreset[i]=Buffer_LCD1.P2[i];
    							}
                            }
                        break;
                            
                        case 0x5A:              //P3
                            if(lado.d.turno==1 && Buffer_LCD1.P3[0]>0){
                                resetvariables(1);
                                Buffer_LCD1.preset&=0xFC;
    							Buffer_LCD1.preset|=2;
                                flujo_LCD=7;      	//Caso 7
    	                        set_imagen(1,63);	//SUBA la manija
    							Buffer_LCD1.PresetProgramado='D';
                                Buffer_LCD1.TipodeVenta='0';
    							for(i=0;i<=Buffer_LCD1.P3[0];i++){
    								Buffer_LCD1.valor[i]=Buffer_LCD1.P3[i];
    								Buffer_LCD1.ValorPreset[i]=Buffer_LCD1.P3[i];
    							}
                            }
                        break;
						
                        case 0x5C:				//Impresion misma posicion
							if(lado.d.turno==1 && Buffer_LCD1.placa[0]>0){		//Solo si esta abierto el turno
							  	set_imagen(1,8);	//esperando 1
								flujo_LCD=43;		//Caso 43
								Buffer_LCD1.Estado_Mux=0xA9;//Impresion misma posicion
                                impresion1=1;
								isr_3_StartEx(animacion);
								Timer_Animacion_Start();
								count_protector=0;
                                Buffer_LCD1.impresionultimaventa=0x02;//Para evitar conflictos
							}
	                    break;
                            
                        case 0x5B:				//Impresion otra posicion
							if(lado.d.turno==1 && Buffer_LCD1.placa[0]>0){		//Solo si esta abierto el turno
							  	set_imagen(1,8);	//esperando 1
								flujo_LCD=43;		//Caso 43
								Buffer_LCD1.Estado_Mux=0xAA;//Impresion otra posicion
                                impresion1=2;
								isr_3_StartEx(animacion);
								Timer_Animacion_Start();
								count_protector=0;
                                Buffer_LCD1.impresionultimaventa=0x02;//Para evitar conflictos
							}
	                    break;
                            
                        case 0x5D:              //Informacion de Mux
                            set_imagen(1,41);     //Informacion mux
                            for(i=1;i<=10;i++){
                                write_LCD(1,DirMuxDef[i],i-2,0x37,0,55,0); 
                                write_LCD(1,versionmux[i-1],i-2,0x37,0,60,1);
                            }
                            write_LCD(1,(lado.a.dir/10)+48,3,0x37,0,185,0);
                            write_LCD(1,(lado.a.dir%10)+48,4,0x37,0,185,0);
                            leer_fecha();
                            write_LCD(1,'2',0,100,1,55,0);
                            write_LCD(1,'0',1,100,1,55,0);
                            write_LCD(1,((rventa.fecha[2]&0xF0)>>4)+48,2,100,1,55,0);
                            write_LCD(1,(rventa.fecha[2]&0x0F)+48,3,100,1,55,0);
                            if((((rventa.fecha[2]&0xF0)>>4)+48)>0x39 &&((rventa.fecha[2]&0x0F)+48)>0x39){
                                Buffer_LCD1.Estado_Mux=0xA5;//Requiere configuraciones iniciales
                            }else if((((rventa.fecha[2]&0xF0)>>4)+48)=='0' &&((rventa.fecha[2]&0x0F)+48)=='0'){
                                Buffer_LCD1.Estado_Mux=0xA5;//Requiere configuraciones iniciales
                            }
                            write_LCD(1,'/',4,100,1,55,0);
                            write_LCD(1,((rventa.fecha[1]&0x10)>>4)+48,5,100,1,55,0);
                            write_LCD(1,(rventa.fecha[1]&0x0F)+48,6,100,1,55,0);
                            write_LCD(1,'/',1,1,2,55,0);
                            write_LCD(1,((rventa.fecha[0]&0x30)>>4)+48,2,1,2,55,0);
                            write_LCD(1,(rventa.fecha[0]&0x0F)+48,3,1,2,55,0);
                            leer_hora();
                            write_LCD(1,((rventa.hora[2]&0xF0)>>4)+48,1,100,1,185,0);
                            write_LCD(1,(rventa.hora[2]&0x0F)+48,2,100,1,185,0);
                            write_LCD(1,':',3,100,1,185,0);
                            write_LCD(1,((rventa.hora[1]&0xF0)>>4)+48,4,100,1,185,0);
                            write_LCD(1,(rventa.hora[1]&0x0F)+48,5,100,1,185,0);
                            write_LCD(1,':',6,100,1,185,0);
                            write_LCD(1,((rventa.hora[0]&0xF0)>>4)+48,1,1,2,185,0);
                            write_LCD(1,(rventa.hora[0]&0x0F)+48,2,1,2,185,0);
                            write_LCD(1,(lado.c.versdig/10)+48,4,100,1,60,1);
                            write_LCD(1,(lado.c.versdig%10)+48,5,100,1,60,1);
                            flujo_LCD=44;		//Caso 44
                        break;
                            
						case 0x0D:				//Atras 
                            set_imagen(1,0);
						  	flujo_LCD=0;		//Caso 0
							LCD_1_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_1_ClearRxBuffer();
	        }
	    break;
			
		case 4:	//Venta de Combustibles
			if(LCD_1_GetRxBufferSize()==8){	
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                switch(LCD_1_rxBuffer[3]){
	                    case 0x37:				//Contado
							set_imagen(1,7);	//dinero volumen full
							flujo_LCD=5;		//Caso 5
							resetvariables(1);
							Buffer_LCD1.TipodeVenta='0';
	                    break;                
	                    
	                    case 0x38:				//Contado Control
							set_imagen(1,14);	//intro km
							flujo_LCD=12;		//Caso 12
							resetvariables(1);
							Buffer_LCD1.TipodeVenta='2';
							Buffer_LCD1.CompTeclado=6;
							teclas1=0;
	                    break; 

	                    case 0x39:				//Credito
	                    	set_imagen(1,14);	//intro km
							flujo_LCD=12;		//Caso 12
							resetvariables(1);
							Buffer_LCD1.TipodeVenta='1';
							Buffer_LCD1.CompTeclado=6;
							teclas1=0;
	                    break;
						
	                    case 0x0D:				//Atras --> Menu Principal
						  	flujo_LCD=3;		//Caso 3
							set_imagen(1,51);	//menu distracom
							LCD_1_ClearRxBuffer();
							Buffer_LCD1.TipodeVenta=0;
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_1_ClearRxBuffer();
	        }
		break;
			
		case 5:	//Venta Combustible de Contado
			if(LCD_1_GetRxBufferSize()==8){	
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					Buffer_LCD1.preset&=0xFC;
	                switch(LCD_1_rxBuffer[3]){
	                    case 0x15:				//Dinero
							set_imagen(1,15);	//Intro Valor
							flujo_LCD=6;		//Case 6
							teclas1=0;          //Inicia el contador de teclas  
							write_LCD(1,'$',0,0x37,0x00,0x40,0x00);
					  		Buffer_LCD1.preset|=2;
							Buffer_LCD1.PresetProgramado='D';
	                    break;
	                    
	                    case 0x16:				//Volumen                             
		                    set_imagen(1,13);	//intro galones1
							flujo_LCD=6;       	//Caso 6          
		                    teclas1=0;			//Inicia el contador de teclas
		                    comas1=0;
		                    write_LCD(1,'G',0,0x37,0x00,0x40,0x00);
							Buffer_LCD1.preset|=1;
							Buffer_LCD1.PresetProgramado='V';
	                    break; 

	                    case 0x17:				//Full
							flujo_LCD=7;      	//Caso 7
	                        set_imagen(1,63);	//SUBA la manija
							Buffer_LCD1.preset|=2;
							Buffer_LCD1.PresetProgramado='F';
							for(i=1;i<=(lado.c.versdig-1);i++){
								Buffer_LCD1.valor[i]=0x39;
								Buffer_LCD1.ValorPreset[i]=0x39;
								if(i==(lado.c.versdig-1)){
									Buffer_LCD1.valor[i]=0x30;
									Buffer_LCD1.ValorPreset[i]=0x30;
									Buffer_LCD1.valor[i+1]=0x30;
									Buffer_LCD1.ValorPreset[i+1]=0x30;
								}
							}
							Buffer_LCD1.valor[0]=lado.c.versdig;
							Buffer_LCD1.ValorPreset[0]=lado.c.versdig;
	                    break;
						
	                    case 0x0D:				//Atras
						  	flujo_LCD=4;		//Caso 4
							set_imagen(1,25);	//contado contado control credito
							LCD_1_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_1_ClearRxBuffer();
	        }
		break;
			
		case 6:	//Digite valor a tanquear
			if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                if(teclas1<=(lado.c.versdig-1)){
	                    if(LCD_1_rxBuffer[3]<=9){
	                        teclas1++;
	                        Buffer_LCD1.valor[teclas1]=LCD_1_rxBuffer[3]+0x30;
							Buffer_LCD1.ValorPreset[teclas1]=LCD_1_rxBuffer[3]+0x30;
	                        write_LCD(1,(LCD_1_rxBuffer[3]+0x30),teclas1,0x37,0x00,0x40,0x00);
	                    }
	                    if(LCD_1_rxBuffer[3]==0x0A){            	//Comando de 0
	                        teclas1++;
	                        Buffer_LCD1.valor[teclas1]=0x30;
							Buffer_LCD1.ValorPreset[teclas1]=0x30;
	                        write_LCD(1,0x30,teclas1,0x37,0x00,0x40,0x00);
	                    }  
	                    if(LCD_1_rxBuffer[3]==0x4E){            	//Comando de Coma
	                        if(teclas1>=1 && comas1==0){
	                            teclas1++;
	                            Buffer_LCD1.valor[teclas1]=0x2C;
								Buffer_LCD1.ValorPreset[teclas1]=0x2C;
	                            write_LCD(1,0x2C,teclas1,0x37,0x00,0x40,0x00);
	                            comas1=1;
	                        }
	                    }
	                }
	                if(LCD_1_rxBuffer[3]==0x0B){					//DEL
	                    if(teclas1==0){								//Si no ha presionado nada regresa al menu anterior
							set_imagen(1,7);
		                    flujo_LCD=5;
	                    }
	                    else{
	                        write_LCD(1,0x20,(teclas1),0x37,0x00,0x40,0x00);			//Si ya presiono borra el dato	
	                        if(Buffer_LCD1.valor[teclas1]==0x2C){
	                            comas1=0;
	                        }
	                        teclas1--;
	                    }
	                }
	                if(LCD_1_rxBuffer[3]==0x0C){					//ENT
	                    if(teclas1>=1){	//Animacion --> Menu Principal --> Combustibles --> Contado --> Dinero --> Suba la Manija
							Buffer_LCD1.valor[0]=teclas1;
							Buffer_LCD1.ValorPreset[0]=teclas1;
							flujo_LCD=7;      	//Caso 7
	                        set_imagen(1,63);	//SUBA la manija
							LCD_1_ClearRxBuffer();
	                    }
	                }
					if(LCD_1_rxBuffer[3]==0x0D){//Atras --> Contado
						teclas1=0;
						flujo_LCD=5;		//Caso 5
					set_imagen(1,7);	//dinero volumen full
						LCD_1_ClearRxBuffer();	
					}
	            }
	            CyDelay(20);            
	            LCD_1_ClearRxBuffer();
	        }
		break;
			
		case 7:	//Esperando a subir la manija para programar el equipo
	        if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                if(LCD_1_rxBuffer[3]==0x0D){//Cancel
						Buffer_LCD1.Estado_Mux=0xA1;	//Queda en espera
						set_imagen(1,0);		//animacion0
						flujo_LCD=0;			//Caso 0
	                }												
				}
	            CyDelay(20);            
	            LCD_1_ClearRxBuffer();
				break;
			}
			if(get_estado(lado.a.dir)==7){//Espera a que este en listo el equipo
				Buffer_LCD1.Estado_Mux=0xA3;//Se subio la manija, despues de programar el equipo
				CyDelay(50);
				producto1=estado_ex(lado.a.dir);											//Obtiene el grado de la manguera
				CyDelay(50);		
				if((Buffer_LCD1.preset&0x02)==0x02||(Buffer_LCD1.preset&0x01)==0x01){		//Dependiendo del preset hace la programación
					if(programar(lado.a.dir,producto1,Buffer_LCD1.valor,(Buffer_LCD1.preset&0x03))==0){
						Buffer_LCD1.Estado_Mux=0xA5;//Se cancelo la operacion despues de subir la manija
						set_imagen(1,3);	   //cancelada por pc
						isr_3_StartEx(animacion);
						Timer_Animacion_Start();
						flujo_LCD=100;		//Caso 100
						count_protector=0;
						break;
					}					
				}
				producto1=estado_ex(lado.a.dir);
				if(producto1!=0){
					if(get_totales(lado.a.dir)!=0){
						if(producto1==1){
							for(i=0;i<=Buffer_LCD1.TotalVolumen1[0];i++){
								Buffer_LCD1.TotalVolumenAnterior[i]=Buffer_LCD1.TotalVolumen1[i];
								Buffer_LCD1.TotalDineroAnterior[i]=Buffer_LCD1.TotalDinero1[i];
							}
						}else if(producto1==2){
							for(i=0;i<=Buffer_LCD1.TotalVolumen2[0];i++){
								Buffer_LCD1.TotalVolumenAnterior[i]=Buffer_LCD1.TotalVolumen2[i];
								Buffer_LCD1.TotalDineroAnterior[i]=Buffer_LCD1.TotalDinero2[i];
							}
						}else if(producto1==3){
							for(i=0;i<=Buffer_LCD1.TotalVolumen3[0];i++){
								Buffer_LCD1.TotalVolumenAnterior[i]=Buffer_LCD1.TotalVolumen3[i];
								Buffer_LCD1.TotalDineroAnterior[i]=Buffer_LCD1.TotalDinero3[i];
							}
						}
					}
					Surtidor_PutChar(0x10|lado.a.dir);//Autoriza el surtidor
				    flujo_LCD=8;		//Caso 8
					if(leer_fecha()==1){//Lectura de Fecha Inicial
						Buffer_LCD1.FechaInicialVenta[0]=14;
						Buffer_LCD1.FechaInicialVenta[1]=0x32;
						Buffer_LCD1.FechaInicialVenta[2]=0x30;
						Buffer_LCD1.FechaInicialVenta[3]=(((rventa.fecha[2]&0xF0)>>4)+48);
						Buffer_LCD1.FechaInicialVenta[4]=((rventa.fecha[2]&0x0F)+48);
						Buffer_LCD1.FechaInicialVenta[5]=(((rventa.fecha[1]&0x10)>>4)+48);
						Buffer_LCD1.FechaInicialVenta[6]=((rventa.fecha[1]&0x0F)+48);
						Buffer_LCD1.FechaInicialVenta[7]=(((rventa.fecha[0]&0x30)>>4)+48);
						Buffer_LCD1.FechaInicialVenta[8]=((rventa.fecha[0]&0x0F)+48);
					}
					if(leer_hora()==1){//Lectura de Hora Inicial	
						Buffer_LCD1.FechaInicialVenta[9]=(((rventa.hora[2]&0xF0)>>4)+48);	
						Buffer_LCD1.FechaInicialVenta[10]=((rventa.hora[2]&0x0F)+48);
						Buffer_LCD1.FechaInicialVenta[11]=(((rventa.hora[1]&0xF0)>>4)+48);
						Buffer_LCD1.FechaInicialVenta[12]=((rventa.hora[1]&0x0F)+48);
						Buffer_LCD1.FechaInicialVenta[13]=(((rventa.hora[0]&0xF0)>>4)+48);
						Buffer_LCD1.FechaInicialVenta[14]=((rventa.hora[0]&0x0F)+48);
					}
				}
				LCD_2_ClearRxBuffer();
				PC_ClearRxBuffer();
        	}
		break;
			
		case 8://Coloca datos digitados durante el tanqueo en pantalla
			set_imagen(1,2);	//DATOS
			for(i=1;i<=Buffer_LCD1.placa[0];i++){		//Coloca la placa en la ventana de datos
				write_LCD(1,Buffer_LCD1.placa[i],i,0x05,0x01,0x65,0x00);
			}
			for(i=1;i<=Buffer_LCD1.cedula[0];i++){		//Coloca la cedula en la ventana de datos
				write_LCD(1,Buffer_LCD1.cedula[i],i,0x05,0x01,0xB0,0x00);
			}
			for(i=1;i<=Buffer_LCD1.Nit[0];i++){		//Coloca en Nit en la ventana de datos
				write_LCD(1,Buffer_LCD1.Nit[i],i,0x05,0x01,0xF7,0x00);
			}
			for(i=1;i<=Buffer_LCD1.km[0];i++){		//Coloca en km en la ventana de datos
				write_LCD(1,Buffer_LCD1.km[i],i,0x05,0x01,0x40,0x01);
			}
			flujo_LCD=9;
		break;
			
		case 9://Tanqueando, introduzca datos
			if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					switch(LCD_1_rxBuffer[3]){
						case 0x0E:	//Placa
							for(i=0;i<=7;i++){				//Para Borrar si se ha digitado placa anteriormente
								Buffer_LCD1.placa[i]=0x20;
							}
							set_imagen(1,6);	//digite placa
							flujo_LCD=10;		//Caso 10
							teclas1=0;
							LCD_1_ClearRxBuffer();
							count_protector=0;
						break;
						case 0x0F:	//Cedula
							for(i=0;i<=9;i++){				//Para Borrar si se ha digitado cedula anteriormente
								Buffer_LCD1.cedula[i]=0x20;
							}
							set_imagen(1,68);	//digite nit cc
							flujo_LCD=12;		//Caso 12
							Buffer_LCD1.CompTeclado=1;//Teclado de cedula 
							teclas1=0;
							LCD_1_ClearRxBuffer();
							count_protector=0;
						break;
						case 0x10:	//Nit
							for(i=0;i<=9;i++){				//Para Borrar si se ha digitado NIT anteriormente
								Buffer_LCD1.Nit[i]=0x20;
							}
							set_imagen(1,68);	//digite nit cc
							flujo_LCD=12;		//Caso 12
							Buffer_LCD1.CompTeclado=2;//Teclado de Nit
							teclas1=0;
							LCD_1_ClearRxBuffer();
							count_protector=0;
						break;
						case 0x11:	//Kilometraje
							for(i=0;i<=6;i++){				//Para Borrar si se ha digitado NIT anteriormente
								Buffer_LCD1.km[i]=0x20;
							}
							set_imagen(1,14);	//intro km1
							flujo_LCD=12;		//Caso 12
							Buffer_LCD1.CompTeclado=3;//Teclado de Kilometraje
							teclas1=0;
							LCD_1_ClearRxBuffer();
							count_protector=0;
						break;
						case 0x0C:	//Aceptar
							if(Placa_Contado==0x01){//Si la placa es obligatoria
								if(Buffer_LCD1.placa[0]==0){//No digito placa
									set_imagen(1,18);	//placa obligatoria
									CyDelay(100);
									flujo_LCD=8;
									LCD_1_ClearRxBuffer();
								}else if(Buffer_LCD1.placa[0]>=1){//Si Digito Placa
									set_imagen(1,20);	//tanqueando
									LCD_1_ClearRxBuffer();
								}
							}else if(Placa_Contado==0x00){//Si no es obligatoria la placa
								set_imagen(1,20);	//tanqueando
								LCD_1_ClearRxBuffer();
							}
						break;	
					}
				}
				CyDelay(20);
		        LCD_1_ClearRxBuffer();
			}
            switch (get_estado(lado.a.dir)){
                case 0x09://Surtiendo
                    Buffer_LCD1.Estado_Mux=0xAC;//Surtiendo Combustible
                break;
                case 0x0B://Termino venta
                    set_imagen(1,8);	//esperando 1
    				if(venta(lado.a.dir,producto1)==1){
    					if(Placa_Contado==0x01){//Si es con placa obligatoria
    						if(Buffer_LCD1.placa[0]==0){//No digito placa
    							set_imagen(1,6);	//digite placa
    							flujo_LCD=11;		//Caso 11
    							teclas1=0;
    						}else if(Buffer_LCD1.placa[0]>=1){//Si Digito Placa
    							set_imagen(1,4);	//desea imprimir recibo
    							flujo_LCD=13;	//Caso 13
    							LCD_1_ClearRxBuffer();
    							isr_3_StartEx(animacion); 
    							Timer_Animacion_Start();
    							count_protector=0;
    						}
    					}else if(Placa_Contado==0x00){//Si no es placa obligatoria
    						set_imagen(1,4);	//desea imprimir recibo
    						flujo_LCD=13;	//Caso 13
    						LCD_1_ClearRxBuffer();
    						isr_3_StartEx(animacion); 
    						Timer_Animacion_Start();
    						count_protector=0;
    					}
    				}
                break;
                case 0x0A://Termino venta
                    set_imagen(1,8);	//esperando 1
    				if(venta(lado.a.dir,producto1)==1){
    					if(Placa_Contado==0x01){//Si es con placa obligatoria
    						if(Buffer_LCD1.placa[0]==0){//No digito placa
    							set_imagen(1,6);	//digite placa
    							flujo_LCD=11;		//Caso 11
    							teclas1=0;
    						}else if(Buffer_LCD1.placa[0]>=1){//Si Digito Placa
    							set_imagen(1,4);	//desea imprimir recibo
    							flujo_LCD=13;	//Caso 13
    							LCD_1_ClearRxBuffer();
    							isr_3_StartEx(animacion); 
    							Timer_Animacion_Start();
    							count_protector=0;
    						}
    						
    					}else if(Placa_Contado==0x00){//Si no es placa obligatoria
    						set_imagen(1,4);	//desea imprimir recibo
    						flujo_LCD=13;	//Caso 13
    						LCD_1_ClearRxBuffer();
    						isr_3_StartEx(animacion); 
    						Timer_Animacion_Start();
    						count_protector=0;
    					}
    				}
                break;
                case 0x06://No hizo venta
    				Buffer_LCD1.Estado_Mux=0xA4;//No se realizo venta
    				flujo_LCD=0;
                break;
            }
		break;
			
		case 10://Digite Placa para datos
	        if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					count_protector=0;
	                if(teclas1<=7){
	                    if(LCD_1_rxBuffer[3]<=9){
	                        teclas1++;
	                        Buffer_LCD1.placa[teclas1]=LCD_1_rxBuffer[3]+0x30;
	                        write_LCD(1,(LCD_1_rxBuffer[3]+0x30),teclas1,0x05,0x01,0x28,0x00);                        
	                    }
	                    if(LCD_1_rxBuffer[3]==0x0A){                                        //Comando de 0
	                        teclas1++;                        
	                        Buffer_LCD1.placa[teclas1]=0x30;
	                        write_LCD(1,0x30,teclas1,0x05,0x01,0x28,0x00);                        
	                    }					
	                    if(LCD_1_rxBuffer[3]>=0x1B && LCD_1_rxBuffer[3]<=0x42){            //Comando de Letra
	                        for(x=0;x<=25;x++){                                            //Compara el dato que llego con un vector que tiene todas las letras     
	                            if(LCD_1_rxBuffer[3]==letras[x]){
	                                teclas1++;                            
	                                Buffer_LCD1.placa[teclas1]=x+0x41;
	                                write_LCD(1,(x+0x41),teclas1,0x05,0x01,0x28,0x00);                            
	                            }
	                        }
	                    }                    
	                }
	                if(LCD_1_rxBuffer[3]==0x0B){                                        //Borrar - Cancelar
	                    if(teclas1==0){
	                        Buffer_LCD1.placa[0]=0;
							if(Buffer_LCD1.CompTeclado==6){//Placa de contado control o credito
								set_imagen(1,52);	//METODO ID1a
								flujo_LCD=15;	//Caso 15
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==21){//Placa de Canastilla
								set_imagen(1,52);	//METODO ID1a
								flujo_LCD=36;	//Caso 36
								Buffer_LCD1.CompTeclado=0;
							}else{
								flujo_LCD=8;		//Caso 8
								Buffer_LCD1.CompTeclado=0;
							}
							LCD_1_ClearRxBuffer();
	                    }
	                    else{
	                        write_LCD(1,0x20,teclas1,0x05,0x01,0x28,0x00);                        
	                        teclas1--;
	                    }
	                }
	                if(LCD_1_rxBuffer[3]==0x0C){                                        //Enter pasa la informacion a la casilla Placa
	                    if(teclas1>=1){
	                        Buffer_LCD1.placa[0]=teclas1;
							if(Buffer_LCD1.CompTeclado==6){//Placa de contado control
								Buffer_LCD1.IdentCliente[0]=Buffer_LCD1.placa[0]+1;
								Buffer_LCD1.IdentCliente[1]='P';
								for(i=0;i<=Buffer_LCD1.placa[0];i++){
									Buffer_LCD1.IdentCliente[i+2]=Buffer_LCD1.placa[i+1];
								}
								Buffer_LCD1.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control
								Buffer_LCD1.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(1,8);	//esperando 1
								flujo_LCD=18;	//Caso 18
								Buffer_LCD1.CompTeclado=0;
								isr_3_StartEx(animacion); 
					         	Timer_Animacion_Start();
					         	count_protector=0;
							}else if(Buffer_LCD1.CompTeclado==21){//Placa de Canastilla
								Buffer_LCD1.IdentCliente[0]=Buffer_LCD1.placa[0]+1;
								Buffer_LCD1.IdentCliente[1]='P';
								for(i=0;i<=Buffer_LCD1.placa[0];i++){
									Buffer_LCD1.IdentCliente[i+2]=Buffer_LCD1.placa[i+1];
								}
								Buffer_LCD1.Estado_Mux=0xF7;//Autorizacion para Venta por Contado Control
								Buffer_LCD1.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(1,8);	//esperando 1
								flujo_LCD=37;	//Caso 37
								Buffer_LCD1.CompTeclado=0;
								isr_3_StartEx(animacion); 
					         	Timer_Animacion_Start();
					         	count_protector=0;
							}else{
								flujo_LCD=8;		//Caso 8
								Buffer_LCD1.CompTeclado=0;
							}
	                    }
	                }
	            }
	            CyDelay(20);            
	            LCD_1_ClearRxBuffer();
	        }
        break;
			
		case 11://Digite Placa Obligatoria
	        if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					count_protector=0;
	                if(teclas1<=7){
	                    if(LCD_1_rxBuffer[3]<=9){
	                        teclas1++;
	                        Buffer_LCD1.placa[teclas1]=LCD_1_rxBuffer[3]+0x30;
	                        write_LCD(1,(LCD_1_rxBuffer[3]+0x30),teclas1,0x05,0x01,0x28,0x00);                        
	                    }
	                    if(LCD_1_rxBuffer[3]==0x0A){                                        //Comando de 0
	                        teclas1++;                        
	                        Buffer_LCD1.placa[teclas1]=0x30;
	                        write_LCD(1,0x30,teclas1,0x05,0x01,0x28,0x00);                        
	                    }					
	                    if(LCD_1_rxBuffer[3]>=0x1B && LCD_1_rxBuffer[3]<=0x42){            //Comando de Letra
	                        for(x=0;x<=25;x++){                                            //Compara el dato que llego con un vector que tiene todas las letras     
	                            if(LCD_1_rxBuffer[3]==letras[x]){
	                                teclas1++;                            
	                                Buffer_LCD1.placa[teclas1]=x+0x41;
	                                write_LCD(1,(x+0x41),teclas1,0x05,0x01,0x28,0x00);                            
	                            }
	                        }
	                    }                    
	                }
	                if(LCD_1_rxBuffer[3]==0x0B){//Borrar - Cancelar
	                    if(teclas1==0){
							set_imagen(1,18);	//placa obligatoria
							CyDelay(100);
							set_imagen(1,6);	//digite placa
							flujo_LCD=11;		//Caso 11
							teclas1=0;
							LCD_1_ClearRxBuffer();
	                    }
	                    else{
	                        write_LCD(1,0x20,teclas1,0x05,0x01,0x28,0x00);                        
	                        teclas1--;
	                    }
	                }
	                if(LCD_1_rxBuffer[3]==0x0C){//Enter pasa la informacion a la casilla Placa
	                    if(teclas1>=1){
							if(Buffer_LCD1.CompTeclado==8){
								Buffer_LCD1.placa[0]=teclas1;
                                if(Buffer_LCD1.VentasPendientesR<3){
                                    escribir_ram(27+(186*(Buffer_LCD1.VentasPendientesR-1)),Buffer_LCD1.placa,1);
                                }else{
                                    write_eeprom(576+(512*(Buffer_LCD1.VentasPendientesE-1)),Buffer_LCD1.placa);
                                }
								set_imagen(1,50);	//imprimiendo 4
								flujo_LCD=14;	//Caso 14
								LCD_1_ClearRxBuffer();
								isr_3_StartEx(animacion); 
								Timer_Animacion_Start();
								count_protector=0;
								Buffer_LCD1.Impresionmux=0x02;//Para evitar conflictos mas adelante
								Buffer_LCD1.BanImpFin=0x02;//Para evitar conflictos mas adelante
								Buffer_LCD1.ConfirmacionImpresion='2';
								Buffer_LCD1.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
								Buffer_LCD1.CompTeclado=0;
							}else{
								Buffer_LCD1.placa[0]=teclas1;
								if(Buffer_LCD1.VentasPendientesR<3){
                                    escribir_ram(27+(186*(Buffer_LCD1.VentasPendientesR-1)),Buffer_LCD1.placa,1);
                                }else{
                                    write_eeprom(576+(512*(Buffer_LCD1.VentasPendientesE-1)),Buffer_LCD1.placa);
                                }
								set_imagen(1,4);	//desea imprimir recibo
								flujo_LCD=13;	//Caso 13
								LCD_1_ClearRxBuffer();
								isr_3_StartEx(animacion); 
								Timer_Animacion_Start();
								count_protector=0;
								Buffer_LCD1.CompTeclado=0;
							}
	                    }
	                }
	            }
	            CyDelay(20);            
	            LCD_1_ClearRxBuffer();
	        }
        break;
		
		case 12://Teclado para digitar Cedula, Nit, Km y N° de Fuel Control
			if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					count_protector=0;
	                if(teclas1<=9){
	                    if(LCD_1_rxBuffer[3]<=9){
	                        teclas1++;
	                        Buffer_LCD1.Numeros[teclas1]=LCD_1_rxBuffer[3]+0x30;
	                        write_LCD(1,(LCD_1_rxBuffer[3]+0x30),teclas1,0x05,0x00,0x40,0x00);
	                    }
	                    if(LCD_1_rxBuffer[3]==0x0A){            	//Comando de 0
	                        teclas1++;
	                        Buffer_LCD1.Numeros[teclas1]=0x30;
	                        write_LCD(1,0x30,teclas1,0x05,0x00,0x40,0x00);
	                    }                    
	                }
	                if(LCD_1_rxBuffer[3]==0x0B){					//DEL
	                    if(teclas1==0){								//Si no ha presionado nada regresa al menu anterior
	                        if(Buffer_LCD1.CompTeclado==1){//Teclado cedula tanqueando
								flujo_LCD=8;	//Caso 8
								Buffer_LCD1.cedula[0]=0;
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==2){//Teclado nit tanqueando
								flujo_LCD=8;	//Caso 8
								Buffer_LCD1.CompTeclado=0;
								Buffer_LCD1.Nit[0]=0;
							}else if(Buffer_LCD1.CompTeclado==3){//Teclado km tanqueando
								flujo_LCD=8;	//Caso 8
								Buffer_LCD1.CompTeclado=0;
								Buffer_LCD1.km[0]=0;
							}else if(Buffer_LCD1.CompTeclado==4||Buffer_LCD1.CompTeclado==5){
								set_imagen(1,52);	//METODO ID1a
								flujo_LCD=15;	//Caso 15
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==6){//Kilometraje para ID
								set_imagen(1,25);//contado contado control credito
								flujo_LCD=4;	//Caso 4
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==7){//Teclado cedula vendedor
								set_imagen(1,58);//ID Turno
								flujo_LCD=28;	//Caso 28
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==20||Buffer_LCD1.CompTeclado==23){//Teclado cedula canastilla o N° Fuel Control
								set_imagen(1,52);//METODO ID
								flujo_LCD=36;	//Caso 36
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==31||Buffer_LCD1.CompTeclado==32||Buffer_LCD1.CompTeclado==33||Buffer_LCD1.CompTeclado==34){//Teclado cantidad productos canastilla
								set_imagen(1,69);	//Canastilla
								LCD_Canastilla(1);
								flujo_LCD=39;		//Caso 39
								Buffer_LCD1.CompTeclado=0;
							}
							Buffer_LCD1.Numeros[0]=0;
	                    }else{
	                        write_LCD(1,0x20,(teclas1),0x05,0x00,0x40,0x00);			//Si ya presiono borra el dato	
	                        if(Buffer_LCD1.Numeros[teclas1]==0x2C){
	                            comas1=0;
	                        }
	                        teclas1--;
	                    }
	                }
	                if(LCD_1_rxBuffer[3]==0x0C){					//ENT
	                    if(teclas1>=1){
							Buffer_LCD1.Numeros[0]=teclas1;
							if(Buffer_LCD1.CompTeclado==1){//Cedula de Tanqueando
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.cedula[i]=Buffer_LCD1.Numeros[i];
								}
								flujo_LCD=8;	//Caso 8
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==2){//Nit de Tanqueando
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.Nit[i]=Buffer_LCD1.Numeros[i];
								}
								flujo_LCD=8;	//Caso 8
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==3){//Kilometraje de Tanqueando
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.km[i]=Buffer_LCD1.Numeros[i];
								}
								flujo_LCD=8;	//Caso 8
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==4){//Cedula de Contado Control o credito
								Buffer_LCD1.IdentCliente[0]=Buffer_LCD1.Numeros[0]+1;
								Buffer_LCD1.IdentCliente[1]='C';
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.IdentCliente[i+2]=Buffer_LCD1.Numeros[i+1];
									Buffer_LCD1.cedula[i]=Buffer_LCD1.Numeros[i];
								}
								Buffer_LCD1.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control
								Buffer_LCD1.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(1,8);	//esperando 1
								flujo_LCD=18;	//Caso 18
								Buffer_LCD1.CompTeclado=0;
								isr_3_StartEx(animacion); 
					         	Timer_Animacion_Start();
					         	count_protector=0;
							}else if(Buffer_LCD1.CompTeclado==5){//N° De Fuel Control de Contado Control o credito
								Buffer_LCD1.IdentCliente[0]=Buffer_LCD1.Numeros[0]+1;
								Buffer_LCD1.IdentCliente[1]='F';
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.IdentCliente[i+2]=Buffer_LCD1.Numeros[i+1];
								}
								Buffer_LCD1.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control
								Buffer_LCD1.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(1,8);	//esperando 1
								flujo_LCD=18;	//Caso 18
								Buffer_LCD1.CompTeclado=0;
								isr_3_StartEx(animacion); 
					         	Timer_Animacion_Start();
					         	count_protector=0;
							}else if(Buffer_LCD1.CompTeclado==6){//Kilometraje para validacion de ID
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.KmID[i]=Buffer_LCD1.Numeros[i];
									Buffer_LCD1.km[i]=Buffer_LCD1.Numeros[i];
								}
	                      		set_imagen(1,52);	//METODO ID1a
								flujo_LCD=15;		//Caso 15
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==7){//Cedula vendedor
								IdentVendedor[0]=Buffer_LCD1.Numeros[0]+1;
								IdentVendedor[1]='C';
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									IdentVendedor[i+2]=Buffer_LCD1.Numeros[i+1];
								}
								set_imagen(1,8);	//esperando 1
								flujo_LCD=29;	//Caso 29
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==20){//Teclado cedula canastilla
								Buffer_LCD1.IdentCliente[0]=Buffer_LCD1.Numeros[0]+1;
								Buffer_LCD1.IdentCliente[1]='C';
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.IdentCliente[i+2]=Buffer_LCD1.Numeros[i+1];
								}
								Buffer_LCD1.Estado_Mux=0xF7;//Autorizacion para Venta de Canastilla por Credito
								Buffer_LCD1.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(1,8);	//esperando 1
								flujo_LCD=37;	//Caso 37
								Buffer_LCD1.CompTeclado=0;
								isr_3_StartEx(animacion); 
					         	Timer_Animacion_Start();
					         	count_protector=0;
							}else if(Buffer_LCD1.CompTeclado==23){//Teclado N° Fuel Control canastilla
								Buffer_LCD1.IdentCliente[0]=Buffer_LCD1.Numeros[0]+1;
								Buffer_LCD1.IdentCliente[1]='F';
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.IdentCliente[i+2]=Buffer_LCD1.Numeros[i+1];
								}
								Buffer_LCD1.Estado_Mux=0xF7;//Autorizacion para Venta de Canastilla por Credito
								Buffer_LCD1.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(1,8);	//esperando 1
								flujo_LCD=37;	//Caso 37
								Buffer_LCD1.CompTeclado=0;
								isr_3_StartEx(animacion); 
					         	Timer_Animacion_Start();
					         	count_protector=0;
							}else if(Buffer_LCD1.CompTeclado==31){//Teclado producto 1 canastilla
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.CantProducto1Canasta[i]=Buffer_LCD1.Numeros[i];
								}
								if(Buffer_LCD1.CantProducto1Canasta[0]>3){
									Buffer_LCD1.CantProducto1Canasta[0]=3;
								}
	                      		set_imagen(1,69);	//Canastilla
								LCD_Canastilla(1);
								flujo_LCD=39;		//Caso 39
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==32){//Teclado producto 2 canastilla
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.CantProducto2Canasta[i]=Buffer_LCD1.Numeros[i];
								}
								if(Buffer_LCD1.CantProducto2Canasta[0]>3){
									Buffer_LCD1.CantProducto2Canasta[0]=3;
								}
	                      		set_imagen(1,69);	//Canastilla
								LCD_Canastilla(1);
								flujo_LCD=39;		//Caso 39
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==33){//Teclado producto 3 canastilla
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.CantProducto3Canasta[i]=Buffer_LCD1.Numeros[i];
								}
								if(Buffer_LCD1.CantProducto3Canasta[0]>3){
									Buffer_LCD1.CantProducto3Canasta[0]=3;
								}
	                      		set_imagen(1,69);	//Canastilla
								LCD_Canastilla(1);
								flujo_LCD=39;		//Caso 39
								Buffer_LCD1.CompTeclado=0;
							}else if(Buffer_LCD1.CompTeclado==34){//Teclado producto 4 canastilla
								for(i=0;i<=Buffer_LCD1.Numeros[0];i++){
									Buffer_LCD1.CantProducto4Canasta[i]=Buffer_LCD1.Numeros[i];
								}
								if(Buffer_LCD1.CantProducto4Canasta[0]>3){
									Buffer_LCD1.CantProducto4Canasta[0]=3;
								}
	                      		set_imagen(1,69);	//Canastilla
								LCD_Canastilla(1);
								flujo_LCD=39;		//Caso 39
								Buffer_LCD1.CompTeclado=0;
							}
	                    }
	                }
					if(LCD_1_rxBuffer[3]==0x0D){//Atras
						teclas1=0;
						for(i=1;i<=9;i++){				 
							Buffer_LCD1.Numeros[i]=0;
						}
						if(Buffer_LCD1.CompTeclado==1){//Teclado cedula tanqueando
							flujo_LCD=8;	//Caso 8
							Buffer_LCD1.cedula[0]=0;
							Buffer_LCD1.CompTeclado=0;
						}else if(Buffer_LCD1.CompTeclado==2){//Teclado nit tanqueando
							flujo_LCD=8;	//Caso 8
							Buffer_LCD1.CompTeclado=0;
							Buffer_LCD1.Nit[0]=0;
						}else if(Buffer_LCD1.CompTeclado==3){//Teclado km tanqueando
							flujo_LCD=8;	//Caso 8
							Buffer_LCD1.CompTeclado=0;
							Buffer_LCD1.km[0]=0;
						}else if(Buffer_LCD1.CompTeclado==4||Buffer_LCD1.CompTeclado==5){
							set_imagen(1,52);	//METODO ID1a
							flujo_LCD=15;	//Caso 15
							Buffer_LCD1.CompTeclado=0;
						}else if(Buffer_LCD1.CompTeclado==6){
							set_imagen(1,25);//contado contado control credito
							flujo_LCD=4;	//Caso 4
							Buffer_LCD1.CompTeclado=0;
						}else if(Buffer_LCD1.CompTeclado==7){//Teclado cedula vendedor
							set_imagen(1,58);//ID Turno
							flujo_LCD=28;	//Caso 28
							Buffer_LCD1.CompTeclado=0;
						}else if(Buffer_LCD1.CompTeclado==20||Buffer_LCD1.CompTeclado==23){//Teclado cedula o N° Fuel control credito canastilla
							set_imagen(1,52);	//METODO ID
							flujo_LCD=36;	//Caso 36
							Buffer_LCD1.CompTeclado=0;
						}else if(Buffer_LCD1.CompTeclado==31||Buffer_LCD1.CompTeclado==32||Buffer_LCD1.CompTeclado==33||Buffer_LCD1.CompTeclado==34){//Teclado cantidad productos canastilla
							set_imagen(1,69);	//Canastilla
							LCD_Canastilla(1);
							flujo_LCD=39;		//Caso 39
							Buffer_LCD1.CompTeclado=0;
						}
						Buffer_LCD1.Numeros[0]=0;
					}
	            }
	            CyDelay(20);            
	            LCD_1_ClearRxBuffer();
	        }
		break;
			
		case 13://Imprimir Venta Combustible
			if(LCD_1_GetRxBufferSize()==8){	
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                switch(LCD_1_rxBuffer[3]){
						case 0x14:	//cero
							set_imagen(1,10);	//gracias
	            			flujo_LCD=100;
							count_protector=0;
							Buffer_LCD1.ConfirmacionImpresion='0';
							Buffer_LCD1.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
						break;
							
						case 0x13:	//uno
							set_imagen(1,50);	//imprimiendo 4
							flujo_LCD=14; //caso 14
							count_protector=0;
							Buffer_LCD1.ConfirmacionImpresion='1';
							Buffer_LCD1.Impresionmux=0x02;//Para evitar conflictos mas adelante
							Buffer_LCD1.BanImpFin=0x02;//Para evitar conflictos mas adelante
							Buffer_LCD1.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
						break;
							
						case 0x57:	//dos
							set_imagen(1,50);	//imprimiendo 4
							flujo_LCD=14; //caso 14
							count_protector=0;
							Buffer_LCD1.ConfirmacionImpresion='2';
							Buffer_LCD1.Impresionmux=0x02;//Para evitar conflictos mas adelante
							Buffer_LCD1.BanImpFin=0x02;//Para evitar conflictos mas adelante
							Buffer_LCD1.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
						break;
					}
				}
				CyDelay(20);            
	            LCD_1_ClearRxBuffer();
			}
			if(count_protector>=30){
	            set_imagen(1,10);	//gracias
	            flujo_LCD=100; 
			    count_protector=0;
				Buffer_LCD1.ConfirmacionImpresion='0';
				Buffer_LCD1.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
		 	}
		break;
			
		case 14://Esperando trama de impresion por sistema
			if(count_protector>=25){//Si no llega nada imprime un recibo predeterminado
				print_logo(print1[1]);
				imprimir(print1[1], producto1,0,lado.a.dir);
                if(Buffer_LCD1.ConfirmacionImpresion=='2' && Buffer_LCD1.TipodeVenta=='0'){
                    print_logo(print1[1]);
				    imprimir(print1[1], producto1,0,lado.a.dir);
                }
				if(Buffer_LCD1.TipodeVenta=='1' || Buffer_LCD1.TipodeVenta=='2'){
					print_logo(print1[1]);
					imprimir(print1[1], producto1,1,lado.a.dir);
				}
				set_imagen(1,10);	//gracias
	            flujo_LCD=100; 
			    count_protector=0;
			}else if(Buffer_LCD1.BanImpFin==0x01){//Cuando finaliza la trama de impresion por sistema
				set_imagen(1,10);	//gracias
	            flujo_LCD=100;  
			    count_protector=0;
			}
		break;
			
		case 15://Venta Combustible de Credito
			if(LCD_1_GetRxBufferSize()==8){	
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                switch(LCD_1_rxBuffer[3]){
	                    case 0x45:				//CC/NIT
							set_imagen(1,68);	//digitenitcc
							flujo_LCD=12;		//Caso 12
							teclas1=0;
							Buffer_LCD1.CompTeclado=4;
							LCD_1_ClearRxBuffer();
	                    break;
	                    
	                    case 0x0E:				//Placa
	                      	set_imagen(1,6);	//digite placa
							flujo_LCD=10;		//Caso 10
							teclas1=0;
							Buffer_LCD1.CompTeclado=6;
							LCD_1_ClearRxBuffer();
	                    break;

	                    case 0x47:				//iButton
	                    	set_imagen(1,9);	//esperando id
							flujo_LCD=16;		//Caso 16
							Buffer_LCD1.CompID=1;
							LCD_1_ClearRxBuffer();
	                    break;
						
						case 0x48:				//N° Fuel Control
	                    	set_imagen(1,37);	//digite numero copias
							flujo_LCD=12;		//Caso 12
							teclas1=0;
							Buffer_LCD1.CompTeclado=5;
							LCD_1_ClearRxBuffer();
	                    break;
						
						case 0x49:				//RF ID
	                    	set_imagen(1,66);	//esperando rfid
							flujo_LCD=17;		//Caso 17
							Buffer_LCD1.CompID=2;
							write_psoc1(3,0);//Activo Lectura de Tarjeta
							LCD_1_ClearRxBuffer();
	                    break;
                            
                        case 0x4A:				//Pistola codigo de barras
                            Pistola_ClearRxBuffer();
	                      	set_imagen(1,1);//codigo de barras
							flujo_LCD=45;
                            Buffer_LCD1.CompID=3;
							LCD_1_ClearRxBuffer();
	                    break;
						
	                    case 0x0D:				//Atras
						  	flujo_LCD=4;		//Caso 4
							set_imagen(1,25);	//contado contado control credito
							LCD_1_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_1_ClearRxBuffer();
	        }
		break;
	
		case 16://Lectura de Ibutton
			if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					if(LCD_1_rxBuffer[3]==0x0D){//Atras
						if(Buffer_LCD1.CompID==1){
							flujo_LCD=15;		//Caso 15 
							set_imagen(1,52);	//METODO ID1a
							Buffer_LCD1.CompID=0;
						}else if(Buffer_LCD1.CompID==22){
							flujo_LCD=36;		//Caso 36 
							set_imagen(1,52);	//METODO ID1a
							Buffer_LCD1.CompID=0;
						}
					}
				}
				CyDelay(20);            
	            LCD_1_ClearRxBuffer();
			}
			if(touch_present(1)==1){
				if(touch_write(1,0x33)){
					for(z=1;z<=8;z++){
						Buffer_LCD1.id[z]=touch_read_byte(1);
					}
					Checkibutton1=0;
					for(z=1;z<8;z++){
                        Checkibutton1=crc_check(Checkibutton1,Buffer_LCD1.id[z]);
                    }
					if(Checkibutton1==Buffer_LCD1.id[8]){
						Buffer_LCD1.id[0]=8;
						Buffer_LCD1.IdentCliente[0]=17;
						Buffer_LCD1.IdentCliente[1]='I';
						j=2;
						for(i=Buffer_LCD1.id[0];i>0;i--){
							if(((Buffer_LCD1.id[i]>>4)&0x0F)>=10){
								Buffer_LCD1.IdentCliente[j]=((Buffer_LCD1.id[i]>>4)&0x0F)+55;
								j++;
							}
							else{
								Buffer_LCD1.IdentCliente[j]=((Buffer_LCD1.id[i]>>4)&0x0F)+48;
								j++;				
							}
							if((Buffer_LCD1.id[i]&0x0F)>=10){
								Buffer_LCD1.IdentCliente[j]=(Buffer_LCD1.id[i]&0x0F)+55;
								j++;
							}
							else{
								Buffer_LCD1.IdentCliente[j]=(Buffer_LCD1.id[i]&0x0F)+48;
								j++;				
							}
						}
						if(Buffer_LCD1.CompID==1){
							Buffer_LCD1.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control o credito
							Buffer_LCD1.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
							set_imagen(1,8);	//esperando 1
							flujo_LCD=18;	//Caso 18
							Buffer_LCD1.CompID=0;
							isr_3_StartEx(animacion); 
				         	Timer_Animacion_Start();
				         	count_protector=0;
						}else if(Buffer_LCD1.CompID==22){
							Buffer_LCD1.Estado_Mux=0xF7;//Autorizacion para Venta Canastilla credito
							Buffer_LCD1.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
							set_imagen(1,8);	//esperando 1
							flujo_LCD=37;	//Caso 37
							Buffer_LCD1.CompID=0;
							isr_3_StartEx(animacion); 
				         	Timer_Animacion_Start();
				         	count_protector=0;
						}
					}
				}
			}
		break;
			
		case 17://Lectura de Tarjeta RFID
			if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					if(LCD_1_rxBuffer[3]==0x0D){//Atras
						if(Buffer_LCD1.CompID==2){
							flujo_LCD=15;		//Caso 15 
							write_psoc1(3,1);//Cancelo Lectura de Tarjeta
							set_imagen(1,52);	//METODO ID1a
							Buffer_LCD1.CompID=0;
						}else if(Buffer_LCD1.CompID==24){//Canastilla credito
							flujo_LCD=36;		//Caso 36 
							write_psoc1(3,1);//Cancelo Lectura de Tarjeta
							set_imagen(1,52);	//METODO ID1a
							Buffer_LCD1.CompID=0;
						}
					}
				}
				CyDelay(20);            
	            LCD_1_ClearRxBuffer();
			}
			if(read_psoc1()==1){
				for(i=1;i<=10;i++){
					Buffer_LCD1.id[i]=buffer_i2c[i];
				}
				Buffer_LCD1.id[0]=10;
				Buffer_LCD1.IdentCliente[0]=Buffer_LCD1.id[0]+1;
				Buffer_LCD1.IdentCliente[1]='T';
				for(i=0;i<=Buffer_LCD1.id[0];i++){
					Buffer_LCD1.IdentCliente[i+2]=Buffer_LCD1.id[i+1];
				}
				if(Buffer_LCD1.CompID==2){
					Buffer_LCD1.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control o credito
					Buffer_LCD1.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
					set_imagen(1,8);	//esperando 1
					flujo_LCD=18;	//Caso 18
					Buffer_LCD1.CompID=0;
					isr_3_StartEx(animacion); 
		         	Timer_Animacion_Start();
		         	count_protector=0;
				}else if(Buffer_LCD1.CompID==24){//Canastilla credito
					Buffer_LCD1.Estado_Mux=0xF7;//Autorizacion para Venta credito canastilla
					Buffer_LCD1.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
					set_imagen(1,8);	//esperando 1
					flujo_LCD=37;	//Caso 37
					Buffer_LCD1.CompID=0;
					isr_3_StartEx(animacion); 
		         	Timer_Animacion_Start();
		         	count_protector=0;
				}
			}
		break;
			
		case 18://Esperando Autorizacion para venta de Contado Control o Credito
			if(Buffer_LCD1.AutorizacionControl==0x01){//Autorizado
				set_imagen(1,11);//SUMINISTRO AUTORIZADO con mensaje
				publicarmensaje(1);
				flujo_LCD=19;//caso 19
				programarPPUID(1);//Se programa de una vez los PPU
				Buffer_LCD1.AutorizacionTrasCali=0x02;//Para evitar conflictos con las autorizaciones de Traslados o Calibracion
				Buffer_LCD1.Estado_Mux=0xA7;//Ya que se realizo la validacion, se deja en espera de una venta por contado control autorizada
				count_protector=0;
			}else if(Buffer_LCD1.AutorizacionControl==0x00){//No Autorizado
				set_imagen(1,62);//SUMINISTRO NO AUTORIZADO1a
				publicarmensaje(1);
				flujo_LCD=20;//caso 20
				Buffer_LCD1.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en modo espera Normal
				Buffer_LCD1.AutorizacionControl=0x02;//Para evitar conflictos mas adelante
				count_protector=0;
			}
			if(count_protector>=60){
                if(count_rf>5){
                    set_imagen(1,35);	//Sin sistema parcial
                }else{
                    set_imagen(1,27);	//Sin sistema total
                }
	            flujo_LCD=100; 
			    count_protector=0;
				Buffer_LCD1.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD1.AutorizacionControl=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
			
		case 19://Suministro autorizado
			if(LCD_1_GetRxBufferSize()==8){	
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                if(LCD_1_rxBuffer[3]==0x0D){//Atras
						Buffer_LCD1.Estado_Mux=0xA2;//Ya que se realizo la validacion y se cancelo antes de subir la manija, se deja en modo cancelo para esperar a resetear al estado espera A1
						programarPPUContado(1);//Se vuelve a programar el PPU con el original
						set_imagen(1,3);	//cancelada por pc
	            		flujo_LCD=100; 
			    		count_protector=0;
					}
				}
				CyDelay(20);
	            LCD_1_ClearRxBuffer();
			}
			if(count_protector>=5){
				if(Buffer_LCD1.AutorizacionControl==0x01){
					if(Buffer_LCD1.PresetAutControl=='D'){
						set_imagen(1,29);//dinero full1a
						flujo_LCD=21;//caso 21
						count_protector=0;
					}else if(Buffer_LCD1.PresetAutControl=='V'){
						set_imagen(1,36);//volumen full
						flujo_LCD=21;//caso 21
						count_protector=0;
					}
				}else if(Buffer_LCD1.AutorizacionTrasCali==0x01){
					Buffer_LCD1.preset&=0xFC;
					if(Buffer_LCD1.PresetAutControl=='D'){
						Buffer_LCD1.preset|=2;
					}else if(Buffer_LCD1.PresetAutControl=='V'){
						Buffer_LCD1.preset|=1;
					}
					for(i=0;i<=Buffer_LCD1.ValorTanqueoControl[0];i++){
						Buffer_LCD1.valor[i]=Buffer_LCD1.ValorTanqueoControl[i];
						Buffer_LCD1.ValorPreset[i]=Buffer_LCD1.ValorTanqueoControl[i];
					}
					flujo_LCD=24;      	//Caso 24
                	set_imagen(1,63);	//SUBA la manija
					Buffer_LCD1.PresetProgramado='F';
				}
		 	}
		break;
		
		case 20://Suministro NO autorizado
			if(LCD_1_GetRxBufferSize()==8){	
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                if(LCD_1_rxBuffer[3]==0x0D){//Atras
						set_imagen(1,10);	//gracias
	            		flujo_LCD=100; 
			    		count_protector=0;
					}
				}
				CyDelay(20);
	            LCD_1_ClearRxBuffer();
			}
			if(count_protector>=15){
	            set_imagen(1,10);	//gracias
	            flujo_LCD=100; 
			    count_protector=0;
		 	}
		break;
			
		case 21://Seleccion de venta en dinero, volumen o full
			if(LCD_1_GetRxBufferSize()==8){	
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					Buffer_LCD1.preset&=0xFC;
					switch(LCD_1_rxBuffer[3]){
						case 0x15:				//Dinero
							set_imagen(1,15);	//Intro Valor
							flujo_LCD=23;		//Case 23
							teclas1=0;                            	 //Inicia el contador de teclas  
							write_LCD(1,'$',0,0x37,0x00,0x40,0x00);
					  		Buffer_LCD1.preset|=2;
							Buffer_LCD1.PresetProgramado='D';
	                    break;
							
						case 0x16:				//Volumen
							set_imagen(1,13);	//intro galones1
							flujo_LCD=23;       //Caso 23         
		                    teclas1=0;			//Inicia el contador de teclas
		                    comas1=0;
		                    write_LCD(1,'G',0,0x37,0x00,0x40,0x00);
							Buffer_LCD1.preset|=1;
							Buffer_LCD1.PresetProgramado='V';
	                    break;
							
						case 0x3C:				//Full
							if(Buffer_LCD1.FullAutControl=='F'){
								if(Buffer_LCD1.PresetAutControl=='D'){
									Buffer_LCD1.preset|=2;
								}else if(Buffer_LCD1.PresetAutControl=='V'){
									Buffer_LCD1.preset|=1;
								}
								for(i=0;i<=Buffer_LCD1.ValorTanqueoControl[0];i++){
									Buffer_LCD1.valor[i]=Buffer_LCD1.ValorTanqueoControl[i];
									Buffer_LCD1.ValorPreset[i]=Buffer_LCD1.ValorTanqueoControl[i];
								}
								flujo_LCD=24;      	//Caso 24
	                        	set_imagen(1,63);	//SUBA la manija
								Buffer_LCD1.PresetProgramado='F';
							}else if(Buffer_LCD1.FullAutControl==0x00){
								flujo_LCD=22;      	//Caso 22
								set_imagen(1,65);//excesos de cupo
								count_protector=0;
							}
	                    break;
							
						case 0x0D:				//Atras
							set_imagen(1,11);//SUMINISTRO AUTORIZADO con mensaje
							publicarmensaje(1);
							flujo_LCD=19;//caso 19
							Buffer_LCD1.Estado_Mux=0xA7;//Ya que se realizo la validacion, se deja en modo espera por Contado Control
							count_protector=0;
	                    break;
					}
				}
	            CyDelay(20);
	            LCD_1_ClearRxBuffer();
			}
		break;
		
		case 22://Full no autorizado
			if(LCD_1_GetRxBufferSize()==8){	
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                if(LCD_1_rxBuffer[3]==0x0D){//Atras
						if(Buffer_LCD1.PresetAutControl=='D'){
							set_imagen(1,29);//dinero full1a
							flujo_LCD=21;//caso 21
							count_protector=0;
						}else if(Buffer_LCD1.PresetAutControl=='V'){
							set_imagen(1,36);//volumen full
							flujo_LCD=21;//caso 21
							count_protector=0;
						}
					}
				}
				CyDelay(20);
	            LCD_1_ClearRxBuffer();
			}
			if(count_protector>=10){
				if(Buffer_LCD1.PresetAutControl=='D'){
					set_imagen(1,29);//dinero full1a
					flujo_LCD=21;//caso 21
					count_protector=0;
				}else if(Buffer_LCD1.PresetAutControl=='V'){
					set_imagen(1,36);//volumen full
					flujo_LCD=21;//caso 21
					count_protector=0;
				}
		 	}
		break;

		case 23://Digite valor a tanquear para Credito y Contado Control
			if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                if(teclas1<=(lado.c.versdig-1)){
	                    if(LCD_1_rxBuffer[3]<=9){
	                        teclas1++;
	                        Buffer_LCD1.valor[teclas1]=LCD_1_rxBuffer[3]+0x30;
							Buffer_LCD1.ValorPreset[teclas1]=LCD_1_rxBuffer[3]+0x30;
	                        write_LCD(1,(LCD_1_rxBuffer[3]+0x30),teclas1,0x37,0x00,0x40,0x00);
	                    }
	                    if(LCD_1_rxBuffer[3]==0x0A){            	//Comando de 0
	                        teclas1++;
	                        Buffer_LCD1.valor[teclas1]=0x30;
							Buffer_LCD1.ValorPreset[teclas1]=0x30;
	                        write_LCD(1,0x30,teclas1,0x37,0x00,0x40,0x00);
	                    }  
	                    if(LCD_1_rxBuffer[3]==0x4E){            	//Comando de Coma
	                        if(teclas1>=1 && comas1==0){
	                            teclas1++;
	                            Buffer_LCD1.valor[teclas1]=0x2C;
								Buffer_LCD1.ValorPreset[teclas1]=0x2C;
	                            write_LCD(1,0x2C,teclas1,0x37,0x00,0x40,0x00);
	                            comas1=1;
	                        }
	                    }
	                }
	                if(LCD_1_rxBuffer[3]==0x0B){					//DEL
	                    if(teclas1==0){								//Si no ha presionado nada regresa al menu anterior
							if(Buffer_LCD1.PresetAutControl=='D'){
								set_imagen(1,29);//dinero full1a
								flujo_LCD=21;//caso 21
								count_protector=0;
							}else if(Buffer_LCD1.PresetAutControl=='V'){
								set_imagen(1,36);//volumen full
								flujo_LCD=21;//caso 21
								count_protector=0;
							}
	                    }
	                    else{
	                        write_LCD(1,0x20,(teclas1),0x37,0x00,0x40,0x00);			//Si ya presiono borra el dato	
	                        if(Buffer_LCD1.valor[teclas1]==0x2C){
	                            comas1=0;
	                        }
	                        teclas1--;
	                    }
	                }
	                if(LCD_1_rxBuffer[3]==0x0C){					//ENT
	                    if(teclas1>=1){	
							Buffer_LCD1.valor[0]=teclas1;
							Buffer_LCD1.ValorPreset[0]=teclas1;
							if(Buffer_LCD1.PresetProgramado=='D'){
								Buffer_LCD1.preset_entero=0;
								Buffer_LCD1.max_din=0;
								for(x=Buffer_LCD1.valor[0];x>=1;x--){
									Buffer_LCD1.preset_entero+=((uint32)(Buffer_LCD1.valor[x]&0x0f)*pow(10,(Buffer_LCD1.valor[0]-x)));
								}
								for(x=Buffer_LCD1.ValorTanqueoControl[0];x>=1;x--){
									Buffer_LCD1.max_din+=((uint32)(Buffer_LCD1.ValorTanqueoControl[x]&0x0f)*pow(10,(Buffer_LCD1.ValorTanqueoControl[0]-x)));
								}
								if(Buffer_LCD1.preset_entero<=Buffer_LCD1.max_din){
									for(i=0;i<=Buffer_LCD1.ValorPreset[0];i++){
										Buffer_LCD1.valor[i]=Buffer_LCD1.ValorPreset[i];
									}
									flujo_LCD=24;      	//Caso 24
		                        	set_imagen(1,63);	//SUBA la manija
								}else{
									set_imagen(1,65);//excesos de cupo
									CyDelay(400);
									set_imagen(1,15);	//Intro Valor
									teclas1=0;                            	 //Inicia el contador de teclas  
									write_LCD(1,'$',0,0x37,0x00,0x40,0x00);
							  		Buffer_LCD1.preset|=2;
									Buffer_LCD1.PresetProgramado='D';
								}
							}else if(Buffer_LCD1.PresetProgramado=='V'){
								Buffer_LCD1.preset_entero=0;
								Buffer_LCD1.max_volu=0;
								w=Buffer_LCD1.valor[0];
								for(x=Buffer_LCD1.valor[0];x>=1;x--){
									if(Buffer_LCD1.valor[x]!=0x2C){
										Buffer_LCD1.preset_entero+=((float)(Buffer_LCD1.valor[x]&0x0f)*pow(10,(w-x)));
									}else{
										if(Buffer_LCD1.preset_entero<10){
											Buffer_LCD1.preset_entero = Buffer_LCD1.preset_entero/10;
											w=w-2;
										}else if(Buffer_LCD1.preset_entero<100){
											Buffer_LCD1.preset_entero = Buffer_LCD1.preset_entero/100;
											w=w-3;
										}else if(Buffer_LCD1.preset_entero<1000){
											Buffer_LCD1.preset_entero = Buffer_LCD1.preset_entero/1000;
											w=w-4;
										}
									}
								}
								w=Buffer_LCD1.ValorTanqueoControl[0];
								for(x=Buffer_LCD1.ValorTanqueoControl[0];x>=1;x--){
									if(Buffer_LCD1.ValorTanqueoControl[x]!=0x2C){
										Buffer_LCD1.max_volu+=((float)(Buffer_LCD1.ValorTanqueoControl[x]&0x0f)*pow(10,(w-x)));
									}else{
										Buffer_LCD1.max_volu = Buffer_LCD1.max_volu/1000;
										w=w-4;
									}
								}
								if(Buffer_LCD1.preset_entero<=Buffer_LCD1.max_volu){
									for(i=0;i<=Buffer_LCD1.ValorPreset[0];i++){
										Buffer_LCD1.valor[i]=Buffer_LCD1.ValorPreset[i];
									}
									flujo_LCD=24;      	//Caso 24
		                        	set_imagen(1,63);	//SUBA la manija
								}else{
									set_imagen(1,65);//excesos de cupo
									CyDelay(400);
									set_imagen(1,13);	//intro galones1
									teclas1=0;			//Inicia el contador de teclas
				                    comas1=0;
				                    write_LCD(1,'G',0,0x37,0x00,0x40,0x00);
									Buffer_LCD1.preset|=1;
									Buffer_LCD1.PresetProgramado='V';
								}
							}
							LCD_1_ClearRxBuffer();
	                    }
	                }
					if(LCD_1_rxBuffer[3]==0x0D){//Atras
						teclas1=0;
						if(Buffer_LCD1.PresetAutControl=='D'){
							set_imagen(1,29);//dinero full1a
							flujo_LCD=21;//caso 21
							count_protector=0;
						}else if(Buffer_LCD1.PresetAutControl=='V'){
							set_imagen(1,36);//volumen full
							flujo_LCD=21;//caso 21
							count_protector=0;
						}
						LCD_1_ClearRxBuffer();	
					}
	            }
	            CyDelay(20);            
	            LCD_1_ClearRxBuffer();
	        }
		break;
			
		case 24:	//Esperando a subir la manija para programar el equipo por sistema autorizado
	        if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                if(LCD_1_rxBuffer[3]==0x0D){//Cancel
						if(Buffer_LCD1.Estado_Mux==0xA7){//Si estaba en espera de una venta por contado control, credito, calibracion o traslados
							programarPPUContado(1);
							Buffer_LCD1.BanPPUid=0;
							Buffer_LCD1.Estado_Mux=0xA2;//...Se cancelo la operacion antes de subir la manija
						}
						set_imagen(1,0);	//animacion0
						flujo_LCD=0;		//Caso 0
	                }	
				}
	            CyDelay(20);            
	            LCD_1_ClearRxBuffer();
				break;
			}
			if(get_estado(lado.a.dir)==7){//Espera a que este en listo el equipo
				Buffer_LCD1.Estado_Mux=0xA3;//Se subio la manija, despues de programar el equipo
				CyDelay(50);
				producto1=estado_ex(lado.a.dir);											//Obtiene el grado de la manguera
				if(producto1==Buffer_LCD1.NumManguera[1] || producto1==Buffer_LCD1.NumManguera[2] || producto1==Buffer_LCD1.NumManguera[3]){
					CyDelay(50);		
					if((Buffer_LCD1.preset&0x02)==0x02||(Buffer_LCD1.preset&0x01)==0x01){		//Dependiendo del preset hace la programación
						if(programar(lado.a.dir,producto1,Buffer_LCD1.valor,(Buffer_LCD1.preset&0x03))==0){
							programarPPUContado(1);
							Buffer_LCD1.Estado_Mux=0xA5;//Se cancelo la operacion despues de subir la manija
							set_imagen(1,3);	//cancelada por pc
							isr_3_StartEx(animacion);
							Timer_Animacion_Start();
							flujo_LCD=100;		//Caso 100
							count_protector=0;
							break;
						}
					}
					producto1=estado_ex(lado.a.dir);
					if(producto1!=0){
						if(get_totales(lado.a.dir)!=0){
							if(producto1==1){
								for(i=0;i<=Buffer_LCD1.TotalVolumen1[0];i++){
									Buffer_LCD1.TotalVolumenAnterior[i]=Buffer_LCD1.TotalVolumen1[i];
									Buffer_LCD1.TotalDineroAnterior[i]=Buffer_LCD1.TotalDinero1[i];
								}
							}else if(producto1==2){
								for(i=0;i<=Buffer_LCD1.TotalVolumen2[0];i++){
									Buffer_LCD1.TotalVolumenAnterior[i]=Buffer_LCD1.TotalVolumen2[i];
									Buffer_LCD1.TotalDineroAnterior[i]=Buffer_LCD1.TotalDinero2[i];
								}
							}else if(producto1==3){
								for(i=0;i<=Buffer_LCD1.TotalVolumen3[0];i++){
									Buffer_LCD1.TotalVolumenAnterior[i]=Buffer_LCD1.TotalVolumen3[i];
									Buffer_LCD1.TotalDineroAnterior[i]=Buffer_LCD1.TotalDinero3[i];
								}
							}
						}
						Surtidor_PutChar(0x10|lado.a.dir);//Autoriza el surtidor
					    flujo_LCD=25;		//Caso 25
						set_imagen(1,20);	//tanqueando
						if(leer_fecha()==1){//Lectura de Fecha Inicial
							Buffer_LCD1.FechaInicialVenta[0]=14;
							Buffer_LCD1.FechaInicialVenta[1]=0x32;
							Buffer_LCD1.FechaInicialVenta[2]=0x30;
							Buffer_LCD1.FechaInicialVenta[3]=(((rventa.fecha[2]&0xF0)>>4)+48);
							Buffer_LCD1.FechaInicialVenta[4]=((rventa.fecha[2]&0x0F)+48);
							Buffer_LCD1.FechaInicialVenta[5]=(((rventa.fecha[1]&0x10)>>4)+48);
							Buffer_LCD1.FechaInicialVenta[6]=((rventa.fecha[1]&0x0F)+48);
							Buffer_LCD1.FechaInicialVenta[7]=(((rventa.fecha[0]&0x30)>>4)+48);
							Buffer_LCD1.FechaInicialVenta[8]=((rventa.fecha[0]&0x0F)+48);
							
						}
						if(leer_hora()==1){//Lectura de Hora Inicial	
							Buffer_LCD1.FechaInicialVenta[9]=(((rventa.hora[2]&0xF0)>>4)+48);	
							Buffer_LCD1.FechaInicialVenta[10]=((rventa.hora[2]&0x0F)+48);
							Buffer_LCD1.FechaInicialVenta[11]=(((rventa.hora[1]&0xF0)>>4)+48);
							Buffer_LCD1.FechaInicialVenta[12]=((rventa.hora[1]&0x0F)+48);
							Buffer_LCD1.FechaInicialVenta[13]=(((rventa.hora[0]&0xF0)>>4)+48);
							Buffer_LCD1.FechaInicialVenta[14]=((rventa.hora[0]&0x0F)+48);
						}
						LCD_2_ClearRxBuffer();
						PC_ClearRxBuffer();
					}
				}else{
					programarPPUContado(1);
					Buffer_LCD1.Estado_Mux=0xA2;//Se cancelo la operacion despues de subir la manija
					set_imagen(1,60);	//baje la manija
					flujo_LCD=100;		//Caso 100
					count_protector=0;
					LCD_2_ClearRxBuffer();
					break;
				}
        	}
		break;
			
		case 25://Tanqueando sin datos
            switch (get_estado(lado.a.dir)){
                case 0x09://Surtiendo
                    Buffer_LCD1.Estado_Mux=0xAC;//Surtiendo Combustible
                break;
                case 0x0B://Termino venta
                    set_imagen(1,8);	//esperando 1
    				if(venta(lado.a.dir,producto1)==1){
    					programarPPUContado(1);
    					if(Buffer_LCD1.IdentCliente[1]=='I'){
    						set_imagen(1,50);	//imprimiendo 4
    						flujo_LCD=14;	//Caso 14
    						LCD_1_ClearRxBuffer();
    						isr_3_StartEx(animacion);
    						Timer_Animacion_Start();
    						count_protector=0;
    						Buffer_LCD1.Impresionmux=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD1.BanImpFin=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD1.ConfirmacionImpresion='2';
    						Buffer_LCD1.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
                            Buffer_LCD1.PlacaCliente[0]=10;//Placa Cliente
    						for(x=0;x<=Buffer_LCD1.PlacaCliente[0];x++){
                                Buffer_LCD1.placa[x]=Buffer_LCD1.PlacaCliente[x];
    						}
    					}else if(Buffer_LCD1.placa[0]==0){//No digito placa
    						set_imagen(1,6);	//digite placa
    						flujo_LCD=11;		//Caso 11
    						Buffer_LCD1.CompTeclado=8;
    						teclas1=0;
    					}else if(Buffer_LCD1.placa[0]>=1){//Si Digito Placa
    						set_imagen(1,50);	//imprimiendo 4
    						flujo_LCD=14;		//Caso 14
    						LCD_1_ClearRxBuffer();
    						isr_3_StartEx(animacion);
    						Timer_Animacion_Start();
    						count_protector=0;
    						Buffer_LCD1.ConfirmacionImpresion='2';
    						Buffer_LCD1.Impresionmux=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD1.BanImpFin=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD1.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
    					}
    				}
                break;
                case 0x0A://Termino venta
                    set_imagen(1,8);	//esperando 1
    				if(venta(lado.a.dir,producto1)==1){
    					programarPPUContado(1);
    					if(Buffer_LCD1.IdentCliente[1]=='I'){
    						set_imagen(1,50);	//imprimiendo 4
    						flujo_LCD=14;	//Caso 14
    						LCD_1_ClearRxBuffer();
    						isr_3_StartEx(animacion);
    						Timer_Animacion_Start();
    						count_protector=0;
    						Buffer_LCD1.Impresionmux=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD1.BanImpFin=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD1.ConfirmacionImpresion='2';
    						Buffer_LCD1.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
                            for(x=0;x<=Buffer_LCD1.PlacaCliente[0];x++){
                                Buffer_LCD1.placa[x]=Buffer_LCD1.PlacaCliente[x];
    						}
    					}else if(Buffer_LCD1.placa[0]==0){//No digito placa
    						set_imagen(1,6);	//digite placa
    						flujo_LCD=11;		//Caso 11
    						Buffer_LCD1.CompTeclado=8;
    						teclas1=0;
    					}else if(Buffer_LCD1.placa[0]>=1){//Si Digito Placa
    						set_imagen(1,50);	//imprimiendo 4
    						flujo_LCD=14;	//Caso 14
    						LCD_1_ClearRxBuffer();
    						isr_3_StartEx(animacion);
    						Timer_Animacion_Start();
    						count_protector=0;
    						Buffer_LCD1.Impresionmux=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD1.BanImpFin=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD1.ConfirmacionImpresion='2';
    						Buffer_LCD1.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
    					}
    				}
                break;
                case 0x06://No hizo venta
                    Buffer_LCD1.Estado_Mux=0xA4;//No se realizo venta
    				flujo_LCD=0;
    				programarPPUContado(1);
                break;
            }
		break;
			
		case 26://Esperando autorizacion para traslados o calibracion
			if(Buffer_LCD1.AutorizacionTrasCali==0x01){//Autorizado
				set_imagen(1,11);//SUMINISTRO AUTORIZADO con mensaje
				publicarmensaje(1);
				Buffer_LCD1.AutorizacionControl=0x02;//Para evitar conflictos con las autorizaciones de Credito o Contado Control
				flujo_LCD=19;//caso 19
				programarPPUID(1);//Se programa de una vez los PPU
				Buffer_LCD1.Estado_Mux=0xA7;//Ya que se realizo la validacion, se deja en espera de una venta por contado control, credito, Calibracion o traslados autorizada
				count_protector=0;
			}else if(Buffer_LCD1.AutorizacionTrasCali==0x00){//No Autorizado
				set_imagen(1,62);//SUMINISTRO NO AUTORIZADO1a
				publicarmensaje(1);
				flujo_LCD=20;//caso 20
				Buffer_LCD1.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en modo espera Normal
				Buffer_LCD1.AutorizacionTrasCali=0x02;//Para evitar conflictos mas adelante
				count_protector=0;
			}
			if(count_protector>=60){
                if(count_rf>5){
                    set_imagen(1,35);	//Sin sistema parcial
                }else{
                    set_imagen(1,27);	//Sin sistema total
                }
	            flujo_LCD=100; 
			    count_protector=0;
				Buffer_LCD1.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD1.AutorizacionTrasCali=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
			
		case 27://Menu para Turnos
			if(LCD_1_GetRxBufferSize()==8){	 
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                switch(LCD_1_rxBuffer[3]){
	                    case 0x35:					//Apertura
							if(lado.d.turno==0 && Buffer_LCD2.Estado_Mux!=0xE1){//Solo si esta cerrado el turno y no estan abriendo por la otra posicion
								flujo_LCD=28;		//Caso 28
								resetvariables(1);
								set_imagen(1,58);	//ID Turno
								write_psoc1(3,0);//Activo Lectura de Tarjeta
								LCD_1_ClearRxBuffer();
							}
	                    break;
							
						case 0x36:				//Cierre
							if(lado.d.turno==1 && Buffer_LCD2.Estado_Mux!=0xA3 && Buffer_LCD2.Estado_Mux!=0xAC && Buffer_LCD2.Estado_Mux!=0xE2){		//Solo si esta abierto el turno
								flujo_LCD=32;		//Caso 32
								resetvariables(1);
								set_imagen(1,38);	//Confirmar Turno Sin sistema
								LCD_1_ClearRxBuffer();
							}
	                    break;
						
						case 0x41:				//Arqueo
							if(lado.d.turno==1 && Buffer_LCD2.Estado_Mux!=0xA3 && Buffer_LCD2.Estado_Mux!=0xAC){		//Solo si esta abierto el turno
								print_arqueo(print1[1]);
								count_protector=41;
								set_imagen(1,17);	//momento de corte
								flujo_LCD=34;		//Caso 34
								LCD_1_ClearRxBuffer();
								PC_ClearRxBuffer();
							}
	                    break;
						
						case 0x0D:				//Atras 
						  	flujo_LCD=3;		//Caso 3
							set_imagen(1,51);	//menu distracom 1a
							LCD_1_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_1_ClearRxBuffer();
	        }
		break;
			
		case 28://Esperando ID del Vendedor para apertura de turno
			if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					 switch(LCD_1_rxBuffer[3]){
	                    case 0x10:				//Cedula
							flujo_LCD=12;		//Caso 12
							teclas1=0;
							Buffer_LCD1.CompTeclado=7;
							set_imagen(1,68);	//digitenitcc
						break;
							
						case 0x0D:				//Atras
							flujo_LCD=27;		//Caso 27 
							write_psoc1(3,1);	//Cancelo Lectura de Tarjeta
							set_imagen(1,22);	//APERTURA CIERRE ARQUEO1a
						break;
					}
				}
				CyDelay(20);            
	            LCD_1_ClearRxBuffer();
			}
			if(read_psoc1()==1){
				set_imagen(1,8);	//esperando 1
				for(i=1;i<=10;i++){
					Buffer_LCD1.id[i]=buffer_i2c[i];
				}
				Buffer_LCD1.id[0]=10;
				IdentVendedor[0]=Buffer_LCD1.id[0]+1;
				IdentVendedor[1]='T';
				for(i=0;i<=Buffer_LCD1.id[0];i++){
					IdentVendedor[i+2]=Buffer_LCD1.id[i+1];
				}
				flujo_LCD=29;	//Caso 29
			}
			if(touch_present(1)==1){
				if(touch_write(1,0x33)){
					for(z=1;z<=8;z++){
						Buffer_LCD1.id[z]=touch_read_byte(1);
					}
					Checkibutton1=0;
					for(z=1;z<8;z++){
                        Checkibutton1=crc_check(Checkibutton1,Buffer_LCD1.id[z]);
                    }
					if(Checkibutton1==Buffer_LCD1.id[8]){
						Buffer_LCD1.id[0]=8;
						IdentVendedor[0]=17;
						IdentVendedor[1]='I';
						j=2;
						for(i=Buffer_LCD1.id[0];i>0;i--){
							if(((Buffer_LCD1.id[i]>>4)&0x0F)>=10){
								IdentVendedor[j]=((Buffer_LCD1.id[i]>>4)&0x0F)+55;
								j++;
							}
							else{
								IdentVendedor[j]=((Buffer_LCD1.id[i]>>4)&0x0F)+48;
								j++;				
							}
							if((Buffer_LCD1.id[i]&0x0F)>=10){
								IdentVendedor[j]=(Buffer_LCD1.id[i]&0x0F)+55;
								j++;
							}
							else{
								IdentVendedor[j]=(Buffer_LCD1.id[i]&0x0F)+48;
								j++;				
							}
						}
						set_imagen(1,8);	//esperando 1
						flujo_LCD=29;	//Caso 29
					}
				}
			}
		break;
			
		case 29://Recopilando datos para apertura de turno
            write_eeprom(258,IdentVendedor);//Guarga ID del Vendedor
			DatosTurno();
			write_psoc1(3,1);	//Cancelo Lectura de Tarjeta
			Buffer_LCD1.Estado_Mux=0xE1;//Autorizacion para Apertura de Turno
			flujo_LCD=30;	//Caso 30
			isr_3_StartEx(animacion); 
         	Timer_Animacion_Start();
         	count_protector=0;
			Buffer_LCD1.AutorizacionApertTurno=0x02;
			PC_ClearRxBuffer();
            count_rf=0;
            Buffer_LCD1.recepcionrf=0;
		break;
			
		case 30://Esperando Autorizacion para Apertura de Turno
            if(count_rf>=20 && Buffer_LCD1.recepcionrf==0){//Si no hay recepcion del RF no se puede abrir el turno
                flujo_LCD=100;//caso 100
    			count_protector=0;
                set_imagen(1,35);//Sin sistema total
                Buffer_LCD1.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD1.AutorizacionApertTurno=0x02;//Para evitar conflictos al hacer una nueva validacion
                break;
            }
			if(Buffer_LCD1.AutorizacionApertTurno==0x01){//Autorizado
				AbrirTurno();
				set_imagen(1,55);//TURNO ABIERTO
				Buffer_LCD1.AutorizacionApertTurno=0x02;//Para evitar conflictos con las autorizaciones de Credito o Contado Control
				Buffer_LCD1.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en espera
				flujo_LCD=100;//caso 100
				count_protector=0;
			}else if(Buffer_LCD1.AutorizacionApertTurno==0x00){//No Autorizado
				set_imagen(1,62);//SUMINISTRO NO AUTORIZADO1a
				publicarmensaje(1);
				flujo_LCD=20;//caso 20
				Buffer_LCD1.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en modo espera Normal
				Buffer_LCD1.AutorizacionApertTurno=0x02;//Para evitar conflictos mas adelante
				count_protector=0;
			}
			if(count_protector>=60){
	            flujo_LCD=31;
				Buffer_LCD1.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD1.AutorizacionApertTurno=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
			
		case 31://Abrir turno sin sistema
			NombreVendedor[0]=20;
			for(x=0;x<=19;x++){
				NombreVendedor[x+1]=msn_Vendedor[x];
			}
            CedulaVendedor[0]=IdentVendedor[0]-1;
            if(CedulaVendedor[0]>10){
                CedulaVendedor[0]=10;
            }
            for(x=1;x<=CedulaVendedor[0];x++){
			    CedulaVendedor[x]=IdentVendedor[x+1];
		    }
			AbrirTurno();
	        set_imagen(1,40);	//Turno abierto sin sistema
			flujo_LCD=100;//caso 100
			count_protector=0;
			PC_ClearRxBuffer();
		break;
			
		case 32://Confirmacion para cierre de Turno
			if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					 switch(LCD_1_rxBuffer[3]){
	                    case 0x13:				//SI
							set_imagen(1,8);	//esperando 1
							DatosTurno();
							flujo_LCD=33;		//Caso 33
							for(x=0;x<=FechaInicialTurno[0];x++){
								FechaFinalTurno[x]=FechaInicialTurno[x];
							}
							isr_3_StartEx(animacion);
				         	Timer_Animacion_Start();
				         	count_protector=0;
							Buffer_LCD1.Estado_Mux=0xE2;//Autorizacion para cierre de Turno
							Buffer_LCD1.BanImpFin=0x02;//Para evitar conflictos mas adelante
							Buffer_LCD1.AutorizacionCierreTurno=0x02;//Para evitar conflictos mas adelante
							PC_ClearRxBuffer();
                            count_rf=0;
                            Buffer_LCD1.recepcionrf=0;
						break;
						
						case 0x14:				//NO
							flujo_LCD=0;		//Caso 0
							set_imagen(1,30);	//animacion1
						break;
							
						case 0x0D:				//Atras
							flujo_LCD=0;		//Caso 0
							set_imagen(1,30);	//animacion1
						break;
					}
				}
				CyDelay(20);            
	            LCD_1_ClearRxBuffer();
			}
		break;
			
		case 33://Esperando Autorizacion para Cierre de Turno
            if(count_rf>=20 && Buffer_LCD1.recepcionrf==0){//Si no hay recepcion del RF no se puede cerrar el turno
                flujo_LCD=100;//caso 100
    			count_protector=0;
                set_imagen(1,35);//Sin sistema total
                Buffer_LCD1.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD1.AutorizacionApertTurno=0x02;//Para evitar conflictos al hacer una nueva validacion
                break;
            }
			if(Buffer_LCD1.AutorizacionCierreTurno==0x01){//Autorizado
                IdentVendedor[0]=1;
                for(x=1;x<=19;x++){
                    IdentVendedor[x]=0;
                }
                write_eeprom(258,IdentVendedor);//Guarga ID del Vendedor seteado
				set_imagen(1,50);//imprimiendo 4
				Buffer_LCD1.AutorizacionCierreTurno=0x02;//Para evitar conflictos con las autorizaciones de Credito o Contado Control
				Buffer_LCD1.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en espera
				write_eeprom(302,FechaFinalTurno);//Guarga la fecha de cierre
				CerrarTurno[0]=1;
				CerrarTurno[1]=0;
				lado.d.turno=0;
				write_eeprom(256,CerrarTurno);//Guarga que el turno esta cerrado
				flujo_LCD=34;//caso 34
				count_protector=0;
			}else if(Buffer_LCD1.AutorizacionCierreTurno==0x00){//No Autorizado
				set_imagen(1,62);//SUMINISTRO NO AUTORIZADO1a
				publicarmensaje(1);
				flujo_LCD=20;//caso 20
				Buffer_LCD1.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en modo espera Normal
				Buffer_LCD1.AutorizacionCierreTurno=0x02;//Para evitar conflictos mas adelante
				count_protector=0;
			}
			if(count_protector>=60){
                IdentVendedor[0]=1;
                for(x=1;x<=19;x++){
                    IdentVendedor[x]=0;
                }
                write_eeprom(258,IdentVendedor);//Guarga ID del Vendedor seteado
	            set_imagen(1,50);	//imprimiendo 4
	            flujo_LCD=34;
				Buffer_LCD1.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				write_eeprom(302,FechaFinalTurno);//Guarga la fecha de cierre
				CerrarTurno[0]=1;
				CerrarTurno[1]=0;
				lado.d.turno=0;
				write_eeprom(256,CerrarTurno);//Guarga que el turno esta cerrado
				Buffer_LCD1.AutorizacionCierreTurno=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
			
		case 34://Esperando trama de impresion para cierre de turno8
			if(count_protector>=40){//Si no llega nada imprime un Corte predeterminado
				print_logo(print1[1]);
				imprimir_corte(print1[1]);
				set_imagen(1,10);	//gracias
	            flujo_LCD=0; 
			    count_protector=0;
			}else if(Buffer_LCD1.BanImpFin==0x01){//Cuando finaliza la trama de impresion por sistema
				set_imagen(1,10);	//gracias
	            flujo_LCD=0; 
			    count_protector=0;
			}
		break;
			
		case 35://Menu de canastilla
			if(LCD_1_GetRxBufferSize()==8){	 
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                switch(LCD_1_rxBuffer[3]){
	                    case 0x39:				//Credito
							set_imagen(1,52);	//METODO ID
							resetvariables(1);
							resetvariableslcd(1);
							flujo_LCD=36;		//Caso 36
							Buffer_LCD1.TipodeVentaCanasta='1';
							Buffer_LCD1.BandAutorCredCanasta=1;//Para en caso de reconocer productos no afecte el estado del mux
	                    break;                
	                    
						case 0x37:				//Efectivo
							resetvariables(1);
							resetvariableslcd(1);
							set_imagen(1,69);	//Canastilla
							LCD_Canastilla(1);
							flujo_LCD=39;		//Caso 39
							Buffer_LCD1.TipodeVentaCanasta='0';
							Buffer_LCD1.BandAutorCredCanasta=0;//Para en caso de reconocer productos no afecte el estado del mux
	                    break;
						
						case 0x0D:				//Atras 
							set_imagen(1,51);	//menu distracom 1a 
						  	flujo_LCD=3;		//Caso 3
							LCD_1_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_1_ClearRxBuffer();
	        }
			for(x=0;x<10;x++){                   
				Buffer_LCD1.ValorCupoCanasta[x]=0;	//Borro variable credito
			}
		break;
			
		case 36://Venta Canastilla de Credito
			if(LCD_1_GetRxBufferSize()==8){	
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                switch(LCD_1_rxBuffer[3]){
	                    case 0x45:				//CC/NIT
							set_imagen(1,68);	//digitenitcc
							flujo_LCD=12;		//Caso 12
							teclas1=0;
							Buffer_LCD1.CompTeclado=20;
	                    break;
	                    
	                    case 0x0E:				//Placa
	                      	set_imagen(1,6);	//digite placa
							flujo_LCD=10;		//Caso 10
							teclas1=0;
							Buffer_LCD1.CompTeclado=21;
	                    break;

	                    case 0x47:				//iButton
	                    	set_imagen(1,9);	//esperando id
							flujo_LCD=16;		//Caso 16
							Buffer_LCD1.CompID=22;
	                    break;
						
						case 0x48:				//N° Fuel Control
	                    	set_imagen(1,37);	//digite numero copias
							flujo_LCD=12;		//Caso 12
							teclas1=0;
							Buffer_LCD1.CompTeclado=23;
	                    break;
						
						case 0x49:				//RF ID
	                    	set_imagen(1,66);	//esperando rfid
							flujo_LCD=17;		//Caso 17
							Buffer_LCD1.CompID=24;
							write_psoc1(3,0);//Activo Lectura de Tarjeta
	                    break;
                            
                        case 0x4A:				//Pistola codigo de barras
                            Pistola_ClearRxBuffer();
	                      	set_imagen(1,1);//codigo de barras
							flujo_LCD=45;
                            Buffer_LCD1.CompID=25;
	                    break;
						
	                    case 0x0D:				//Atras
						  	flujo_LCD=35;		//Caso 35
							set_imagen(1,71);	//CONTADO CREDITO
							LCD_1_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_1_ClearRxBuffer();
	        }
			Buffer_LCD1.KmID[0]=1;
			Buffer_LCD1.KmID[1]='0';
		break;
			
		case 37://Esperando Autorizacion para Venta de Canastilla en Credito
			if(Buffer_LCD1.AutorizacionCreditoCanasta==0x01){//Autorizado
				set_imagen(1,11);//SUMINISTRO AUTORIZADO con mensaje
				publicarmensaje(1);
				flujo_LCD=38;//caso 38
				Buffer_LCD1.Estado_Mux=0xAB;//Ya que se realizo la validacion, queda en espera de una venta por canastilla crédito autorizada
				Buffer_LCD1.BandAutorCredCanasta=1;//Para en caso de reconocer productos no afecte el estado del mux
				count_protector=0;
			}else if(Buffer_LCD1.AutorizacionCreditoCanasta==0x00){//No Autorizado
				set_imagen(1,62);//SUMINISTRO NO AUTORIZADO1a
				publicarmensaje(1);
				flujo_LCD=20;//caso 20
				Buffer_LCD1.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en modo espera Normal
				Buffer_LCD1.BandAutorCredCanasta=0;//Para en caso de reconocer productos no afecte el estado del mux
				Buffer_LCD1.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos mas adelante
				count_protector=0;
			}
			if(count_protector>=60){
                if(count_rf>5){
                    set_imagen(1,35);	//Sin sistema parcial
                }else{
                    set_imagen(1,27);	//Sin sistema total
                }
	            flujo_LCD=100; 
			    count_protector=0;
				Buffer_LCD1.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD1.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
			
		case 38://Suministro autorizado de canastilla
			if(LCD_1_GetRxBufferSize()==8){	
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                if(LCD_1_rxBuffer[3]==0x0D){//Atras
						Buffer_LCD1.Estado_Mux=0xFC;//Ya que se realizo la validacion y se cancelo la operacion, se deja en modo cancelo para esperar a resetear al estado espera A1
						set_imagen(1,3);	//cancelada por pc
	            		flujo_LCD=100; 
			    		count_protector=0;
					}
				}
				CyDelay(20);
	            LCD_1_ClearRxBuffer();
			}
			if(count_protector>=5){
				set_imagen(1,69);//Canastilla
				LCD_Canastilla(1);
				flujo_LCD=39;
		 	}
		break;
			
		case 39://Formulario de Canastilla
			if(LCD_1_GetRxBufferSize()==8){	 
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                switch(LCD_1_rxBuffer[3]){
	                    case 0x19://Producto 1
							Pistola_ClearRxBuffer();
							set_imagen(1,1);//codigo de barras
							Buffer_LCD1.ProductoCanasta=1;
							flujo_LCD=40;
							for(x=0;x<=20;x++){
								Buffer_LCD1.MensajeProducto[x]=Buffer_LCD1.NombreProducto1Canasta[x];
							}
							publicmenprod(1);
	                    break;
	                    
						case 0x4F://Cant 1
							set_imagen(1,37);	//digite numero
							Buffer_LCD1.CompTeclado=31;
							flujo_LCD=12;
							teclas1=0;
	                    break;
													
						case 0x53://Cancelar 1
							Buffer_LCD1.CantProducto1Canasta[0]=0;
							Buffer_LCD1.ValorProducto1Orig=0;
							Buffer_LCD1.NombreProducto1Canasta[0]=0;
							for(i=1;i<=20;i++){//Producto1
								Buffer_LCD1.NombreProducto1Canasta[i]='-';
								Buffer_LCD1.CodigoProductoCanasta1[i]=0;
								Buffer_LCD1.CodigoProductoCanasta1[0]=0;
							}
							set_imagen(1,69);	//Canastilla
							LCD_Canastilla(1);
	                    break;
						
	                    case 0x1A://Producto 2
							Pistola_ClearRxBuffer();
							set_imagen(1,1);//codigo de barras
							Buffer_LCD1.ProductoCanasta=2;
							flujo_LCD=40;
							for(x=0;x<=20;x++){
								Buffer_LCD1.MensajeProducto[x]=Buffer_LCD1.NombreProducto2Canasta[x];
							}
							publicmenprod(1);
	                    break;
							
						case 0x50://Cant 2
	                      	set_imagen(1,37);	//digite numero
							Buffer_LCD1.CompTeclado=32;
							flujo_LCD=12;
							teclas1=0;
	                    break;
						
						case 0x54://Cancelar 2
	                      	Buffer_LCD1.CantProducto2Canasta[0]=0;
							Buffer_LCD1.ValorProducto2Orig=0;
							Buffer_LCD1.NombreProducto2Canasta[0]=0;
							for(i=1;i<=20;i++){//Producto1
								Buffer_LCD1.NombreProducto2Canasta[i]='-';
								Buffer_LCD1.CodigoProductoCanasta2[i]=0;
								Buffer_LCD1.CodigoProductoCanasta2[0]=0;
							}
							set_imagen(1,69);	//Canastilla
							LCD_Canastilla(1);
	                    break;
						
						case 0x2E://Producto 3
							Pistola_ClearRxBuffer();
	                      	set_imagen(1,1);//codigo de barras
							Buffer_LCD1.ProductoCanasta=3;
							flujo_LCD=40;
							for(x=0;x<=20;x++){
								Buffer_LCD1.MensajeProducto[x]=Buffer_LCD1.NombreProducto3Canasta[x];
							}
							publicmenprod(1);
	                    break;
						
						case 0x51://Cant 3
	                      	set_imagen(1,37);	//digite numero
							Buffer_LCD1.CompTeclado=33;
							flujo_LCD=12;
							teclas1=0;
	                    break;
						
						case 0x55://Cancelar 3
	                      	Buffer_LCD1.CantProducto3Canasta[0]=0;
							Buffer_LCD1.ValorProducto3Orig=0;
							Buffer_LCD1.NombreProducto3Canasta[0]=0;
							for(i=1;i<=20;i++){//Producto1
								Buffer_LCD1.NombreProducto3Canasta[i]='-';
								Buffer_LCD1.CodigoProductoCanasta3[i]=0;
								Buffer_LCD1.CodigoProductoCanasta3[0]=0;
							}
							set_imagen(1,69);	//Canastilla
							LCD_Canastilla(1);
	                    break;
						
						case 0x3A://Producto 4
							Pistola_ClearRxBuffer();
	                      	set_imagen(1,1);//codigo de barras
							Buffer_LCD1.ProductoCanasta=4;
							flujo_LCD=40;
							for(x=0;x<=20;x++){
								Buffer_LCD1.MensajeProducto[x]=Buffer_LCD1.NombreProducto4Canasta[x];
							}
							 publicmenprod(1);
	                    break;
						
						case 0x52://Cant 4
	                      	set_imagen(1,37);	//digite numero
							Buffer_LCD1.CompTeclado=34;
							flujo_LCD=12;
							teclas1=0;
	                    break;
						
						case 0x56://Cancelar 4
	                      	Buffer_LCD1.CantProducto4Canasta[0]=0;
							Buffer_LCD1.ValorProducto4Orig=0;
							Buffer_LCD1.NombreProducto4Canasta[0]=0;
							for(i=1;i<=20;i++){//Producto1
								Buffer_LCD1.NombreProducto4Canasta[i]='-';
								Buffer_LCD1.CodigoProductoCanasta4[i]=0;
								Buffer_LCD1.CodigoProductoCanasta4[0]=0;
							}
							set_imagen(1,69);	//Canastilla
							LCD_Canastilla(1);
	                    break;
						
						case 0x0C://Aceptar
							if(leer_fecha()==1){						//Lectura de Fecha Final
								Buffer_LCD1.FechaVentaCanastilla[0]=14;
								Buffer_LCD1.FechaVentaCanastilla[1]=0x32;
								Buffer_LCD1.FechaVentaCanastilla[2]=0x30;
								Buffer_LCD1.FechaVentaCanastilla[3]=(((rventa.fecha[2]&0xF0)>>4)+48);
								Buffer_LCD1.FechaVentaCanastilla[4]=((rventa.fecha[2]&0x0F)+48);
								Buffer_LCD1.FechaVentaCanastilla[5]=(((rventa.fecha[1]&0x10)>>4)+48);
								Buffer_LCD1.FechaVentaCanastilla[6]=((rventa.fecha[1]&0x0F)+48);
								Buffer_LCD1.FechaVentaCanastilla[7]=(((rventa.fecha[0]&0x30)>>4)+48);
								Buffer_LCD1.FechaVentaCanastilla[8]=((rventa.fecha[0]&0x0F)+48);
							}
							if(leer_hora()==1){							//Lectura de Hora Final	
								Buffer_LCD1.FechaVentaCanastilla[9]=(((rventa.hora[2]&0xF0)>>4)+48);	
								Buffer_LCD1.FechaVentaCanastilla[10]=((rventa.hora[2]&0x0F)+48);
								Buffer_LCD1.FechaVentaCanastilla[11]=(((rventa.hora[1]&0xF0)>>4)+48);
								Buffer_LCD1.FechaVentaCanastilla[12]=((rventa.hora[1]&0x0F)+48);
								Buffer_LCD1.FechaVentaCanastilla[13]=(((rventa.hora[0]&0xF0)>>4)+48);
								Buffer_LCD1.FechaVentaCanastilla[14]=((rventa.hora[0]&0x0F)+48);
							}
							if(Buffer_LCD1.TipodeVentaCanasta=='1'){
								if(Buffer_LCD1.ValorProductoTotal>0){
									if(Buffer_LCD1.ValorProductoTotal>Buffer_LCD1.ValorCupoCanastaOri){
										set_imagen(1,65);//excesos de cupo
										CyDelay(300);
										set_imagen(1,69);	//Canastilla
										LCD_Canastilla(1);
									}else{
										set_imagen(1,8);	//esperando 1
										flujo_LCD=42;
										isr_3_StartEx(animacion);
							         	Timer_Animacion_Start();
							         	count_protector=0;
										Buffer_LCD1.Estado_Mux=0xA8;//Fin de la venta de Canastilla
										Buffer_LCD1.AutorizacionVentaCanasta=0x02;//Para evitar conflictos mas adelante
									}
								}
							}else{
								if(Buffer_LCD1.ValorProductoTotal>0){
									set_imagen(1,8);	//esperando 1
									flujo_LCD=42;
									isr_3_StartEx(animacion);
						         	Timer_Animacion_Start();
						         	count_protector=0;
									Buffer_LCD1.Estado_Mux=0xA8;//Fin de la venta de Canastilla
									Buffer_LCD1.AutorizacionVentaCanasta=0x02;//Para evitar conflictos mas adelante
								}
							}
	                    break;
						
						case 0x0D://Atras
							if(Buffer_LCD1.TipodeVentaCanasta=='1'){//Credito
								set_imagen(1,11);//SUMINISTRO AUTORIZADO con mensaje
								publicarmensaje(1);
								flujo_LCD=38;//caso 38
								count_protector=0;
							}else if(Buffer_LCD1.TipodeVentaCanasta=='0'){//Efectivo
								set_imagen(1,71);	//CONTADO CREDITO
								flujo_LCD=35;//caso 35
							}
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_1_ClearRxBuffer();
	        }
		break;
			
		case 40://Lectura de codigo de barras
			if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					if(LCD_1_rxBuffer[3]==0x0D){//Atras
						set_imagen(1,69);	//Canastilla
						flujo_LCD=39;	//caso 39
						LCD_Canastilla(1);
					}
				}
				CyDelay(20);            
	            LCD_1_ClearRxBuffer();
			}
			if(codigodebarras()==1){
				if(Buffer_LCD1.ProductoCanasta==1){//Producto 1
					for(x=0;x<=Rx_Pistola[0];x++){
						Buffer_LCD1.CodigoProductoCanasta1[x]=Rx_Pistola[x];
					}
				}else if(Buffer_LCD1.ProductoCanasta==2){//Producto 2
					for(x=0;x<=Rx_Pistola[0];x++){
						Buffer_LCD1.CodigoProductoCanasta2[x]=Rx_Pistola[x];
					}
				}else if(Buffer_LCD1.ProductoCanasta==3){//Producto 3
					for(x=0;x<=Rx_Pistola[0];x++){
						Buffer_LCD1.CodigoProductoCanasta3[x]=Rx_Pistola[x];
					}
				}else if(Buffer_LCD1.ProductoCanasta==4){//Producto 4
					for(x=0;x<=Rx_Pistola[0];x++){
						Buffer_LCD1.CodigoProductoCanasta4[x]=Rx_Pistola[x];
					}
				}
				set_imagen(1,8);//esperando 1
				flujo_LCD=41;	//caso 41
				Buffer_LCD1.Estado_Mux=0xFD;//Espera reconocimiento de un producto de Canastilla
				Buffer_LCD1.ReconocimientoProducto=0x02;//Para evitar conflictos al hacer una nueva validacion
				isr_3_StartEx(animacion);
	         	Timer_Animacion_Start();
	         	count_protector=0;
			}
		break;
			
		case 41://Esperando reconocimiento de producto canastilla
			if(Buffer_LCD1.ReconocimientoProducto==0x01){//Producto reconocido
				if(Buffer_LCD1.BandAutorCredCanasta==1){
					Buffer_LCD1.Estado_Mux=0xAB;//esta en espera de una venta por Canastilla en Credito
				}else{
					Buffer_LCD1.Estado_Mux=0xA1;//esta en espera 
				}
				set_imagen(1,69);	//Canastilla
				LCD_Canastilla(1);
	            flujo_LCD=39;
				Buffer_LCD1.ReconocimientoProducto=0x02;//Para evitar conflictos al hacer una nueva validacion
			}
			if(count_protector>=40){
				if(Buffer_LCD1.BandAutorCredCanasta==1){
					Buffer_LCD1.Estado_Mux=0xAB;//esta en espera de una venta por Canastilla en Credito
				}else{
					Buffer_LCD1.Estado_Mux=0xA1;//esta en espera 
				}
	            set_imagen(1,69);	//Canastilla
				LCD_Canastilla(1);
	            flujo_LCD=39; 
			    count_protector=0;
				Buffer_LCD1.ReconocimientoProducto=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
		
		case 42://Esperando aprobacion para fin de venta de canastilla
			if(Buffer_LCD1.AutorizacionVentaCanasta==0x01){//Autorizado
				set_imagen(1,50);//imprimiendo 4
				flujo_LCD=100;//caso 38
				count_protector=0;
				Buffer_LCD1.AutorizacionVentaCanasta=0x02;
			}
			if(count_protector>=90){
	            set_imagen(1,35);	//Sin sistema total
	            flujo_LCD=100; 
			    count_protector=0;
				if(Buffer_LCD1.Estado_Mux==0xAB){
					Buffer_LCD1.Estado_Mux=0xFC;
				}else{
					Buffer_LCD1.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				}
				Buffer_LCD1.AutorizacionVentaCanasta=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
            
        case 43://Esperando impresion de ultima venta .
            if(Buffer_LCD1.impresionultimaventa==0x01){//Autorizado
				set_imagen(1,50);	//imprimiendo 4
				flujo_LCD=100; 
			    count_protector=0;
				Buffer_LCD1.Estado_Mux=0xA1;//el modulo queda en espera
                Buffer_LCD1.impresionultimaventa=0x00;
			}
			if(count_protector>=25){
	            set_imagen(1,50);	//imprimiendo 4
                if(impresion1==1){
                    print_logo(print1[1]);
    				imprimir(print1[1], producto1,0,lado.a.dir);
                    if(Buffer_LCD1.ConfirmacionImpresion=='2' && Buffer_LCD1.TipodeVenta=='0'){
                        print_logo(print1[1]);
    				    imprimir(print1[1], producto1,0,lado.a.dir);
                    }
    				if(Buffer_LCD1.TipodeVenta=='1' || Buffer_LCD1.TipodeVenta=='2'){
    					print_logo(print1[1]);
    					imprimir(print1[1], producto1,1,lado.a.dir);
    				}
                }else{
                    print_logo(print2[1]);
    				imprimir(print2[1], producto1,0,lado.a.dir);
                    if(Buffer_LCD1.ConfirmacionImpresion=='2' && Buffer_LCD1.TipodeVenta=='0'){
                        print_logo(print2[1]);
    				    imprimir(print2[1], producto1,0,lado.a.dir);
                    }
    				if(Buffer_LCD1.TipodeVenta=='1' || Buffer_LCD1.TipodeVenta=='2'){
    					print_logo(print2[1]);
    					imprimir(print2[1], producto1,1,lado.a.dir);
    				}
                }
                impresion1=0;
                set_imagen(1,10);	//gracias
	            flujo_LCD=100; 
			    count_protector=0;
				Buffer_LCD1.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
                Buffer_LCD1.impresionultimaventa=0x00;
		 	}
        break;
            
        case 44://Informacion de mux
            /*-------------HORA EN TIEMPO REAL---------------*/
            leer_hora();
            write_LCD(1,((rventa.hora[2]&0xF0)>>4)+48,1,100,1,185,0);
            write_LCD(1,(rventa.hora[2]&0x0F)+48,2,100,1,185,0);
            write_LCD(1,':',3,100,1,185,0);
            write_LCD(1,((rventa.hora[1]&0xF0)>>4)+48,4,100,1,185,0);
            write_LCD(1,(rventa.hora[1]&0x0F)+48,5,100,1,185,0);
            write_LCD(1,':',6,100,1,185,0);
            write_LCD(1,((rventa.hora[0]&0xF0)>>4)+48,1,1,2,185,0);
            write_LCD(1,(rventa.hora[0]&0x0F)+48,2,1,2,185,0);
            /*-------------HORA EN TIEMPO REAL---------------*/
            
            if(LCD_1_GetRxBufferSize()==8){	 
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
	                if(LCD_1_rxBuffer[3]==0x0D){//Atras
                        set_imagen(1,0);
                        flujo_LCD=0;		//Caso 0
						LCD_1_ClearRxBuffer();
                    }
	            }
	            CyDelay(20);
	            LCD_1_ClearRxBuffer();
	        }
        break;
            
        case 45://Lectura Codigo de Barras Cliente
            if(LCD_1_GetRxBufferSize()==8){
	            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
					if(LCD_1_rxBuffer[3]==0x0D){//Atras
                        if(Buffer_LCD1.CompID==3){
                            set_imagen(1,52);	//METODO ID
    						flujo_LCD=15;	//caso 15
                            Buffer_LCD1.CompID=0;
                        }else if(Buffer_LCD1.CompID==25){
                            set_imagen(1,52);	//METODO ID
						    flujo_LCD=36;	//caso 15
                            Buffer_LCD1.CompID=0;
                        }
					}
				}
				CyDelay(20);            
	            LCD_1_ClearRxBuffer();
			}
			if(codigodebarras()==1){
				for(x=1;x<=Rx_Pistola[0];x++){
					Buffer_LCD1.IdentCliente[x+1]=Rx_Pistola[x];
				}
                Buffer_LCD1.IdentCliente[0]=Rx_Pistola[0]+1;
                Buffer_LCD1.IdentCliente[1]='B';
                if(Buffer_LCD1.CompID==3){
    				Buffer_LCD1.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control o credito
    				Buffer_LCD1.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
    				set_imagen(1,8);	//esperando 1
    				flujo_LCD=18;	//Caso 18
    				Buffer_LCD1.CompID=0;
    				isr_3_StartEx(animacion); 
    	         	Timer_Animacion_Start();
    	         	count_protector=0;
                }else if(Buffer_LCD1.CompID==25){
                    Buffer_LCD1.Estado_Mux=0xF7;//Autorizacion para Venta Canastilla credito
                    Buffer_LCD1.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
					set_imagen(1,8);	//esperando 1
					flujo_LCD=37;	//Caso 37
					Buffer_LCD1.CompID=0;
					isr_3_StartEx(animacion); 
		         	Timer_Animacion_Start();
		         	count_protector=0;
                }
			}
        break;
	}
}

/*
*********************************************************************************************************
*                                         void polling_LCD2(void)
*
* Description : Ejecuta las diferentes funciones que se pueden realizar desde la pantalla 2
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void polling_LCD2(void){
    uint32 i,x,z,j,w;
 	switch(flujo_LCD2){
		case 100://Inicio de protector
	        if(count_protector2>=7){//Espera a que pasen 2.5 seg aprox e inicia la pantalla
	            flujo_LCD2=0;							 
	            isr_4_Stop(); 
	            Timer_Animacion2_Stop(); 
	            count_protector2=0;
	        }
        break;
		
		case 0:	//Protector de Pantalla
			isr_4_StartEx(animacion2);
			Timer_Animacion2_Start();
	        count_protector2=0;
	        flujo_LCD2=1;//Caso 1
		break;
		
		case 1:	//Esperando a presionar la pantalla
			if(LCD_2_GetRxBufferSize()==8){
	            flujo_LCD2=2;	//Caso 2
	            LCD_2_ClearRxBuffer(); 
	            isr_4_Stop();
	            Timer_Animacion2_Stop();			
	            set_imagen(2,51);
			}
		break;
		
		case 2://Pasa a pantalla inicial de opciones y limpia el buffer
			flujo_LCD2=3;	//Caso 3
		 	CyDelay(20);
         	LCD_2_ClearRxBuffer();
		break;
		
		case 3:	//Menu Principal
	        if(LCD_2_GetRxBufferSize()==8){	 
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                switch(LCD_2_rxBuffer[3]){
	                    case 0x3F:					//Combustibles
							if(lado.d.turno==1){//Solo si esta abierto el turno
								set_imagen(2,25);	//contado contado control credito
								flujo_LCD2=4;		//Caso 4
							}
	                    break;                
	                    
						case 0x44:				//Turno
							set_imagen(2,22);	//APERTURA CIERRE ARQUEO1a
							flujo_LCD2=27;		//Caso 27
	                    break;
													
						case 0x43:				//Calibracion
							if(lado.d.turno==1){		//Solo si esta abierto el turno
							  	set_imagen(2,8);	//esperando 1
								flujo_LCD2=26;		//Caso 26
								resetvariables(2);
								Buffer_LCD2.TipodeVenta='5';
								Buffer_LCD2.Estado_Mux=0xE6;//Calibracion
								Buffer_LCD2.AutorizacionTrasCali=0x02;//Para evitar conflictos
								isr_4_StartEx(animacion2);
								Timer_Animacion2_Start();
								count_protector2=0;
							}
	                    break;
						
	                    case 0x42:				//Traslados
							if(lado.d.turno==1){		//Solo si esta abierto el turno
							  	set_imagen(2,8);	//esperando 1
								flujo_LCD2=26;		//Caso 26
								resetvariables(2);
								Buffer_LCD2.TipodeVenta='6';
								Buffer_LCD2.Estado_Mux=0xF1;//Autorizacion para Traslados
								Buffer_LCD2.AutorizacionTrasCali=0x02;//Para evitar conflictos
								isr_4_StartEx(animacion2);
								Timer_Animacion2_Start();
								count_protector2=0;
							}
	                    break;
							
						case 0x40:				//Canastilla
							if(lado.d.turno==1){		//Solo si esta abierto el turno
		                      	set_imagen(2,71);	//CONTADO CREDITO
								flujo_LCD2=35;		//Caso 35
							}
	                    break;
						
                        case 0x58:              //P1
                            if(lado.d.turno==1 && Buffer_LCD2.P1[0]>0){
                                resetvariables(2);
                                Buffer_LCD2.preset&=0xFC;
    							Buffer_LCD2.preset|=2;
                                flujo_LCD2=7;      	//Caso 7
    	                        set_imagen(2,63);	//SUBA la manija
    							Buffer_LCD2.PresetProgramado='D';
                                Buffer_LCD2.TipodeVenta='0';
    							for(i=0;i<=Buffer_LCD2.P1[0];i++){
    								Buffer_LCD2.valor[i]=Buffer_LCD2.P1[i];
    								Buffer_LCD2.ValorPreset[i]=Buffer_LCD2.P1[i];
    							}
                            }
                        break;
                            
                        case 0x59:              //P2
                            if(lado.d.turno==1 && Buffer_LCD2.P2[0]>0){
                                resetvariables(2);
                                Buffer_LCD2.preset&=0xFC;
    							Buffer_LCD2.preset|=2;
                                flujo_LCD2=7;      	//Caso 7
    	                        set_imagen(2,63);	//SUBA la manija
    							Buffer_LCD2.PresetProgramado='D';
                                Buffer_LCD2.TipodeVenta='0';
    							for(i=0;i<=Buffer_LCD2.P2[0];i++){
    								Buffer_LCD2.valor[i]=Buffer_LCD2.P2[i];
    								Buffer_LCD2.ValorPreset[i]=Buffer_LCD2.P2[i];
    							}
                            }
                        break;
                            
                        case 0x5A:              //P3
                            if(lado.d.turno==1 && Buffer_LCD2.P3[0]>0){
                                resetvariables(2);
                                Buffer_LCD2.preset&=0xFC;
    							Buffer_LCD2.preset|=2;
                                flujo_LCD2=7;      	//Caso 7
    	                        set_imagen(2,63);	//SUBA la manija
    							Buffer_LCD2.PresetProgramado='D';
                                Buffer_LCD2.TipodeVenta='0';
    							for(i=0;i<=Buffer_LCD2.P3[0];i++){
    								Buffer_LCD2.valor[i]=Buffer_LCD2.P3[i];
    								Buffer_LCD2.ValorPreset[i]=Buffer_LCD2.P3[i];
    							}
                            }
                        break;
                        
                        case 0x5C:				//Impresion misma posicion
							if(lado.d.turno==1 && Buffer_LCD2.placa[0]>0){		//Solo si esta abierto el turno y se digito placa anteriormente
							  	set_imagen(2,8);	//esperando 1
								flujo_LCD2=43;		//Caso 43
								Buffer_LCD2.Estado_Mux=0xA9;//Impresion misma posicion
                                impresion2=1;
								isr_4_StartEx(animacion2);
								Timer_Animacion2_Start();
								count_protector2=0;
                                Buffer_LCD2.impresionultimaventa=0x02;//Para evitar conflictos
							}
	                    break;
                            
                        case 0x5B:				//Impresion otra posicion
							if(lado.d.turno==1 && Buffer_LCD2.placa[0]>0){	//Solo si esta abierto el turno y se digito placa anteriormente
							  	set_imagen(2,8);	//esperando 1
								flujo_LCD2=43;		//Caso 43
								Buffer_LCD2.Estado_Mux=0xAA;//Impresion otra posicion
                                impresion2=2;
								isr_4_StartEx(animacion2);
								Timer_Animacion2_Start();
								count_protector2=0;
                                Buffer_LCD2.impresionultimaventa=0x02;//Para evitar conflictos
							}
	                    break;
                        
                        case 0x5D:              //Informacion de Mux
                            set_imagen(2,41);     //Informacion mux
                            for(i=1;i<=10;i++){
                                write_LCD(2,DirMuxDef[i],i-2,0x37,0,55,0); 
                                write_LCD(2,versionmux[i-1],i-2,0x37,0,60,1);
                            }
                            write_LCD(2,(lado.b.dir/10)+48,3,0x37,0,185,0);
                            write_LCD(2,(lado.b.dir%10)+48,4,0x37,0,185,0);
                            leer_fecha();
                            write_LCD(2,'2',0,100,1,55,0);
                            write_LCD(2,'0',1,100,1,55,0);
                            write_LCD(2,((rventa.fecha[2]&0xF0)>>4)+48,2,100,1,55,0);
                            write_LCD(2,(rventa.fecha[2]&0x0F)+48,3,100,1,55,0);
                            if((((rventa.fecha[2]&0xF0)>>4)+48)>0x39 &&((rventa.fecha[2]&0x0F)+48)>0x39){
                                Buffer_LCD2.Estado_Mux=0xA5;//Requiere configuraciones iniciales
                            }else if((((rventa.fecha[2]&0xF0)>>4)+48)=='0' &&((rventa.fecha[2]&0x0F)+48)=='0'){
                                Buffer_LCD2.Estado_Mux=0xA5;//Requiere configuraciones iniciales
                            }
                            write_LCD(2,'/',4,100,1,55,0);
                            write_LCD(2,((rventa.fecha[1]&0x10)>>4)+48,5,100,1,55,0);
                            write_LCD(2,(rventa.fecha[1]&0x0F)+48,6,100,1,55,0);
                            write_LCD(2,'/',1,1,2,55,0);
                            write_LCD(2,((rventa.fecha[0]&0x30)>>4)+48,2,1,2,55,0);
                            write_LCD(2,(rventa.fecha[0]&0x0F)+48,3,1,2,55,0);
                            leer_hora();
                            write_LCD(2,((rventa.hora[2]&0xF0)>>4)+48,1,100,1,185,0);
                            write_LCD(2,(rventa.hora[2]&0x0F)+48,2,100,1,185,0);
                            write_LCD(2,':',3,100,1,185,0);
                            write_LCD(2,((rventa.hora[1]&0xF0)>>4)+48,4,100,1,185,0);
                            write_LCD(2,(rventa.hora[1]&0x0F)+48,5,100,1,185,0);
                            write_LCD(2,':',6,100,1,185,0);
                            write_LCD(2,((rventa.hora[0]&0xF0)>>4)+48,1,1,2,185,0);
                            write_LCD(2,(rventa.hora[0]&0x0F)+48,2,1,2,185,0);
                            write_LCD(2,(lado.c.versdig/10)+48,4,100,1,60,1);
                            write_LCD(2,(lado.c.versdig%10)+48,5,100,1,60,1);
                            flujo_LCD2=44;		//Caso 44
                        break;
                            
						case 0x0D:				//Atras 
                            set_imagen(2,0);
						  	flujo_LCD2=0;		//Caso 0
							LCD_2_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_2_ClearRxBuffer();
	        }
	    break;
			
		case 4:	//Venta de Combustibles
			if(LCD_2_GetRxBufferSize()==8){	
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                switch(LCD_2_rxBuffer[3]){
	                    case 0x37:				//Contado
							set_imagen(2,7);	//dinero volumen full
							flujo_LCD2=5;		//Caso 5
							resetvariables(2);
							Buffer_LCD2.TipodeVenta='0';
	                    break;                
	                    
	                    case 0x38:				//Contado Control
							set_imagen(2,14);	//intro km
							flujo_LCD2=12;		//Caso 12
							resetvariables(2);
							Buffer_LCD2.TipodeVenta='2';
							Buffer_LCD2.CompTeclado=6;
							teclas2=0;
	                    break; 

	                    case 0x39:				//Credito
	                    	set_imagen(2,14);	//intro km
							flujo_LCD2=12;		//Caso 
							resetvariables(2);
							Buffer_LCD2.TipodeVenta='1';
							Buffer_LCD2.CompTeclado=6;
							teclas2=0;
	                    break;
						
	                    case 0x0D:				//Atras --> Menu Principal
						  	flujo_LCD2=3;		//Caso 3
							set_imagen(2,51);	//menu distracom
							LCD_2_ClearRxBuffer();
							Buffer_LCD2.TipodeVenta=0;
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_2_ClearRxBuffer();
	        }
		break;
			
		case 5:	//Venta Combustible de Contado
			if(LCD_2_GetRxBufferSize()==8){	
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					Buffer_LCD2.preset&=0xFC;
	                switch(LCD_2_rxBuffer[3]){
	                    case 0x15:				//Dinero
							set_imagen(2,15);	//Intro Valor
							flujo_LCD2=6;		//Case 6
							teclas2=0;          //Inicia el contador de teclas  
							write_LCD(2,'$',0,0x37,0x00,0x40,0x00);
					  		Buffer_LCD2.preset|=2;
							Buffer_LCD2.PresetProgramado='D';
	                    break;
	                    
	                    case 0x16:				//Volumen                             
		                    set_imagen(2,13);	//intro galones1
							flujo_LCD2=6;       	//Caso 6          
		                    teclas2=0;			//Inicia el contador de teclas
		                    comas2=0;
		                    write_LCD(2,'G',0,0x37,0x00,0x40,0x00);
							Buffer_LCD2.preset|=1;
							Buffer_LCD2.PresetProgramado='V';
	                    break; 

	                    case 0x17:				//Full
							flujo_LCD2=7;      	//Caso 7
	                        set_imagen(2,63);	//SUBA la manija
							Buffer_LCD2.preset|=2;
							Buffer_LCD2.PresetProgramado='F';
							for(i=1;i<=(lado.c.versdig-1);i++){
								Buffer_LCD2.valor[i]=0x39;
								Buffer_LCD2.ValorPreset[i]=0x39;
								if(i==(lado.c.versdig-1)){
									Buffer_LCD2.valor[i]=0x30;
									Buffer_LCD2.ValorPreset[i]=0x30;
									Buffer_LCD2.valor[i+1]=0x30;
									Buffer_LCD2.ValorPreset[i+1]=0x30;
								}
							}
							Buffer_LCD2.valor[0]=lado.c.versdig;
							Buffer_LCD2.ValorPreset[0]=lado.c.versdig;
	                    break;
						
	                    case 0x0D:				//Atras
						  	flujo_LCD2=4;		//Caso 4
							set_imagen(2,25);	//contado contado control credito
							LCD_2_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_2_ClearRxBuffer();
	        }
		break;
			
		case 6:	//Digite valor a tanquear
			if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                if(teclas2<=(lado.c.versdig-1)){
	                    if(LCD_2_rxBuffer[3]<=9){
	                        teclas2++;
	                        Buffer_LCD2.valor[teclas2]=LCD_2_rxBuffer[3]+0x30;
							Buffer_LCD2.ValorPreset[teclas2]=LCD_2_rxBuffer[3]+0x30;
	                        write_LCD(2,(LCD_2_rxBuffer[3]+0x30),teclas2,0x37,0x00,0x40,0x00);
	                    }
	                    if(LCD_2_rxBuffer[3]==0x0A){            	//Comando de 0
	                        teclas2++;
	                        Buffer_LCD2.valor[teclas2]=0x30;
							Buffer_LCD2.ValorPreset[teclas2]=0x30;
	                        write_LCD(2,0x30,teclas2,0x37,0x00,0x40,0x00);
	                    }  
	                    if(LCD_2_rxBuffer[3]==0x4E){            	//Comando de Coma
	                        if(teclas2>=1 && comas2==0){
	                            teclas2++;
	                            Buffer_LCD2.valor[teclas2]=0x2C;
								Buffer_LCD2.ValorPreset[teclas2]=0x2C;
	                            write_LCD(2,0x2C,teclas2,0x37,0x00,0x40,0x00);
	                            comas2=1;
	                        }
	                    }
	                }
	                if(LCD_2_rxBuffer[3]==0x0B){					//DEL
	                    if(teclas2==0){								//Si no ha presionado nada regresa al menu anterior
							set_imagen(2,7);
		                    flujo_LCD2=5;
	                    }
	                    else{
	                        write_LCD(2,0x20,(teclas2),0x37,0x00,0x40,0x00);			//Si ya presiono borra el dato	
	                        if(Buffer_LCD2.valor[teclas2]==0x2C){
	                            comas2=0;
	                        }
	                        teclas2--;
	                    }
	                }
	                if(LCD_2_rxBuffer[3]==0x0C){					//ENT
	                    if(teclas2>=1){	//Animacion --> Menu Principal --> Combustibles --> Contado --> Dinero --> Suba la Manija
							Buffer_LCD2.valor[0]=teclas2;
							Buffer_LCD2.ValorPreset[0]=teclas2;
							flujo_LCD2=7;      	//Caso 7
	                        set_imagen(2,63);	//SUBA la manija
							LCD_2_ClearRxBuffer();
	                    }
	                }
					if(LCD_2_rxBuffer[3]==0x0D){//Atras --> Contado
						teclas2=0;
						flujo_LCD2=5;		//Caso 5
						set_imagen(2,7);	//dinero volumen full
						LCD_2_ClearRxBuffer();	
					}
	            }
	            CyDelay(20);            
	            LCD_2_ClearRxBuffer();
	        }
		break;
			
		case 7:	//Esperando a subir la manija para programar el equipo
	        if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                if(LCD_2_rxBuffer[3]==0x0D){//Cancel
						Buffer_LCD2.Estado_Mux=0xA1;	//Queda en espera
						set_imagen(2,0);		//animacion0
						flujo_LCD2=0;			//Caso 0
	                }												
				}
	            CyDelay(20);            
	            LCD_2_ClearRxBuffer();
				break;
			}
			if(get_estado(lado.b.dir)==7){//Espera a que este en listo el equipo
				Buffer_LCD2.Estado_Mux=0xA3;//Se subio la manija, despues de programar el equipo
				CyDelay(50);
				producto2=estado_ex(lado.b.dir);											//Obtiene el grado de la manguera
				CyDelay(50);		
				if((Buffer_LCD2.preset&0x02)==0x02||(Buffer_LCD2.preset&0x01)==0x01){		//Dependiendo del preset hace la programación
					if(programar(lado.b.dir,producto2,Buffer_LCD2.valor,(Buffer_LCD2.preset&0x03))==0){
						Buffer_LCD2.Estado_Mux=0xA5;//Se cancelo la operacion despues de subir la manija
						set_imagen(2,3);	//cancelada por pc
						isr_4_StartEx(animacion2);
						Timer_Animacion2_Start();
						flujo_LCD2=100;		//Caso 100
						count_protector2=0;
						break;
					}					
				}
				producto2=estado_ex(lado.b.dir);
				if(producto2!=0){	
					if(get_totales(lado.b.dir)!=0){
						if(producto2==1){
							for(i=0;i<=Buffer_LCD2.TotalVolumen1[0];i++){
								Buffer_LCD2.TotalVolumenAnterior[i]=Buffer_LCD2.TotalVolumen1[i];
								Buffer_LCD2.TotalDineroAnterior[i]=Buffer_LCD2.TotalDinero1[i];
							}
						}else if(producto2==2){
							for(i=0;i<=Buffer_LCD2.TotalVolumen2[0];i++){
								Buffer_LCD2.TotalVolumenAnterior[i]=Buffer_LCD2.TotalVolumen2[i];
								Buffer_LCD2.TotalDineroAnterior[i]=Buffer_LCD2.TotalDinero2[i];
							}
						}else if(producto2==3){
							for(i=0;i<=Buffer_LCD2.TotalVolumen3[0];i++){
								Buffer_LCD2.TotalVolumenAnterior[i]=Buffer_LCD2.TotalVolumen3[i];
								Buffer_LCD2.TotalDineroAnterior[i]=Buffer_LCD2.TotalDinero3[i];
							}
						}
					}
					Surtidor_PutChar(0x10|lado.b.dir);//Autoriza el surtidor
				    flujo_LCD2=8;		//Caso 8
					if(leer_fecha()==1){//Lectura de Fecha Inicial
						Buffer_LCD2.FechaInicialVenta[0]=14;
						Buffer_LCD2.FechaInicialVenta[1]=0x32;
						Buffer_LCD2.FechaInicialVenta[2]=0x30;
						Buffer_LCD2.FechaInicialVenta[3]=(((rventa.fecha[2]&0xF0)>>4)+48);
						Buffer_LCD2.FechaInicialVenta[4]=((rventa.fecha[2]&0x0F)+48);
						Buffer_LCD2.FechaInicialVenta[5]=(((rventa.fecha[1]&0x10)>>4)+48);
						Buffer_LCD2.FechaInicialVenta[6]=((rventa.fecha[1]&0x0F)+48);
						Buffer_LCD2.FechaInicialVenta[7]=(((rventa.fecha[0]&0x30)>>4)+48);
						Buffer_LCD2.FechaInicialVenta[8]=((rventa.fecha[0]&0x0F)+48);
						
					}
					if(leer_hora()==1){//Lectura de Hora Inicial	
						Buffer_LCD2.FechaInicialVenta[9]=(((rventa.hora[2]&0xF0)>>4)+48);	
						Buffer_LCD2.FechaInicialVenta[10]=((rventa.hora[2]&0x0F)+48);
						Buffer_LCD2.FechaInicialVenta[11]=(((rventa.hora[1]&0xF0)>>4)+48);
						Buffer_LCD2.FechaInicialVenta[12]=((rventa.hora[1]&0x0F)+48);
						Buffer_LCD2.FechaInicialVenta[13]=(((rventa.hora[0]&0xF0)>>4)+48);
						Buffer_LCD2.FechaInicialVenta[14]=((rventa.hora[0]&0x0F)+48);
					}
				}
				LCD_1_ClearRxBuffer();
				PC_ClearRxBuffer();
        	}
		break;
			
		case 8://Coloca datos digitados durante el tanqueo en pantalla
			set_imagen(2,2);	//DATOS
			for(i=1;i<=Buffer_LCD2.placa[0];i++){		//Coloca la placa en la ventana de datos
				write_LCD(2,Buffer_LCD2.placa[i],i,0x05,0x01,0x65,0x00);
			}
			for(i=1;i<=Buffer_LCD2.cedula[0];i++){		//Coloca la cedula en la ventana de datos
				write_LCD(2,Buffer_LCD2.cedula[i],i,0x05,0x01,0xB0,0x00);
			}
			for(i=1;i<=Buffer_LCD2.Nit[0];i++){		//Coloca en Nit en la ventana de datos
				write_LCD(2,Buffer_LCD2.Nit[i],i,0x05,0x01,0xF7,0x00);
			}
			for(i=1;i<=Buffer_LCD2.km[0];i++){		//Coloca en km en la ventana de datos
				write_LCD(2,Buffer_LCD2.km[i],i,0x05,0x01,0x40,0x01);
			}
			flujo_LCD2=9;
		break;
			
		case 9://Tanqueando, introduzca datos
			if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					switch(LCD_2_rxBuffer[3]){
						case 0x0E:	//Placa
							for(i=0;i<=7;i++){				//Para Borrar si se ha digitado placa anteriormente
								Buffer_LCD2.placa[i]=0x20;
							}
							set_imagen(2,6);	//digite placa
							flujo_LCD2=10;		//Caso 10
							teclas2=0;
							LCD_2_ClearRxBuffer();
							count_protector2=0;
						break;
						case 0x0F:	//Cedula
							for(i=0;i<=9;i++){				//Para Borrar si se ha digitado cedula anteriormente
								Buffer_LCD2.cedula[i]=0x20;
							}
							set_imagen(2,68);	//digite nit cc
							flujo_LCD2=12;		//Caso 12
							Buffer_LCD2.CompTeclado=1;//Teclado de cedula 
							teclas2=0;
							LCD_2_ClearRxBuffer();
							count_protector2=0;
						break;
						case 0x10:	//Nit
							for(i=0;i<=9;i++){				//Para Borrar si se ha digitado NIT anteriormente
								Buffer_LCD2.Nit[i]=0x20;
							}
							set_imagen(2,68);	//digite nit cc
							flujo_LCD2=12;		//Caso 12
							Buffer_LCD2.CompTeclado=2;//Teclado de Nit
							teclas2=0;
							LCD_2_ClearRxBuffer();
							count_protector2=0;
						break;
						case 0x11:	//Kilometraje
							for(i=0;i<=6;i++){				//Para Borrar si se ha digitado NIT anteriormente
								Buffer_LCD2.km[i]=0x20;
							}
							set_imagen(2,14);	//intro km1
							flujo_LCD2=12;		//Caso 12
							Buffer_LCD2.CompTeclado=3;//Teclado de Kilometraje
							teclas2=0;
							LCD_2_ClearRxBuffer();
							count_protector2=0;
						break;
						case 0x0C:	//Aceptar
							if(Placa_Contado==0x01){//Si la placa es obligatoria
								if(Buffer_LCD2.placa[0]==0){//No digito placa
									set_imagen(2,18);	//placa obligatoria
									CyDelay(100);
									flujo_LCD2=8;
									LCD_2_ClearRxBuffer();
								}else if(Buffer_LCD2.placa[0]>=1){//Si Digito Placa
									set_imagen(2,20);	//tanqueando
									LCD_2_ClearRxBuffer();
								}
							}else if(Placa_Contado==0x00){//Si no es obligatoria la placa
								set_imagen(2,20);	//tanqueando
								LCD_2_ClearRxBuffer();
							}
						break;	
					}
				}
				CyDelay(20);
		        LCD_2_ClearRxBuffer();
			}
            switch (get_estado(lado.b.dir)){
                case 0x09://Surtiendo
                    Buffer_LCD2.Estado_Mux=0xAC;//Surtiendo Combustible
                break;
                case 0x0B://Termino venta
                    set_imagen(2,8);	//esperando 1
    				if(venta(lado.b.dir,producto2)==1){
    					if(Placa_Contado==0x01){//Si es con placa obligatoria
    						if(Buffer_LCD2.placa[0]==0){//No digito placa
    							set_imagen(2,6);	//digite placa
    							flujo_LCD2=11;		//Caso 11
    							teclas2=0;
    						}else if(Buffer_LCD2.placa[0]>=1){//Si Digito Placa
    							set_imagen(2,4);	//desea imprimir recibo
    							flujo_LCD2=13;	//Caso 13
    							LCD_2_ClearRxBuffer();
    							isr_4_StartEx(animacion2); 
    							Timer_Animacion2_Start();
    							count_protector2=0;
    						}
    					}else if(Placa_Contado==0x00){//Si no es placa obligatoria
    						set_imagen(2,4);	//desea imprimir recibo
    						flujo_LCD2=13;	//Caso 13
    						LCD_2_ClearRxBuffer();
    						isr_4_StartEx(animacion2); 
    						Timer_Animacion2_Start();
    						count_protector2=0;
    					}
    				}
                break;
                case 0x0A://Termino venta
                    set_imagen(2,8);	//esperando 1
    				if(venta(lado.b.dir,producto2)==1){
    					if(Placa_Contado==0x01){//Si es con placa obligatoria
    						if(Buffer_LCD2.placa[0]==0){//No digito placa
    							set_imagen(2,6);	//digite placa
    							flujo_LCD2=11;		//Caso 11
    							teclas2=0;
    						}else if(Buffer_LCD2.placa[0]>=1){//Si Digito Placa
    							set_imagen(2,4);	//desea imprimir recibo
    							flujo_LCD2=13;	//Caso 13
    							LCD_2_ClearRxBuffer();
    							isr_4_StartEx(animacion2); 
    							Timer_Animacion2_Start();
    							count_protector2=0;
    						}
    						
    					}else if(Placa_Contado==0x00){//Si no es placa obligatoria
    						set_imagen(2,4);	//desea imprimir recibo
    						flujo_LCD2=13;	//Caso 13
    						LCD_2_ClearRxBuffer();
    						isr_4_StartEx(animacion2); 
    						Timer_Animacion2_Start();
    						count_protector2=0;
    					}
    				}
                break;
                case 0x06://No hizo venta
                    Buffer_LCD2.Estado_Mux=0xA4;//No se realizo venta
				    flujo_LCD2=0;
                break;
            }
		break;
			
		case 10://Digite Placa para datos
	        if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					count_protector2=0;
	                if(teclas2<=7){
	                    if(LCD_2_rxBuffer[3]<=9){
	                        teclas2++;
	                        Buffer_LCD2.placa[teclas2]=LCD_2_rxBuffer[3]+0x30;
	                        write_LCD(2,(LCD_2_rxBuffer[3]+0x30),teclas2,0x05,0x01,0x28,0x00);                        
	                    }
	                    if(LCD_2_rxBuffer[3]==0x0A){                                        //Comando de 0
	                        teclas2++;                        
	                        Buffer_LCD2.placa[teclas2]=0x30;
	                        write_LCD(2,0x30,teclas2,0x05,0x01,0x28,0x00);                        
	                    }					
	                    if(LCD_2_rxBuffer[3]>=0x1B && LCD_2_rxBuffer[3]<=0x42){            //Comando de Letra
	                        for(x=0;x<=25;x++){                                            //Compara el dato que llego con un vector que tiene todas las letras     
	                            if(LCD_2_rxBuffer[3]==letras[x]){
	                                teclas2++;                            
	                                Buffer_LCD2.placa[teclas2]=x+0x41;
	                                write_LCD(2,(x+0x41),teclas2,0x05,0x01,0x28,0x00);                            
	                            }
	                        }
	                    }                    
	                }
	                if(LCD_2_rxBuffer[3]==0x0B){                                        //Borrar - Cancelar
	                    if(teclas2==0){
	                        Buffer_LCD2.placa[0]=0;
							if(Buffer_LCD2.CompTeclado==6){//Placa de contado control o credito
								set_imagen(2,52);	//METODO ID1a
								flujo_LCD2=15;	//Caso 15
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==21){//Placa de Canastilla
								set_imagen(2,52);	//METODO ID1a
								flujo_LCD2=36;	//Caso 36
								Buffer_LCD2.CompTeclado=0;
							}else{
								flujo_LCD2=8;		//Caso 8
								Buffer_LCD2.CompTeclado=0;
							}
							LCD_2_ClearRxBuffer();
	                    }
	                    else{
	                        write_LCD(2,0x20,teclas2,0x05,0x01,0x28,0x00);                        
	                        teclas2--;
	                    }
	                }
	                if(LCD_2_rxBuffer[3]==0x0C){                                        //Enter pasa la informacion a la casilla Placa
	                    if(teclas2>=1){
	                        Buffer_LCD2.placa[0]=teclas2;
							if(Buffer_LCD2.CompTeclado==6){//Placa de contado control
								Buffer_LCD2.IdentCliente[0]=Buffer_LCD2.placa[0]+1;
								Buffer_LCD2.IdentCliente[1]='P';
								for(i=0;i<=Buffer_LCD2.placa[0];i++){
									Buffer_LCD2.IdentCliente[i+2]=Buffer_LCD2.placa[i+1];
								}
								Buffer_LCD2.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control
								Buffer_LCD2.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(2,8);	//esperando 1
								flujo_LCD2=18;	//Caso 18
								Buffer_LCD2.CompTeclado=0;
								isr_4_StartEx(animacion2); 
					         	Timer_Animacion2_Start();
					         	count_protector2=0;
							}else if(Buffer_LCD2.CompTeclado==21){//Placa de Canastilla
								Buffer_LCD2.IdentCliente[0]=Buffer_LCD2.placa[0]+1;
								Buffer_LCD2.IdentCliente[1]='P';
								for(i=0;i<=Buffer_LCD2.placa[0];i++){
									Buffer_LCD2.IdentCliente[i+2]=Buffer_LCD2.placa[i+1];
								}
								Buffer_LCD2.Estado_Mux=0xF7;//Autorizacion para Venta por Contado Control
								Buffer_LCD2.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(2,8);	//esperando 1
								flujo_LCD2=37;	//Caso 37
								Buffer_LCD2.CompTeclado=0;
								isr_4_StartEx(animacion2); 
					         	Timer_Animacion2_Start();
					         	count_protector2=0;
							}else{
								flujo_LCD2=8;		//Caso 8
								Buffer_LCD2.CompTeclado=0;
							}
	                    }
	                }
	            }
	            CyDelay(20);            
	            LCD_2_ClearRxBuffer();
	        }
        break;

		case 11://Digite Placa Obligatoria
	        if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					count_protector2=0;
	                if(teclas2<=7){
	                    if(LCD_2_rxBuffer[3]<=9){
	                        teclas2++;
	                        Buffer_LCD2.placa[teclas2]=LCD_2_rxBuffer[3]+0x30;
	                        write_LCD(2,(LCD_2_rxBuffer[3]+0x30),teclas2,0x05,0x01,0x28,0x00);                        
	                    }
	                    if(LCD_2_rxBuffer[3]==0x0A){                                        //Comando de 0
	                        teclas2++;                        
	                        Buffer_LCD2.placa[teclas2]=0x30;
	                        write_LCD(2,0x30,teclas2,0x05,0x01,0x28,0x00);                        
	                    }					
	                    if(LCD_2_rxBuffer[3]>=0x1B && LCD_2_rxBuffer[3]<=0x42){            //Comando de Letra
	                        for(x=0;x<=25;x++){                                            //Compara el dato que llego con un vector que tiene todas las letras     
	                            if(LCD_2_rxBuffer[3]==letras[x]){
	                                teclas2++;                            
	                                Buffer_LCD2.placa[teclas2]=x+0x41;
	                                write_LCD(2,(x+0x41),teclas2,0x05,0x01,0x28,0x00);                            
	                            }
	                        }
	                    }                    
	                }
	                if(LCD_2_rxBuffer[3]==0x0B){//Borrar - Cancelar
	                    if(teclas2==0){
							set_imagen(2,18);	//placa obligatoria
							CyDelay(100);
							set_imagen(2,6);	//digite placa
							flujo_LCD2=11;		//Caso 11
							teclas2=0;
							LCD_2_ClearRxBuffer();
	                    }
	                    else{
	                        write_LCD(2,0x20,teclas2,0x05,0x01,0x28,0x00);                        
	                        teclas2--;
	                    }
	                }
	                if(LCD_2_rxBuffer[3]==0x0C){		//Enter 
	                    if(teclas2>=1){
							if(Buffer_LCD2.CompTeclado==8){//Si la venta viene autorizada
								Buffer_LCD2.placa[0]=teclas2;
                                if(Buffer_LCD2.VentasPendientesR<3){
                                    escribir_ram(27+(186*(Buffer_LCD2.VentasPendientesR-1)),Buffer_LCD2.placa,2);
                                }else{
                                    write_eeprom(607+(512*(Buffer_LCD2.VentasPendientesE-1)),Buffer_LCD2.placa);
                                }
								set_imagen(2,50);	//imprimiendo 4
								flujo_LCD2=14;		//Caso 14
								LCD_2_ClearRxBuffer();
								isr_4_StartEx(animacion2); 
								Timer_Animacion2_Start();
								count_protector2=0;
								Buffer_LCD2.Impresionmux=0x02;//Para evitar conflictos mas adelante
								Buffer_LCD2.BanImpFin=0x02;//Para evitar conflictos mas adelante
								Buffer_LCD2.ConfirmacionImpresion='2';
								Buffer_LCD2.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
								Buffer_LCD2.CompTeclado=0;
							}else{	//Ventas solo de contado
		                        Buffer_LCD2.placa[0]=teclas2;
                                if(Buffer_LCD2.VentasPendientesR<3){
                                    escribir_ram(27+(186*(Buffer_LCD2.VentasPendientesR-1)),Buffer_LCD2.placa,2);
                                }else{
                                    write_eeprom(607+(512*(Buffer_LCD2.VentasPendientesE-1)),Buffer_LCD2.placa);
                                }
								set_imagen(2,4);	//desea imprimir recibo
								flujo_LCD2=13;	//Caso 13
								LCD_2_ClearRxBuffer();
								isr_4_StartEx(animacion2); 
								Timer_Animacion2_Start();
								count_protector2=0;
								Buffer_LCD2.CompTeclado=0;
							}
	                    }
	                }
	            }
	            CyDelay(20);            
	            LCD_2_ClearRxBuffer();
	        }
        break;

		case 12://Teclado para digitar Cedula, Nit, Km y N° de Fuel Control
			if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					count_protector2=0;
	                if(teclas2<=9){
	                    if(LCD_2_rxBuffer[3]<=9){
	                        teclas2++;
	                        Buffer_LCD2.Numeros[teclas2]=LCD_2_rxBuffer[3]+0x30;
	                        write_LCD(2,(LCD_2_rxBuffer[3]+0x30),teclas2,0x05,0x00,0x40,0x00);
	                    }
	                    if(LCD_2_rxBuffer[3]==0x0A){            	//Comando de 0
	                        teclas2++;
	                        Buffer_LCD2.Numeros[teclas2]=0x30;
	                        write_LCD(2,0x30,teclas2,0x05,0x00,0x40,0x00);
	                    }                    
	                }
	                if(LCD_2_rxBuffer[3]==0x0B){					//DEL
	                    if(teclas2==0){								//Si no ha presionado nada regresa al menu anterior
	                        if(Buffer_LCD2.CompTeclado==1){//Teclado cedula tanqueando
								flujo_LCD2=8;	//Caso 8
								Buffer_LCD2.cedula[0]=0;
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==2){//Teclado nit tanqueando
								flujo_LCD2=8;	//Caso 8
								Buffer_LCD2.CompTeclado=0;
								Buffer_LCD2.Nit[0]=0;
							}else if(Buffer_LCD2.CompTeclado==3){//Teclado km tanqueando
								flujo_LCD2=8;	//Caso 8
								Buffer_LCD2.CompTeclado=0;
								Buffer_LCD2.km[0]=0;
							}else if(Buffer_LCD2.CompTeclado==4||Buffer_LCD2.CompTeclado==5){
								set_imagen(2,52);	//METODO ID1a
								flujo_LCD2=15;	//Caso 15
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==6){//Kilometraje para ID
								set_imagen(2,25);//contado contado control credito
								flujo_LCD2=4;	//Caso 4
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==7){//Teclado cedula vendedor
								set_imagen(2,58);//ID Turno
								flujo_LCD2=28;	//Caso 28
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==20||Buffer_LCD2.CompTeclado==23){//Teclado cedula canastilla o N° Fuel Control
								set_imagen(2,52);//METODO ID
								flujo_LCD2=36;	//Caso 36
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==31||Buffer_LCD2.CompTeclado==32||Buffer_LCD2.CompTeclado==33||Buffer_LCD2.CompTeclado==34){//Teclado cantidad productos canastilla
								set_imagen(2,69);	//Canastilla
								LCD_Canastilla(2);
								flujo_LCD2=39;		//Caso 39
								Buffer_LCD2.CompTeclado=0;
							}
							Buffer_LCD2.Numeros[0]=0;
	                    }else{
	                        write_LCD(2,0x20,(teclas2),0x05,0x00,0x40,0x00);			//Si ya presiono borra el dato	
	                        if(Buffer_LCD2.Numeros[teclas2]==0x2C){
	                            comas2=0;
	                        }
	                        teclas2--;
	                    }
	                }
	                if(LCD_2_rxBuffer[3]==0x0C){					//ENT
	                    if(teclas2>=1){
							Buffer_LCD2.Numeros[0]=teclas2;
							if(Buffer_LCD2.CompTeclado==1){//Cedula de Tanqueando
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.cedula[i]=Buffer_LCD2.Numeros[i];
								}
								flujo_LCD2=8;	//Caso 8
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==2){//Nit de Tanqueando
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.Nit[i]=Buffer_LCD2.Numeros[i];
								}
								flujo_LCD2=8;	//Caso 8
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==3){//Kilometraje de Tanqueando
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.km[i]=Buffer_LCD2.Numeros[i];
								}
								flujo_LCD2=8;	//Caso 8
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==4){//Cedula de Contado Control o credito
								Buffer_LCD2.IdentCliente[0]=Buffer_LCD2.Numeros[0]+1;
								Buffer_LCD2.IdentCliente[1]='C';
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.IdentCliente[i+2]=Buffer_LCD2.Numeros[i+1];
									Buffer_LCD2.cedula[i]=Buffer_LCD2.Numeros[i];
								}
								Buffer_LCD2.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control
								Buffer_LCD2.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(2,8);	//esperando 1
								flujo_LCD2=18;	//Caso 18
								Buffer_LCD2.CompTeclado=0;
								isr_4_StartEx(animacion2); 
					         	Timer_Animacion2_Start();
					         	count_protector2=0;
							}else if(Buffer_LCD2.CompTeclado==5){//N° De Fuel Control de Contado Control o credito
								Buffer_LCD2.IdentCliente[0]=Buffer_LCD2.Numeros[0]+1;
								Buffer_LCD2.IdentCliente[1]='F';
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.IdentCliente[i+2]=Buffer_LCD2.Numeros[i+1];
								}
								Buffer_LCD2.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control
								Buffer_LCD2.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(2,8);	//esperando 1
								flujo_LCD2=18;	//Caso 18
								Buffer_LCD2.CompTeclado=0;
								isr_4_StartEx(animacion2); 
					         	Timer_Animacion2_Start();
					         	count_protector2=0;
							}else if(Buffer_LCD2.CompTeclado==6){//Kilometraje para validacion de ID
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.KmID[i]=Buffer_LCD2.Numeros[i];
									Buffer_LCD2.km[i]=Buffer_LCD2.Numeros[i];
								}
	                      		set_imagen(2,52);	//METODO ID1a
								flujo_LCD2=15;		//Caso 15
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==7){//Cedula vendedor
								IdentVendedor[0]=Buffer_LCD2.Numeros[0]+1;
								IdentVendedor[1]='C';
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									IdentVendedor[i+2]=Buffer_LCD2.Numeros[i+1];
								}
								set_imagen(2,8);	//esperando 1
								flujo_LCD2=29;	//Caso 29
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==20){//Teclado cedula canastilla
								Buffer_LCD2.IdentCliente[0]=Buffer_LCD2.Numeros[0]+1;
								Buffer_LCD2.IdentCliente[1]='C';
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.IdentCliente[i+2]=Buffer_LCD2.Numeros[i+1];
								}
								Buffer_LCD2.Estado_Mux=0xF7;//Autorizacion para Venta de Canastilla por Credito
								Buffer_LCD2.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(2,8);	//esperando 1
								flujo_LCD2=37;	//Caso 37
								Buffer_LCD2.CompTeclado=0;
								isr_4_StartEx(animacion2); 
					         	Timer_Animacion2_Start();
					         	count_protector2=0;
							}else if(Buffer_LCD2.CompTeclado==23){//Teclado N° Fuel Control canastilla
								Buffer_LCD2.IdentCliente[0]=Buffer_LCD2.Numeros[0]+1;
								Buffer_LCD2.IdentCliente[1]='F';
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.IdentCliente[i+2]=Buffer_LCD2.Numeros[i+1];
								}
								Buffer_LCD2.Estado_Mux=0xF7;//Autorizacion para Venta de Canastilla por Credito
								Buffer_LCD2.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
								set_imagen(2,8);	//esperando 1
								flujo_LCD2=37;	//Caso 37
								Buffer_LCD2.CompTeclado=0;
								isr_4_StartEx(animacion2); 
					         	Timer_Animacion2_Start();
					         	count_protector2=0;
							}else if(Buffer_LCD2.CompTeclado==31){//Teclado producto 1 canastilla
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.CantProducto1Canasta[i]=Buffer_LCD2.Numeros[i];
								}
								if(Buffer_LCD2.CantProducto1Canasta[0]>3){
									Buffer_LCD2.CantProducto1Canasta[0]=3;
								}
	                      		set_imagen(2,69);	//Canastilla
								LCD_Canastilla(2);
								flujo_LCD2=39;		//Caso 39
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==32){//Teclado producto 2 canastilla
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.CantProducto2Canasta[i]=Buffer_LCD2.Numeros[i];
								}
								if(Buffer_LCD2.CantProducto2Canasta[0]>3){
									Buffer_LCD2.CantProducto2Canasta[0]=3;
								}
	                      		set_imagen(2,69);	//Canastilla
								LCD_Canastilla(2);
								flujo_LCD2=39;		//Caso 39
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==33){//Teclado producto 3 canastilla
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.CantProducto3Canasta[i]=Buffer_LCD2.Numeros[i];
								}
								if(Buffer_LCD2.CantProducto3Canasta[0]>3){
									Buffer_LCD2.CantProducto3Canasta[0]=3;
								}
	                      		set_imagen(2,69);	//Canastilla
								LCD_Canastilla(2);
								flujo_LCD2=39;		//Caso 39
								Buffer_LCD2.CompTeclado=0;
							}else if(Buffer_LCD2.CompTeclado==31){//Teclado producto 4 canastilla
								for(i=0;i<=Buffer_LCD2.Numeros[0];i++){
									Buffer_LCD2.CantProducto4Canasta[i]=Buffer_LCD2.Numeros[i];
								}
								if(Buffer_LCD2.CantProducto4Canasta[0]>3){
									Buffer_LCD2.CantProducto4Canasta[0]=3;
								}
	                      		set_imagen(2,69);	//Canastilla
								LCD_Canastilla(2);
								flujo_LCD2=39;		//Caso 39
								Buffer_LCD2.CompTeclado=0;
							}
	                    }
	                }
					if(LCD_2_rxBuffer[3]==0x0D){//Atras
						teclas2=0;
						for(i=1;i<=9;i++){				 
							Buffer_LCD2.Numeros[i]=0;
						}
						if(Buffer_LCD2.CompTeclado==1){//Teclado cedula tanqueando
							flujo_LCD2=8;	//Caso 8
							Buffer_LCD2.cedula[0]=0;
							Buffer_LCD2.CompTeclado=0;
						}else if(Buffer_LCD2.CompTeclado==2){//Teclado nit tanqueando
							flujo_LCD2=8;	//Caso 8
							Buffer_LCD2.CompTeclado=0;
							Buffer_LCD2.Nit[0]=0;
						}else if(Buffer_LCD2.CompTeclado==3){//Teclado km tanqueando
							flujo_LCD2=8;	//Caso 8
							Buffer_LCD2.CompTeclado=0;
							Buffer_LCD2.km[0]=0;
						}else if(Buffer_LCD2.CompTeclado==4||Buffer_LCD2.CompTeclado==5){
							set_imagen(2,52);	//METODO ID1a
							flujo_LCD2=15;	//Caso 15
							Buffer_LCD2.CompTeclado=0;
						}else if(Buffer_LCD2.CompTeclado==6){
							set_imagen(2,25);//contado contado control credito
							flujo_LCD2=4;	//Caso 4
							Buffer_LCD2.CompTeclado=0;
						}else if(Buffer_LCD2.CompTeclado==7){//Teclado cedula vendedor
							set_imagen(2,58);//ID Turno
							flujo_LCD2=28;	//Caso 28
							Buffer_LCD2.CompTeclado=0;
						}else if(Buffer_LCD2.CompTeclado==20||Buffer_LCD2.CompTeclado==23){//Teclado cedula o N° Fuel control credito canastilla
							set_imagen(2,52);//METODO ID
							flujo_LCD2=36;	//Caso 36
							Buffer_LCD2.CompTeclado=0;
						}else if(Buffer_LCD2.CompTeclado==31||Buffer_LCD2.CompTeclado==32||Buffer_LCD2.CompTeclado==33||Buffer_LCD2.CompTeclado==34){//Teclado cantidad productos canastilla
							set_imagen(2,69);	//Canastilla
							LCD_Canastilla(2);
							flujo_LCD2=39;		//Caso 39
							Buffer_LCD2.CompTeclado=0;
						}
						Buffer_LCD2.Numeros[0]=0;
					}
	            }
	            CyDelay(20);            
	            LCD_2_ClearRxBuffer();
	        }
		break;
			
		case 13://Imprimir Venta Combustible
			if(LCD_2_GetRxBufferSize()==8){	
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                switch(LCD_2_rxBuffer[3]){
						case 0x14:	//cero
							set_imagen(2,10);	//gracias
	            			flujo_LCD2=100;
							count_protector2=0;
							Buffer_LCD2.ConfirmacionImpresion='0';
							Buffer_LCD2.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
						break;
							
						case 0x13:	//uno
							set_imagen(2,50);	//imprimiendo 4
							flujo_LCD2=14; //caso 14
							count_protector2=0;
							Buffer_LCD2.ConfirmacionImpresion='1';
							Buffer_LCD2.Impresionmux=0x02;//Para evitar conflictos mas adelante
							Buffer_LCD2.BanImpFin=0x02;//Para evitar conflictos mas adelante
							Buffer_LCD2.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
						break;
							
						case 0x57:	//dos
							set_imagen(2,50);	//imprimiendo 4
							flujo_LCD2=14; //caso 14
							count_protector2=0;
							Buffer_LCD2.ConfirmacionImpresion='2';
							Buffer_LCD2.Impresionmux=0x02;//Para evitar conflictos mas adelante
							Buffer_LCD2.BanImpFin=0x02;//Para evitar conflictos mas adelante
							Buffer_LCD2.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
						break;
					}
				}
				CyDelay(20);            
	            LCD_2_ClearRxBuffer();
			}
			if(count_protector2>=30){
	            set_imagen(2,10);	//gracias
	            flujo_LCD2=100; 
			    count_protector2=0;
				Buffer_LCD2.ConfirmacionImpresion='0';
				Buffer_LCD2.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
		 	}
		break;
			
		case 14://Esperando trama de impresion por sistema
			if(count_protector2>=25){//Si no llega nada imprime un recibo predeterminado
				print_logo(print2[1]);
				imprimir(print2[1], producto2,0,lado.b.dir);
                if(Buffer_LCD2.ConfirmacionImpresion=='2' && Buffer_LCD2.TipodeVenta=='0'){
                    print_logo(print2[1]);
    				imprimir(print2[1], producto2,0,lado.b.dir);
                }
				if(Buffer_LCD2.TipodeVenta=='1' || Buffer_LCD2.TipodeVenta=='2'){
					print_logo(print2[1]);
					imprimir(print2[1], producto2,1,lado.b.dir);
				}   
				set_imagen(2,10);	//gracias
	            flujo_LCD2=100; 
			    count_protector2=0;
			}else if(Buffer_LCD2.BanImpFin==0x01){//Cuando finaliza la trama de impresion por sistema
				set_imagen(2,10);	//gracias
	            flujo_LCD2=100; 
			    count_protector2=0;
			}
		break;
			
		case 15://Venta Combustible de Credito
			if(LCD_2_GetRxBufferSize()==8){	
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                switch(LCD_2_rxBuffer[3]){
	                    case 0x45:				//CC/NIT
							set_imagen(2,68);	//digitenitcc
							flujo_LCD2=12;		//Caso 12
							teclas2=0;
							Buffer_LCD2.CompTeclado=4;
							LCD_2_ClearRxBuffer();
	                    break;
	                    
	                    case 0x0E:				//Placa
	                      	set_imagen(2,6);	//digite placa
							flujo_LCD2=10;		//Caso 10
							teclas2=0;
							Buffer_LCD2.CompTeclado=6;
							LCD_2_ClearRxBuffer();
	                    break;

	                    case 0x47:				//iButton
	                    	set_imagen(2,9);	//esperando id
							flujo_LCD2=16;		//Caso 16
							Buffer_LCD2.CompID=1;
							LCD_2_ClearRxBuffer();
	                    break;
						
						case 0x48:				//N° Fuel Control
	                    	set_imagen(2,37);	//digite numero copias
							flujo_LCD2=12;		//Caso 12
							teclas2=0;
							Buffer_LCD2.CompTeclado=5;
							LCD_2_ClearRxBuffer();
	                    break;
						
						case 0x49:				//RF ID
	                    	set_imagen(2,66);	//esperando rfid
							flujo_LCD2=17;		//Caso 17
							Buffer_LCD2.CompID=2;
							write_psoc1(4,0);//Activo Lectura de Tarjeta
							LCD_2_ClearRxBuffer();
	                    break;
						
                        case 0x4A:				//Pistola codigo de barras
                            Pistola_ClearRxBuffer();
	                      	set_imagen(2,1);//codigo de barras
							flujo_LCD2=45;
                            Buffer_LCD2.CompID=3;
							LCD_2_ClearRxBuffer();
	                    break;
                            
	                    case 0x0D:				//Atras
						  	flujo_LCD2=4;		//Caso 4
							set_imagen(2,25);	//contado contado control credito
							LCD_2_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_2_ClearRxBuffer();
	        }
		break;
	
		case 16://Lectura de Ibutton
			if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					if(LCD_2_rxBuffer[3]==0x0D){//Atras
						if(Buffer_LCD2.CompID==1){
							flujo_LCD2=15;		//Caso 15 
							set_imagen(2,52);	//METODO ID1a
							Buffer_LCD2.CompID=0;
						}else if(Buffer_LCD2.CompID==22){
							flujo_LCD2=36;		//Caso 36 
							set_imagen(2,52);	//METODO ID1a
							Buffer_LCD2.CompID=0;
						}
					}
				}
				CyDelay(20);            
	            LCD_2_ClearRxBuffer();
			}
			if(touch_present(2)==1){
				if(touch_write(2,0x33)){
					for(z=1;z<=8;z++){
						Buffer_LCD2.id[z]=touch_read_byte(2);
					}
					Checkibutton2=0;
					for(z=1;z<8;z++){
                        Checkibutton2=crc_check(Checkibutton2,Buffer_LCD2.id[z]);
                    }
					if(Checkibutton2==Buffer_LCD2.id[8]){
						Buffer_LCD2.id[0]=8;
						Buffer_LCD2.IdentCliente[0]=17;
						Buffer_LCD2.IdentCliente[1]='I';
						j=2;
						for(i=Buffer_LCD2.id[0];i>0;i--){
							if(((Buffer_LCD2.id[i]>>4)&0x0F)>=10){
								Buffer_LCD2.IdentCliente[j]=((Buffer_LCD2.id[i]>>4)&0x0F)+55;
								j++;
							}
							else{
								Buffer_LCD2.IdentCliente[j]=((Buffer_LCD2.id[i]>>4)&0x0F)+48;
								j++;				
							}
							if((Buffer_LCD2.id[i]&0x0F)>=10){
								Buffer_LCD2.IdentCliente[j]=(Buffer_LCD2.id[i]&0x0F)+55;
								j++;
							}
							else{
								Buffer_LCD2.IdentCliente[j]=(Buffer_LCD2.id[i]&0x0F)+48;
								j++;				
							}
						}
						if(Buffer_LCD2.CompID==1){
							Buffer_LCD2.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control o credito
							Buffer_LCD2.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
							set_imagen(2,8);	//esperando 1
							flujo_LCD2=18;	//Caso 18
							Buffer_LCD2.CompID=0;
							isr_4_StartEx(animacion2); 
				         	Timer_Animacion2_Start();
				         	count_protector2=0;
						}else if(Buffer_LCD2.CompID==22){
							Buffer_LCD2.Estado_Mux=0xF7;//Autorizacion para Venta Canastilla credito
							Buffer_LCD2.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
							set_imagen(2,8);	//esperando 1
							flujo_LCD2=37;	//Caso 37
							Buffer_LCD2.CompID=0;
							isr_4_StartEx(animacion2); 
				         	Timer_Animacion2_Start();
				         	count_protector2=0;
						}
					}
				}
			}
		break;
			
		case 17://Lectura de Tarjeta RFID
			if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					if(LCD_2_rxBuffer[3]==0x0D){//Atras
						if(Buffer_LCD2.CompID==2){
							flujo_LCD2=15;		//Caso 15 
							write_psoc1(4,1);//Cancelo Lectura de Tarjeta
							set_imagen(2,52);	//METODO ID1a
							Buffer_LCD2.CompID=0;
						}else if(Buffer_LCD2.CompID==24){//Canastilla credito
							flujo_LCD2=36;		//Caso 36 
							write_psoc1(4,1);//Cancelo Lectura de Tarjeta
							set_imagen(2,52);	//METODO ID1a
							Buffer_LCD2.CompID=0;
						}
					}
				}
				CyDelay(20);            
	            LCD_2_ClearRxBuffer();
			}
			if(read_psoc1()==1){
				for(i=1;i<=10;i++){
					Buffer_LCD2.id[i]=buffer_i2c[i];
				}
				Buffer_LCD2.id[0]=10;
				Buffer_LCD2.IdentCliente[0]=Buffer_LCD2.id[0]+1;
				Buffer_LCD2.IdentCliente[1]='T';
				for(i=0;i<=Buffer_LCD2.id[0];i++){
					Buffer_LCD2.IdentCliente[i+2]=Buffer_LCD2.id[i+1];
				}
				if(Buffer_LCD2.CompID==2){
					Buffer_LCD2.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control o credito
					Buffer_LCD2.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
					set_imagen(2,8);	//esperando 1
					flujo_LCD2=18;	//Caso 18
					Buffer_LCD2.CompID=0;
					isr_4_StartEx(animacion2); 
		         	Timer_Animacion2_Start();
		         	count_protector2=0;
				}else if(Buffer_LCD2.CompID==24){//Canastilla credito
					Buffer_LCD2.Estado_Mux=0xF7;//Autorizacion para Venta credito canastilla
					Buffer_LCD2.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
					set_imagen(2,8);	//esperando 1
					flujo_LCD2=37;	//Caso 37
					Buffer_LCD2.CompID=0;
					isr_4_StartEx(animacion2); 
		         	Timer_Animacion2_Start();
		         	count_protector2=0;
				}
			}
		break;
			
		case 18://Esperando Autorizacion para venta de Contado Control o Credito
			if(Buffer_LCD2.AutorizacionControl==0x01){//Autorizado
				set_imagen(2,11);//SUMINISTRO AUTORIZADO con mensaje
				publicarmensaje(2);
				flujo_LCD2=19;//caso 19
				programarPPUID(2);//Se programa de una vez los PPU
				Buffer_LCD2.AutorizacionTrasCali=0x02;//Para evitar conflictos con las autorizaciones de Traslados o Calibracion
				Buffer_LCD2.Estado_Mux=0xA7;//Ya que se realizo la validacion, se deja en espera de una venta por contado control autorizada
				count_protector2=0;
			}else if(Buffer_LCD2.AutorizacionControl==0x00){//No Autorizado
				set_imagen(2,62);//SUMINISTRO NO AUTORIZADO1a
				publicarmensaje(2);
				flujo_LCD2=20;//caso 20
				Buffer_LCD2.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en modo espera Normal
				Buffer_LCD2.AutorizacionControl=0x02;//Para evitar conflictos mas adelante
				count_protector2=0;
			}
			if(count_protector2>=60){
                if(count_rf>5){
                    set_imagen(2,35);	//Sin sistema parcial
                }else{
                    set_imagen(2,27);	//Sin sistema total
                }
	            flujo_LCD2=100; 
			    count_protector2=0;
				Buffer_LCD2.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD2.AutorizacionControl=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
			
		case 19://Suministro autorizado
			if(LCD_2_GetRxBufferSize()==8){	
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                if(LCD_2_rxBuffer[3]==0x0D){//Atras
						Buffer_LCD2.Estado_Mux=0xA2;//Ya que se realizo la validacion y se cancelo antes de subir la manija, se deja en modo cancelo para esperar a resetear al estado espera A1
						programarPPUContado(2);//Se vuelve a programar el PPU con el original
						set_imagen(2,3);	//cancelada por pc
	            		flujo_LCD2=100; 
			    		count_protector2=0;
					}
				}
				CyDelay(20);
	            LCD_2_ClearRxBuffer();
			}
			if(count_protector2>=5){
				if(Buffer_LCD2.AutorizacionControl==0x01){
					if(Buffer_LCD2.PresetAutControl=='D'){
						set_imagen(2,29);//dinero full1a
						flujo_LCD2=21;//caso 21
						count_protector2=0;
					}else if(Buffer_LCD2.PresetAutControl=='V'){
						set_imagen(2,36);//volumen full
						flujo_LCD2=21;//caso 21
						count_protector2=0;
					}
				}else if(Buffer_LCD2.AutorizacionTrasCali==0x01){
					Buffer_LCD2.preset&=0xFC;
					if(Buffer_LCD2.PresetAutControl=='D'){
						Buffer_LCD2.preset|=2;
					}else if(Buffer_LCD2.PresetAutControl=='V'){
						Buffer_LCD2.preset|=1;
					}
					for(i=0;i<=Buffer_LCD2.ValorTanqueoControl[0];i++){
						Buffer_LCD2.valor[i]=Buffer_LCD2.ValorTanqueoControl[i];
						Buffer_LCD2.ValorPreset[i]=Buffer_LCD2.ValorTanqueoControl[i];
					}
					flujo_LCD2=24;      	//Caso 24
                	set_imagen(2,63);	//SUBA la manija
					Buffer_LCD2.PresetProgramado='F';
				}
		 	}
		break;
		
		case 20://Suministro NO autorizado
			if(LCD_2_GetRxBufferSize()==8){	
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                if(LCD_2_rxBuffer[3]==0x0D){//Atras
						set_imagen(2,10);	//gracias
	            		flujo_LCD2=100; 
			    		count_protector2=0;
					}
				}
				CyDelay(20);
	            LCD_2_ClearRxBuffer();
			}
			if(count_protector2>=15){
	            set_imagen(2,10);	//gracias
	            flujo_LCD2=100; 
			    count_protector2=0;
		 	}
		break;
			
		case 21://Seleccion de venta en dinero, volumen o full
			if(LCD_2_GetRxBufferSize()==8){	
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					Buffer_LCD2.preset&=0xFC;
					switch(LCD_2_rxBuffer[3]){
						case 0x15:				//Dinero
							set_imagen(2,15);	//Intro Valor
							flujo_LCD2=23;		//Case 23
							teclas2=0;                            	 //Inicia el contador de teclas  
							write_LCD(2,'$',0,0x37,0x00,0x40,0x00);
					  		Buffer_LCD2.preset|=2;
							Buffer_LCD2.PresetProgramado='D';
	                    break;
							
						case 0x16:				//Volumen
							set_imagen(2,13);	//intro galones1
							flujo_LCD2=23;       //Caso 23         
		                    teclas2=0;			//Inicia el contador de teclas
		                    comas2=0;
		                    write_LCD(2,'G',0,0x37,0x00,0x40,0x00);
							Buffer_LCD2.preset|=1;
							Buffer_LCD2.PresetProgramado='V';
	                    break;
							
						case 0x3C:				//Full
							if(Buffer_LCD2.FullAutControl=='F'){
								if(Buffer_LCD2.PresetAutControl=='D'){
									Buffer_LCD2.preset|=2;
								}else if(Buffer_LCD2.PresetAutControl=='V'){
									Buffer_LCD2.preset|=1;
								}
								for(i=0;i<=Buffer_LCD2.ValorTanqueoControl[0];i++){
									Buffer_LCD2.valor[i]=Buffer_LCD2.ValorTanqueoControl[i];
									Buffer_LCD2.ValorPreset[i]=Buffer_LCD2.ValorTanqueoControl[i];
								}
								flujo_LCD2=24;      	//Caso 24
	                        	set_imagen(2,63);	//SUBA la manija
								Buffer_LCD2.PresetProgramado='F';
							}else if(Buffer_LCD2.FullAutControl==0x00){
								flujo_LCD2=22;      	//Caso 22
								set_imagen(2,65);//excesos de cupo
								count_protector2=0;
							}
	                    break;
							
						case 0x0D:				//Atras
							set_imagen(2,11);//SUMINISTRO AUTORIZADO con mensaje
							publicarmensaje(2);
							flujo_LCD2=19;//caso 19
							Buffer_LCD2.Estado_Mux=0xA7;//Ya que se realizo la validacion, se deja en modo espera por Contado Control
							count_protector2=0;
	                    break;
					}
				}
	            CyDelay(20);
	            LCD_2_ClearRxBuffer();
			}
		break;
		
		case 22://Full no autorizado
			if(LCD_2_GetRxBufferSize()==8){	
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                if(LCD_2_rxBuffer[3]==0x0D){//Atras
						if(Buffer_LCD2.PresetAutControl=='D'){
							set_imagen(2,29);//dinero full1a
							flujo_LCD2=21;//caso 21
							count_protector2=0;
						}else if(Buffer_LCD2.PresetAutControl=='V'){
							set_imagen(2,36);//volumen full
							flujo_LCD2=21;//caso 21
							count_protector2=0;
						}
					}
				}
				CyDelay(20);
	            LCD_2_ClearRxBuffer();
			}
			if(count_protector2>=10){
				if(Buffer_LCD2.PresetAutControl=='D'){
					set_imagen(2,29);//dinero full1a
					flujo_LCD2=21;//caso 21
					count_protector2=0;
				}else if(Buffer_LCD2.PresetAutControl=='V'){
					set_imagen(2,36);//volumen full
					flujo_LCD2=21;//caso 21
					count_protector2=0;
				}
		 	}
		break;

		case 23://Digite valor a tanquear para Credito y Contado Control
			if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                if(teclas2<=(lado.c.versdig-1)){
	                    if(LCD_2_rxBuffer[3]<=9){
	                        teclas2++;
	                        Buffer_LCD2.valor[teclas2]=LCD_2_rxBuffer[3]+0x30;
							Buffer_LCD2.ValorPreset[teclas2]=LCD_2_rxBuffer[3]+0x30;
	                        write_LCD(2,(LCD_2_rxBuffer[3]+0x30),teclas2,0x37,0x00,0x40,0x00);
	                    }
	                    if(LCD_2_rxBuffer[3]==0x0A){            	//Comando de 0
	                        teclas2++;
	                        Buffer_LCD2.valor[teclas2]=0x30;
							Buffer_LCD2.ValorPreset[teclas2]=0x30;
	                        write_LCD(2,0x30,teclas2,0x37,0x00,0x40,0x00);
	                    }  
	                    if(LCD_2_rxBuffer[3]==0x4E){            	//Comando de Coma
	                        if(teclas2>=1 && comas2==0){
	                            teclas2++;
	                            Buffer_LCD2.valor[teclas2]=0x2C;
								Buffer_LCD2.ValorPreset[teclas2]=0x2C;
	                            write_LCD(2,0x2C,teclas2,0x37,0x00,0x40,0x00);
	                            comas2=1;
	                        }
	                    }
	                }
	                if(LCD_2_rxBuffer[3]==0x0B){					//DEL
	                    if(teclas2==0){								//Si no ha presionado nada regresa al menu anterior
							if(Buffer_LCD2.PresetAutControl=='D'){
								set_imagen(2,29);//dinero full1a
								flujo_LCD2=21;//caso 21
								count_protector2=0;
							}else if(Buffer_LCD2.PresetAutControl=='V'){
								set_imagen(2,36);//volumen full
								flujo_LCD2=21;//caso 21
								count_protector2=0;
							}
	                    }
	                    else{
	                        write_LCD(2,0x20,(teclas2),0x37,0x00,0x40,0x00);			//Si ya presiono borra el dato	
	                        if(Buffer_LCD2.valor[teclas2]==0x2C){
	                            comas2=0;
	                        }
	                        teclas2--;
	                    }
	                }
	                if(LCD_2_rxBuffer[3]==0x0C){					//ENT
	                    if(teclas2>=1){	
							Buffer_LCD2.valor[0]=teclas2;
							Buffer_LCD2.ValorPreset[0]=teclas2;
							if(Buffer_LCD2.PresetProgramado=='D'){
								Buffer_LCD2.preset_entero=0;
								Buffer_LCD2.max_din=0;
								for(x=Buffer_LCD2.valor[0];x>=1;x--){
									Buffer_LCD2.preset_entero+=((uint32)(Buffer_LCD2.valor[x]&0x0f)*pow(10,(Buffer_LCD2.valor[0]-x)));
								}
								for(x=Buffer_LCD2.ValorTanqueoControl[0];x>=1;x--){
									Buffer_LCD2.max_din+=((uint32)(Buffer_LCD2.ValorTanqueoControl[x]&0x0f)*pow(10,(Buffer_LCD2.ValorTanqueoControl[0]-x)));
								}
								if(Buffer_LCD2.preset_entero<=Buffer_LCD2.max_din){
									for(i=0;i<=Buffer_LCD2.ValorPreset[0];i++){
										Buffer_LCD2.valor[i]=Buffer_LCD2.ValorPreset[i];
									}
									flujo_LCD2=24;      	//Caso 24
		                        	set_imagen(2,63);	//SUBA la manija
								}else{
									set_imagen(2,65);//excesos de cupo
									CyDelay(400);
									set_imagen(2,15);	//Intro Valor
									teclas2=0;                            	 //Inicia el contador de teclas  
									write_LCD(2,'$',0,0x37,0x00,0x40,0x00);
							  		Buffer_LCD2.preset|=2;
									Buffer_LCD2.PresetProgramado='D';
								}
							}else if(Buffer_LCD2.PresetProgramado=='V'){
								Buffer_LCD2.preset_entero=0;
								Buffer_LCD2.max_volu=0;
								w=Buffer_LCD2.valor[0];
								for(x=Buffer_LCD2.valor[0];x>=1;x--){
									if(Buffer_LCD2.valor[x]!=0x2C){
										Buffer_LCD2.preset_entero+=((float)(Buffer_LCD2.valor[x]&0x0f)*pow(10,(w-x)));
									}else{
										if(Buffer_LCD2.preset_entero<10){
											Buffer_LCD2.preset_entero = Buffer_LCD2.preset_entero/10;
											w=w-2;
										}else if(Buffer_LCD2.preset_entero<100){
											Buffer_LCD2.preset_entero = Buffer_LCD2.preset_entero/100;
											w=w-3;
										}else if(Buffer_LCD2.preset_entero<1000){
											Buffer_LCD2.preset_entero = Buffer_LCD2.preset_entero/1000;
											w=w-4;
										}
									}
								}
								w=Buffer_LCD2.ValorTanqueoControl[0];
								for(x=Buffer_LCD2.ValorTanqueoControl[0];x>=1;x--){
									if(Buffer_LCD2.ValorTanqueoControl[x]!=0x2C){
										Buffer_LCD2.max_volu+=((float)(Buffer_LCD2.ValorTanqueoControl[x]&0x0f)*pow(10,(w-x)));
									}else{
										Buffer_LCD2.max_volu = Buffer_LCD2.max_volu/1000;
										w=w-4;
									}
								}
								if(Buffer_LCD2.preset_entero<=Buffer_LCD2.max_volu){
									for(i=0;i<=Buffer_LCD2.ValorPreset[0];i++){
										Buffer_LCD2.valor[i]=Buffer_LCD2.ValorPreset[i];
									}
									flujo_LCD2=24;      	//Caso 24
		                        	set_imagen(2,63);	//SUBA la manija
								}else{
									set_imagen(2,65);//excesos de cupo
									CyDelay(400);
									set_imagen(2,13);	//intro galones1
									teclas2=0;			//Inicia el contador de teclas
				                    comas2=0;
				                    write_LCD(2,'G',0,0x37,0x00,0x40,0x00);
									Buffer_LCD2.preset|=1;
									Buffer_LCD2.PresetProgramado='V';
								}
							}
							LCD_2_ClearRxBuffer();
	                    }
	                }
					if(LCD_2_rxBuffer[3]==0x0D){//Atras
						teclas2=0;
						if(Buffer_LCD2.PresetAutControl=='D'){
							set_imagen(2,29);//dinero full1a
							flujo_LCD2=21;//caso 21
							count_protector2=0;
						}else if(Buffer_LCD2.PresetAutControl=='V'){
							set_imagen(2,36);//volumen full
							flujo_LCD2=21;//caso 21
							count_protector2=0;
						}
						LCD_2_ClearRxBuffer();	
					}
	            }
	            CyDelay(20);            
	            LCD_2_ClearRxBuffer();
	        }
		break;

		case 24:	//Esperando a subir la manija para programar el equipo por sistema autorizado
	        if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                if(LCD_2_rxBuffer[3]==0x0D){//Cancel
						if(Buffer_LCD2.Estado_Mux==0xA7){//Si estaba en espera de una venta por contado control, credito, calibracion o traslados
							programarPPUContado(2);
							Buffer_LCD2.BanPPUid=0;
							Buffer_LCD2.Estado_Mux=0xA2;//...Se cancelo la operacion antes de subir la manija
						}
						set_imagen(2,0);	//animacion0
						flujo_LCD2=0;		//Caso 0
	                }	
				}
	            CyDelay(20);            
	            LCD_2_ClearRxBuffer();
				break;
			}
			if(get_estado(lado.b.dir)==7){//Espera a que este en listo el equipo
				Buffer_LCD2.Estado_Mux=0xA3;//Se subio la manija, despues de programar el equipo
				CyDelay(50);
				producto2=estado_ex(lado.b.dir);											//Obtiene el grado de la manguera
				if(producto2==Buffer_LCD2.NumManguera[1] || producto2==Buffer_LCD2.NumManguera[2] || producto2==Buffer_LCD2.NumManguera[3]){
					CyDelay(50);		
					if((Buffer_LCD2.preset&0x02)==0x02||(Buffer_LCD2.preset&0x01)==0x01){		//Dependiendo del preset hace la programación
						if(programar(lado.b.dir,producto2,Buffer_LCD2.valor,(Buffer_LCD2.preset&0x03))==0){
							programarPPUContado(2);
							Buffer_LCD2.Estado_Mux=0xA5;//Se cancelo la operacion despues de subir la manija
							set_imagen(2,3);	//cancelada por pc
							isr_4_StartEx(animacion2);
							Timer_Animacion2_Start();
							flujo_LCD2=100;		//Caso 100
							count_protector2=0;
							break;
						}
					}
					producto2=estado_ex(lado.b.dir);
					if(producto2!=0){
						if(get_totales(lado.b.dir)!=0){
							if(producto2==1){
								for(i=0;i<=Buffer_LCD2.TotalVolumen1[0];i++){
									Buffer_LCD2.TotalVolumenAnterior[i]=Buffer_LCD2.TotalVolumen1[i];
									Buffer_LCD2.TotalDineroAnterior[i]=Buffer_LCD2.TotalDinero1[i];
								}
							}else if(producto2==2){
								for(i=0;i<=Buffer_LCD2.TotalVolumen2[0];i++){
									Buffer_LCD2.TotalVolumenAnterior[i]=Buffer_LCD2.TotalVolumen2[i];
									Buffer_LCD2.TotalDineroAnterior[i]=Buffer_LCD2.TotalDinero2[i];
								}
							}else if(producto2==3){
								for(i=0;i<=Buffer_LCD2.TotalVolumen3[0];i++){
									Buffer_LCD2.TotalVolumenAnterior[i]=Buffer_LCD2.TotalVolumen3[i];
									Buffer_LCD2.TotalDineroAnterior[i]=Buffer_LCD2.TotalDinero3[i];
								}
							}
						}
						Surtidor_PutChar(0x10|lado.b.dir);//Autoriza el surtidor
					    flujo_LCD2=25;		//Caso 25
						set_imagen(2,20);	//tanqueando
						if(leer_fecha()==1){//Lectura de Fecha Inicial
							Buffer_LCD2.FechaInicialVenta[0]=14;
							Buffer_LCD2.FechaInicialVenta[1]=0x32;
							Buffer_LCD2.FechaInicialVenta[2]=0x30;
							Buffer_LCD2.FechaInicialVenta[3]=(((rventa.fecha[2]&0xF0)>>4)+48);
							Buffer_LCD2.FechaInicialVenta[4]=((rventa.fecha[2]&0x0F)+48);
							Buffer_LCD2.FechaInicialVenta[5]=(((rventa.fecha[1]&0x10)>>4)+48);
							Buffer_LCD2.FechaInicialVenta[6]=((rventa.fecha[1]&0x0F)+48);
							Buffer_LCD2.FechaInicialVenta[7]=(((rventa.fecha[0]&0x30)>>4)+48);
							Buffer_LCD2.FechaInicialVenta[8]=((rventa.fecha[0]&0x0F)+48);
							
						}
						if(leer_hora()==1){//Lectura de Hora Inicial	
							Buffer_LCD2.FechaInicialVenta[9]=(((rventa.hora[2]&0xF0)>>4)+48);	
							Buffer_LCD2.FechaInicialVenta[10]=((rventa.hora[2]&0x0F)+48);
							Buffer_LCD2.FechaInicialVenta[11]=(((rventa.hora[1]&0xF0)>>4)+48);
							Buffer_LCD2.FechaInicialVenta[12]=((rventa.hora[1]&0x0F)+48);
							Buffer_LCD2.FechaInicialVenta[13]=(((rventa.hora[0]&0xF0)>>4)+48);
							Buffer_LCD2.FechaInicialVenta[14]=((rventa.hora[0]&0x0F)+48);
						}
						LCD_1_ClearRxBuffer();
						PC_ClearRxBuffer();
					}
				}else{
					programarPPUContado(2);
					Buffer_LCD2.Estado_Mux=0xA2;//Se cancelo la operacion despues de subir la manija
					set_imagen(2,60);	//baje la manija
					flujo_LCD2=100;		//Caso 100
					count_protector2=0;
					LCD_1_ClearRxBuffer();
					break;
				}
        	}
		break;
			
		case 25://Tanqueando sin datos
            switch (get_estado(lado.b.dir)){
                case 0x09://Surtiendo
                    Buffer_LCD2.Estado_Mux=0xAC;//Surtiendo Combustible
                break;
                case 0x0B://Termino venta
                    set_imagen(2,8);	//esperando 1
    				if(venta(lado.b.dir,producto2)==1){
    					programarPPUContado(2);
    					if(Buffer_LCD2.IdentCliente[1]=='I'){
    						set_imagen(2,50);	//imprimiendo 4
    						flujo_LCD2=14;	//Caso 14
    						LCD_2_ClearRxBuffer();
    						isr_4_StartEx(animacion2);
    						Timer_Animacion2_Start();
    						count_protector2=0;
    						Buffer_LCD2.Impresionmux=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD2.BanImpFin=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD2.ConfirmacionImpresion='2';
    						Buffer_LCD2.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
                            for(x=0;x<=Buffer_LCD2.PlacaCliente[0];x++){
                                Buffer_LCD2.placa[x]=Buffer_LCD2.PlacaCliente[x];
    						}
    					}else if(Buffer_LCD2.placa[0]==0){//No digito placa
    						set_imagen(2,6);	//digite placa
    						flujo_LCD2=11;		//Caso 11
    						Buffer_LCD2.CompTeclado=8;
    						teclas2=0;
    					}else if(Buffer_LCD2.placa[0]>=1){//Si Digito Placa
    						set_imagen(2,50);	//imprimiendo 4
    						flujo_LCD2=14;	//Caso 14
    						LCD_2_ClearRxBuffer();
    						isr_4_StartEx(animacion2);
    						Timer_Animacion2_Start();
    						count_protector2=0;
    						Buffer_LCD2.Impresionmux=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD2.BanImpFin=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD2.ConfirmacionImpresion='2';
    						Buffer_LCD2.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
    					}
    				}
                break;
                case 0x0A://Termino venta
                    set_imagen(2,8);	//esperando 1
    				if(venta(lado.b.dir,producto2)==1){
    					programarPPUContado(2);
    					if(Buffer_LCD2.IdentCliente[1]=='I'){
    						set_imagen(2,50);	//imprimiendo 4
    						flujo_LCD2=14;	//Caso 14
    						LCD_2_ClearRxBuffer();
    						isr_4_StartEx(animacion2);
    						Timer_Animacion2_Start();
    						count_protector2=0;
    						Buffer_LCD2.Impresionmux=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD2.BanImpFin=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD2.ConfirmacionImpresion='2';
    						Buffer_LCD2.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
                            for(x=0;x<=Buffer_LCD2.PlacaCliente[0];x++){
                                Buffer_LCD2.placa[x]=Buffer_LCD2.PlacaCliente[x];
    						}
    					}else if(Buffer_LCD2.placa[0]==0){//No digito placa
    						set_imagen(2,6);	//digite placa
    						flujo_LCD2=11;		//Caso 11
    						Buffer_LCD2.CompTeclado=8;
    						teclas2=0;
    					}else if(Buffer_LCD2.placa[0]>=1){//Si Digito Placa
    						set_imagen(2,50);	//imprimiendo 4
    						flujo_LCD2=14;	//Caso 14
    						LCD_2_ClearRxBuffer();
    						isr_4_StartEx(animacion2);
    						Timer_Animacion2_Start();
    						count_protector2=0;
    						Buffer_LCD2.Impresionmux=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD2.BanImpFin=0x02;//Para evitar conflictos mas adelante
    						Buffer_LCD2.ConfirmacionImpresion='2';
    						Buffer_LCD2.Estado_Mux=0xA6;//Se bajo la manija, fin de la venta
    					}
    				}
                break;
                case 0x06://No hizo venta
                    Buffer_LCD2.Estado_Mux=0xA4;//No se realizo venta
    				flujo_LCD2=0;
    				programarPPUContado(2);
                break;
            }
		break;
			
		case 26://Esperando autorizacion para traslados o calibracion
			if(Buffer_LCD2.AutorizacionTrasCali==0x01){//Autorizado
				set_imagen(2,11);//SUMINISTRO AUTORIZADO con mensaje
				publicarmensaje(2);
				Buffer_LCD2.AutorizacionControl=0x02;//Para evitar conflictos con las autorizaciones de Credito o Contado Control
				flujo_LCD2=19;//caso 19
				programarPPUID(2);//Se programa de una vez los PPU
				Buffer_LCD2.Estado_Mux=0xA7;//Ya que se realizo la validacion, se deja en espera de una venta por contado control, credito, Calibracion o traslados autorizada
				count_protector2=0;
			}else if(Buffer_LCD2.AutorizacionTrasCali==0x00){//No Autorizado
				set_imagen(2,62);//SUMINISTRO NO AUTORIZADO1a
				publicarmensaje(2);
				flujo_LCD2=20;//caso 20
				Buffer_LCD2.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en modo espera Normal
				Buffer_LCD2.AutorizacionTrasCali=0x02;//Para evitar conflictos mas adelante
				count_protector2=0;
			}
			if(count_protector2>=60){
                if(count_rf>5){
                    set_imagen(2,35);	//Sin sistema parcial
                }else{
                    set_imagen(2,27);	//Sin sistema total
                }
	            flujo_LCD2=100; 
			    count_protector2=0;
				Buffer_LCD2.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD2.AutorizacionTrasCali=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
			
		case 27://Menu para Turnos
			if(LCD_2_GetRxBufferSize()==8){	 
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                switch(LCD_2_rxBuffer[3]){
	                    case 0x35:					//Apertura
							if(lado.d.turno==0 && Buffer_LCD1.Estado_Mux!=0xE1){			//Solo si esta cerrado el turno
								flujo_LCD2=28;		//Caso 28
								resetvariables(2);
								set_imagen(2,58);	//ID Turno
								write_psoc1(4,0);//Activo Lectura de Tarjeta
								LCD_2_ClearRxBuffer();
							}
	                    break;
							
						case 0x36:				//Cierre
							if(lado.d.turno==1 && Buffer_LCD1.Estado_Mux!=0xA3 && Buffer_LCD1.Estado_Mux!=0xAC && Buffer_LCD1.Estado_Mux!=0xE2){		//Solo si esta abierto el turno
								flujo_LCD2=32;		//Caso 32
								resetvariables(2);
								set_imagen(2,38);	//Confirmar Turno Sin sistema
								LCD_2_ClearRxBuffer();
							}
	                    break;
						
						case 0x41:				//Arqueo
							if(lado.d.turno==1 && Buffer_LCD1.Estado_Mux!=0xA3 && Buffer_LCD1.Estado_Mux!=0xAC){		//Solo si esta abierto el turno
								print_arqueo(print2[1]);
								count_protector2=41;
								set_imagen(2,17);	//momento de corte
								flujo_LCD2=34;		//Caso 34
								LCD_2_ClearRxBuffer();
								PC_ClearRxBuffer();
							}
	                    break;
						
						case 0x0D:				//Atras 
						  	flujo_LCD2=3;		//Caso 3
							set_imagen(2,51);	//menu distracom 1a
							LCD_2_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_2_ClearRxBuffer();
	        }
		break;
			
		case 28://Esperando ID del Vendedor para apertura de turno
			if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					 switch(LCD_2_rxBuffer[3]){
	                    case 0x10:				//Cedula
							flujo_LCD2=12;		//Caso 12
							teclas2=0;
							Buffer_LCD2.CompTeclado=7;
							set_imagen(2,68);	//digitenitcc
						break;
							
						case 0x0D:				//Atras
							flujo_LCD2=27;		//Caso 27 
							write_psoc1(4,1);	//Cancelo Lectura de Tarjeta
							set_imagen(2,22);	//APERTURA CIERRE ARQUEO1a
						break;
					}
				}
				CyDelay(20);            
	            LCD_2_ClearRxBuffer();
			}
			if(read_psoc1()==1){
				set_imagen(2,8);	//esperando 1
				for(i=1;i<=10;i++){
					Buffer_LCD2.id[i]=buffer_i2c[i];
				}
				Buffer_LCD2.id[0]=10;
				IdentVendedor[0]=Buffer_LCD2.id[0]+1;
				IdentVendedor[1]='T';
				for(i=0;i<=Buffer_LCD2.id[0];i++){
					IdentVendedor[i+2]=Buffer_LCD2.id[i+1];
				}
				flujo_LCD2=29;	//Caso 29
			}
			if(touch_present(2)==1){
				if(touch_write(2,0x33)){
					for(z=1;z<=8;z++){
						Buffer_LCD2.id[z]=touch_read_byte(2);
					}
					Checkibutton2=0;
					for(z=1;z<8;z++){
                        Checkibutton2=crc_check(Checkibutton2,Buffer_LCD2.id[z]);
                    }
					if(Checkibutton2==Buffer_LCD2.id[8]){
						Buffer_LCD2.id[0]=8;
						IdentVendedor[0]=17;
						IdentVendedor[1]='I';
						j=2;
						for(i=Buffer_LCD2.id[0];i>0;i--){
							if(((Buffer_LCD2.id[i]>>4)&0x0F)>=10){
								IdentVendedor[j]=((Buffer_LCD2.id[i]>>4)&0x0F)+55;
								j++;
							}
							else{
								IdentVendedor[j]=((Buffer_LCD2.id[i]>>4)&0x0F)+48;
								j++;				
							}
							if((Buffer_LCD2.id[i]&0x0F)>=10){
								IdentVendedor[j]=(Buffer_LCD2.id[i]&0x0F)+55;
								j++;
							}
							else{
								IdentVendedor[j]=(Buffer_LCD2.id[i]&0x0F)+48;
								j++;				
							}
						}
						set_imagen(2,8);	//esperando 1
						flujo_LCD2=29;	//Caso 29
					}
				}
			}
		break;
			
		case 29://Recopilando datos para apertura de turno
            write_eeprom(258,IdentVendedor);//Guarga ID del Vendedor
			DatosTurno();
			write_psoc1(4,1);	//Cancelo Lectura de Tarjeta
			Buffer_LCD2.Estado_Mux=0xE1;//Autorizacion para Apertura de Turno
			flujo_LCD2=30;	//Caso 30
			isr_4_StartEx(animacion2); 
         	Timer_Animacion2_Start();
         	count_protector2=0;
			Buffer_LCD2.AutorizacionApertTurno=0x02;
			PC_ClearRxBuffer();
            count_rf=0;
            Buffer_LCD2.recepcionrf=0;
		break;
			
		case 30://Esperando Autorizacion para Apertura de Turno
            if(count_rf>=20 && Buffer_LCD2.recepcionrf==0){//Si no hay recepcion del RF no se puede abrir el turno
                flujo_LCD2=100;//caso 100
    			count_protector2=0;
                set_imagen(2,35);//Sin sistema total
                Buffer_LCD2.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD2.AutorizacionApertTurno=0x02;//Para evitar conflictos al hacer una nueva validacion
                break;
            }
			if(Buffer_LCD2.AutorizacionApertTurno==0x01){//Autorizado
				AbrirTurno();
				set_imagen(2,55);//TURNO ABIERTO
				Buffer_LCD2.AutorizacionApertTurno=0x02;//Para evitar conflictos con las autorizaciones de Credito o Contado Control
				Buffer_LCD2.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en espera
				flujo_LCD2=100;//caso 100
				count_protector2=0;
			}else if(Buffer_LCD2.AutorizacionApertTurno==0x00){//No Autorizado
				set_imagen(2,62);//SUMINISTRO NO AUTORIZADO1a
				publicarmensaje(2);
				flujo_LCD2=20;//caso 20
				Buffer_LCD2.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en modo espera Normal
				Buffer_LCD2.AutorizacionApertTurno=0x02;//Para evitar conflictos mas adelante
				count_protector2=0;
			}
			if(count_protector2>=60){
				set_imagen(2,40);	//Turno abierto sin sistema
	            flujo_LCD2=31;
				Buffer_LCD2.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD2.AutorizacionApertTurno=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
			
		case 31://Abrir turno sin sistema
			NombreVendedor[0]=20;
			for(x=0;x<=19;x++){
				NombreVendedor[x+1]=msn_Vendedor[x];
			}
			CedulaVendedor[0]=IdentVendedor[0]-1;
            if(CedulaVendedor[0]>10){
                CedulaVendedor[0]=10;
            }
            for(x=1;x<=CedulaVendedor[0];x++){
			    CedulaVendedor[x]=IdentVendedor[x+1];
		    }
			AbrirTurno();
	        set_imagen(2,40);	//Turno abierto sin sistema
			flujo_LCD2=100;//caso 100
			count_protector2=0;
			PC_ClearRxBuffer();
		break;
			
		case 32://Confirmacion para cierre de Turno
			if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					 switch(LCD_2_rxBuffer[3]){
	                    case 0x13:				//SI
							set_imagen(2,8);	//esperando 1
							DatosTurno();
							flujo_LCD2=33;		//Caso 33
							for(x=0;x<=FechaInicialTurno[0];x++){
								FechaFinalTurno[x]=FechaInicialTurno[x];
							}
							isr_4_StartEx(animacion2);
				         	Timer_Animacion2_Start();
				         	count_protector2=0;
							Buffer_LCD2.Estado_Mux=0xE2;//Autorizacion para cierre de Turno
							Buffer_LCD2.BanImpFin=0x02;//Para evitar conflictos mas adelante
							Buffer_LCD2.AutorizacionCierreTurno=0x02;//Para evitar conflictos mas adelante
							PC_ClearRxBuffer();
                            count_rf=0;
                            Buffer_LCD2.recepcionrf=0;
						break;
						
						case 0x14:				//NO
							flujo_LCD2=0;		//Caso 0
							set_imagen(2,30);	//animacion1
						break;
						
						case 0x0D:				//Atras
							flujo_LCD2=0;		//Caso 0
							set_imagen(2,30);	//animacion1
						break;
					}
				}
				CyDelay(20);            
	            LCD_2_ClearRxBuffer();
			}
		break;
			
		case 33://Esperando Autorizacion para Cierre de Turno
            if(count_rf>=20  && Buffer_LCD2.recepcionrf==0){//Si no hay recepcion del RF no se puede cerrar el turno
                flujo_LCD2=100;//caso 100
    			count_protector2=0;
                set_imagen(2,35);//Sin sistema total
                Buffer_LCD2.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD2.AutorizacionApertTurno=0x02;//Para evitar conflictos al hacer una nueva validacion
                break;
            }
			if(Buffer_LCD2.AutorizacionCierreTurno==0x01){//Autorizado
                IdentVendedor[0]=1;
                for(x=1;x<=19;x++){
                    IdentVendedor[x]=0;
                }
                write_eeprom(258,IdentVendedor);//Guarga ID del Vendedor seteado
				set_imagen(2,50);//imprimiendo 4
				Buffer_LCD2.AutorizacionCierreTurno=0x02;//Para evitar conflictos con las autorizaciones de Credito o Contado Control
				Buffer_LCD2.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en espera
				write_eeprom(302,FechaFinalTurno);//Guarga la fecha de cierre
				CerrarTurno[0]=1;
				CerrarTurno[1]=0;
				lado.d.turno=0;
				write_eeprom(256,CerrarTurno);//Guarga que el turno esta cerrado
				flujo_LCD2=34;//caso 34
				count_protector2=0;
			}else if(Buffer_LCD2.AutorizacionCierreTurno==0x00){//No Autorizado
				set_imagen(2,62);//SUMINISTRO NO AUTORIZADO1a
				publicarmensaje(2);
				flujo_LCD2=20;//caso 20
				Buffer_LCD2.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en modo espera Normal
				Buffer_LCD2.AutorizacionCierreTurno=0x02;//Para evitar conflictos mas adelante
				count_protector2=0;
			}
			if(count_protector2>=60){
                IdentVendedor[0]=1;
                for(x=1;x<=19;x++){
                    IdentVendedor[x]=0;
                }
                write_eeprom(258,IdentVendedor);//Guarga ID del Vendedor seteado
	            set_imagen(2,50);	//imprimiendo 4
	            flujo_LCD2=34;
				Buffer_LCD2.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				write_eeprom(302,FechaFinalTurno);//Guarga la fecha de cierre
				CerrarTurno[0]=1;
				CerrarTurno[1]=0;
				lado.d.turno=0;
				write_eeprom(256,CerrarTurno);//Guarga que el turno esta cerrado
				Buffer_LCD2.AutorizacionCierreTurno=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
			
		case 34://Esperando trama de impresion para cierre de turno
			if(count_protector2>=40){//Si no llega nada imprime un Corte predeterminado
				print_logo(print2[1]);
				imprimir_corte(print2[1]);
				set_imagen(2,10);	//gracias
	            flujo_LCD2=0; 
			    count_protector2=0;
			}else if(Buffer_LCD2.BanImpFin==0x01){//Cuando finaliza la trama de impresion por sistema
				set_imagen(2,10);	//gracias
	            flujo_LCD2=0; 
			    count_protector2=0;
			}
		break;
			
		case 35://Menu de canastilla
			if(LCD_2_GetRxBufferSize()==8){	 
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                switch(LCD_2_rxBuffer[3]){
	                    case 0x39:				//Credito
							resetvariables(2);
							resetvariableslcd(2);
							set_imagen(2,52);	//METODO ID
							flujo_LCD2=36;		//Caso 36
							Buffer_LCD2.TipodeVentaCanasta='1';
							Buffer_LCD2.BandAutorCredCanasta=1;//Para en caso de reconocer productos no afecte el estado del mux
	                    break;                
	                    
						case 0x37:				//Efectivo
							resetvariables(2);
							resetvariableslcd(2);
							set_imagen(2,69);	//Canastilla
							LCD_Canastilla(2);
							flujo_LCD2=39;		//Caso 39
							Buffer_LCD2.TipodeVentaCanasta='0';
							Buffer_LCD2.BandAutorCredCanasta=0;//Para en caso de reconocer productos no afecte el estado del mux
	                    break;
						
						case 0x0D:				//Atras 
							set_imagen(2,51);	//menu distracom 1a 
						  	flujo_LCD2=3;		//Caso 3
							LCD_2_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_2_ClearRxBuffer();
	        }
			for(x=0;x<10;x++){                   
				Buffer_LCD2.ValorCupoCanasta[x]=0;	//Borro variable credito
			}
		break;
			
		case 36://Venta Canastilla de Credito
			if(LCD_2_GetRxBufferSize()==8){	
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                switch(LCD_2_rxBuffer[3]){
	                    case 0x45:				//CC/NIT
							set_imagen(2,68);	//digitenitcc
							flujo_LCD2=12;		//Caso 12
							teclas2=0;
							Buffer_LCD2.CompTeclado=20;
	                    break;
	                    
	                    case 0x0E:				//Placa
	                      	set_imagen(2,6);	//digite placa
							flujo_LCD2=10;		//Caso 10
							teclas2=0;
							Buffer_LCD2.CompTeclado=21;
	                    break;

	                    case 0x47:				//iButton
	                    	set_imagen(2,9);	//esperando id
							flujo_LCD2=16;		//Caso 16
							Buffer_LCD2.CompID=22;
	                    break;
						
						case 0x48:				//N° Fuel Control
	                    	set_imagen(2,37);	//digite numero copias
							flujo_LCD2=12;		//Caso 12
							teclas2=0;
							Buffer_LCD2.CompTeclado=23;
	                    break;
						
						case 0x49:				//RF ID
	                    	set_imagen(2,66);	//esperando rfid
							flujo_LCD2=17;		//Caso 17
							Buffer_LCD2.CompID=24;
							write_psoc1(4,0);//Activo Lectura de Tarjeta
	                    break;
                            
						case 0x4A:				//Pistola codigo de barras
                            Pistola_ClearRxBuffer();
	                      	set_imagen(2,1);//codigo de barras
							flujo_LCD2=45;
                            Buffer_LCD2.CompID=25;
	                    break;
                            
	                    case 0x0D:				//Atras
						  	flujo_LCD2=35;		//Caso 35
							set_imagen(2,71);	//CONTADO CREDITO
							LCD_2_ClearRxBuffer();
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_2_ClearRxBuffer();
	        }
			Buffer_LCD2.KmID[0]=1;
			Buffer_LCD2.KmID[1]='0';
		break;
			
		case 37://Esperando Autorizacion para Venta de Canastilla en Credito
			if(Buffer_LCD2.AutorizacionCreditoCanasta==0x01){//Autorizado
				set_imagen(2,11);//SUMINISTRO AUTORIZADO con mensaje
				publicarmensaje(2);
				flujo_LCD2=38;//caso 38
				Buffer_LCD2.Estado_Mux=0xAB;//Ya que se realizo la validacion, queda en espera de una venta por canastilla crédito autorizada
				Buffer_LCD2.BandAutorCredCanasta=1;//Para en caso de reconocer productos no afecte el estado del mux
				count_protector2=0;
			}else if(Buffer_LCD2.AutorizacionCreditoCanasta==0x00){//No Autorizado
				set_imagen(2,62);//SUMINISTRO NO AUTORIZADO1a
				publicarmensaje(2);
				flujo_LCD2=20;//caso 20
				Buffer_LCD2.Estado_Mux=0xA1;//Ya que se realizo la validacion, se deja en modo espera Normal
				Buffer_LCD2.BandAutorCredCanasta=0;//Para en caso de reconocer productos no afecte el estado del mux
				Buffer_LCD2.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos mas adelante
				count_protector2=0;
			}
			if(count_protector2>=60){
                if(count_rf>5){
                    set_imagen(2,35);	//Sin sistema parcial
                }else{
                    set_imagen(2,27);	//Sin sistema total
                }
	            flujo_LCD2=100; 
			    count_protector2=0;
				Buffer_LCD2.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				Buffer_LCD2.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
			
		case 38://Suministro autorizado de canastilla
			if(LCD_2_GetRxBufferSize()==8){	
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                if(LCD_2_rxBuffer[3]==0x0D){//Atras
						Buffer_LCD2.Estado_Mux=0xFC;//Ya que se realizo la validacion y se cancelo la operacion, se deja en modo cancelo para esperar a resetear al estado espera A1
						set_imagen(2,3);	//cancelada por pc
	            		flujo_LCD2=100; 
			    		count_protector2=0;
					}
				}
				CyDelay(20);
	            LCD_2_ClearRxBuffer();
			}
			if(count_protector2>=5){
				set_imagen(2,69);//Canastilla
				LCD_Canastilla(2);
				flujo_LCD2=39;
		 	}
		break;
		
		case 39://Formulario de Canastilla
			if(LCD_2_GetRxBufferSize()==8){	 
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                switch(LCD_2_rxBuffer[3]){
	                    case 0x19://Producto 1
							Pistola_ClearRxBuffer();
							set_imagen(2,1);//codigo de barras
							Buffer_LCD2.ProductoCanasta=1;
							flujo_LCD2=40;
							for(x=0;x<=20;x++){
								Buffer_LCD2.MensajeProducto[x]=Buffer_LCD2.NombreProducto1Canasta[x];
							}
							publicmenprod(2);
	                    break;                
	                    
						case 0x4F://Cant 1
							set_imagen(2,37);	//digite numero
							Buffer_LCD2.CompTeclado=31;
							flujo_LCD2=12;
							teclas2=0;
	                    break;
													
						case 0x53://Cancelar 1
							Buffer_LCD2.CantProducto1Canasta[0]=0;
							Buffer_LCD2.ValorProducto1Orig=0;
							Buffer_LCD2.NombreProducto1Canasta[0]=0;
							for(i=1;i<=20;i++){//Producto1
								Buffer_LCD2.NombreProducto1Canasta[i]='-';
								Buffer_LCD2.CodigoProductoCanasta1[i]=0;
								Buffer_LCD2.CodigoProductoCanasta1[0]=0;
							}
							set_imagen(2,69);	//Canastilla
							LCD_Canastilla(2);
	                    break;
						
	                    case 0x1A://Producto 2
							Pistola_ClearRxBuffer();
							set_imagen(2,1);//codigo de barras
							Buffer_LCD2.ProductoCanasta=2;
							flujo_LCD2=40;
							for(x=0;x<=20;x++){
								Buffer_LCD2.MensajeProducto[x]=Buffer_LCD2.NombreProducto2Canasta[x];
							}
							publicmenprod(2);
	                    break;
							
						case 0x50://Cant 2
	                      	set_imagen(2,37);	//digite numero
							Buffer_LCD2.CompTeclado=32;
							flujo_LCD2=12;
							teclas2=0;
	                    break;
						
						case 0x54://Cancelar 2
	                      	Buffer_LCD2.CantProducto2Canasta[0]=0;
							Buffer_LCD2.ValorProducto2Orig=0;
							Buffer_LCD2.NombreProducto2Canasta[0]=0;
							for(i=1;i<=20;i++){//Producto1
								Buffer_LCD2.NombreProducto2Canasta[i]='-';
								Buffer_LCD2.CodigoProductoCanasta2[i]=0;
								Buffer_LCD2.CodigoProductoCanasta2[0]=0;
							}
							set_imagen(2,69);	//Canastilla
							LCD_Canastilla(2);
	                    break;
						
						case 0x2E://Producto 3
							Pistola_ClearRxBuffer();
	                      	set_imagen(2,1);//codigo de barras
							Buffer_LCD2.ProductoCanasta=3;
							flujo_LCD2=40;
							for(x=0;x<=20;x++){
								Buffer_LCD2.MensajeProducto[x]=Buffer_LCD2.NombreProducto3Canasta[x];
							}
							publicmenprod(2);
	                    break;
						
						case 0x51://Cant 3
	                      	set_imagen(2,37);	//digite numero
							Buffer_LCD2.CompTeclado=33;
							flujo_LCD2=12;
							teclas2=0;
	                    break;
						
						case 0x55://Cancelar 3
	                      	Buffer_LCD2.CantProducto3Canasta[0]=0;
							Buffer_LCD2.ValorProducto3Orig=0;
							Buffer_LCD2.NombreProducto3Canasta[0]=0;
							for(i=1;i<=20;i++){//Producto1
								Buffer_LCD2.NombreProducto3Canasta[i]='-';
								Buffer_LCD2.CodigoProductoCanasta3[i]=0;
								Buffer_LCD2.CodigoProductoCanasta3[0]=0;
							}
							set_imagen(2,69);	//Canastilla
							LCD_Canastilla(2);
	                    break;
						
						case 0x3A://Producto 4
							Pistola_ClearRxBuffer();
	                      	set_imagen(2,1);//codigo de barras
							Buffer_LCD2.ProductoCanasta=4;
							flujo_LCD2=40;
							for(x=0;x<=20;x++){
								Buffer_LCD2.MensajeProducto[x]=Buffer_LCD2.NombreProducto4Canasta[x];
							}
							publicmenprod(2);
	                    break;
						
						case 0x52://Cant 4
	                      	set_imagen(2,37);	//digite numero
							Buffer_LCD2.CompTeclado=34;
							flujo_LCD2=12;
							teclas2=0;
	                    break;
						
						case 0x56://Cancelar 4
	                      	Buffer_LCD2.CantProducto4Canasta[0]=0;
							Buffer_LCD2.ValorProducto4Orig=0;
							Buffer_LCD2.NombreProducto4Canasta[0]=0;
							for(i=1;i<=20;i++){//Producto1
								Buffer_LCD2.NombreProducto4Canasta[i]='-';
								Buffer_LCD2.CodigoProductoCanasta4[i]=0;
								Buffer_LCD2.CodigoProductoCanasta4[0]=0;
							}
							set_imagen(2,69);	//Canastilla
							LCD_Canastilla(2);
	                    break;
						
						case 0x0C://Aceptar
							if(leer_fecha()==1){						//Lectura de Fecha Final
								Buffer_LCD2.FechaVentaCanastilla[0]=14;
								Buffer_LCD2.FechaVentaCanastilla[1]=0x32;
								Buffer_LCD2.FechaVentaCanastilla[2]=0x30;
								Buffer_LCD2.FechaVentaCanastilla[3]=(((rventa.fecha[2]&0xF0)>>4)+48);
								Buffer_LCD2.FechaVentaCanastilla[4]=((rventa.fecha[2]&0x0F)+48);
								Buffer_LCD2.FechaVentaCanastilla[5]=(((rventa.fecha[1]&0x10)>>4)+48);
								Buffer_LCD2.FechaVentaCanastilla[6]=((rventa.fecha[1]&0x0F)+48);
								Buffer_LCD2.FechaVentaCanastilla[7]=(((rventa.fecha[0]&0x30)>>4)+48);
								Buffer_LCD2.FechaVentaCanastilla[8]=((rventa.fecha[0]&0x0F)+48);
							}
							if(leer_hora()==1){							//Lectura de Hora Final	
								Buffer_LCD2.FechaVentaCanastilla[9]=(((rventa.hora[2]&0xF0)>>4)+48);	
								Buffer_LCD2.FechaVentaCanastilla[10]=((rventa.hora[2]&0x0F)+48);
								Buffer_LCD2.FechaVentaCanastilla[11]=(((rventa.hora[1]&0xF0)>>4)+48);
								Buffer_LCD2.FechaVentaCanastilla[12]=((rventa.hora[1]&0x0F)+48);
								Buffer_LCD2.FechaVentaCanastilla[13]=(((rventa.hora[0]&0xF0)>>4)+48);
								Buffer_LCD2.FechaVentaCanastilla[14]=((rventa.hora[0]&0x0F)+48);
							}
	                      	if(Buffer_LCD2.TipodeVentaCanasta=='1'){
								if(Buffer_LCD2.ValorProductoTotal>0){
									if(Buffer_LCD2.ValorProductoTotal>Buffer_LCD2.ValorCupoCanastaOri){
										set_imagen(2,65);//excesos de cupo
										CyDelay(300);
										set_imagen(2,69);	//Canastilla
										LCD_Canastilla(2);
									}else{
										set_imagen(2,8);	//esperando 1
										flujo_LCD2=42;
										isr_4_StartEx(animacion2);
							         	Timer_Animacion2_Start();
							         	count_protector2=0;
										Buffer_LCD2.Estado_Mux=0xA8;//Fin de la venta de Canastilla
										Buffer_LCD2.AutorizacionVentaCanasta=0x02;//Para evitar conflictos mas adelante
									}
								}
							}else{
								if(Buffer_LCD2.ValorProductoTotal>0){
									set_imagen(2,8);	//esperando 1
									flujo_LCD2=42;
									isr_4_StartEx(animacion2);
						         	Timer_Animacion2_Start();
						         	count_protector2=0;
									Buffer_LCD2.Estado_Mux=0xA8;//Fin de la venta de Canastilla
									Buffer_LCD2.AutorizacionVentaCanasta=0x02;//Para evitar conflictos mas adelante
								}
							}
	                    break;
						
						case 0x0D://Atras
							if(Buffer_LCD2.TipodeVentaCanasta=='1'){//Credito
								set_imagen(2,11);//SUMINISTRO AUTORIZADO con mensaje
								publicarmensaje(2);
								flujo_LCD2=38;//caso 38
								count_protector2=0;
							}else if(Buffer_LCD2.TipodeVentaCanasta=='0'){//Efectivo
								set_imagen(2,71);	//CONTADO CREDITO
								flujo_LCD2=35;//caso 35
							}
	                    break;
	                }
	            }
	            CyDelay(20);
	            LCD_2_ClearRxBuffer();
	        }
		break;
			
		case 40://Lectura de codigo de barras
			if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					if(LCD_2_rxBuffer[3]==0x0D){//Atras
						set_imagen(2,69);	//Canastilla
						flujo_LCD2=39;	//caso 39
						LCD_Canastilla(2);
					}
				}
				CyDelay(20);            
	            LCD_2_ClearRxBuffer();
			}
			if(codigodebarras()==1){
				if(Buffer_LCD2.ProductoCanasta==1){//Producto 1
					for(x=0;x<=Rx_Pistola[0];x++){
						Buffer_LCD2.CodigoProductoCanasta1[x]=Rx_Pistola[x];
					}
				}else if(Buffer_LCD2.ProductoCanasta==2){//Producto 2
					for(x=0;x<=Rx_Pistola[0];x++){
						Buffer_LCD2.CodigoProductoCanasta2[x]=Rx_Pistola[x];
					}
				}else if(Buffer_LCD2.ProductoCanasta==3){//Producto 3
					for(x=0;x<=Rx_Pistola[0];x++){
						Buffer_LCD2.CodigoProductoCanasta3[x]=Rx_Pistola[x];
					}
				}else if(Buffer_LCD2.ProductoCanasta==4){//Producto 4
					for(x=0;x<=Rx_Pistola[0];x++){
						Buffer_LCD2.CodigoProductoCanasta4[x]=Rx_Pistola[x];
					}
				}
				set_imagen(2,8);//esperando 1
				flujo_LCD2=41;	//caso 41
				Buffer_LCD2.Estado_Mux=0xFD;//Espera reconocimiento de un producto de Canastilla
				Buffer_LCD2.ReconocimientoProducto=0x02;//Para evitar conflictos al hacer una nueva validacion
				isr_4_StartEx(animacion2);
	         	Timer_Animacion2_Start();
	         	count_protector2=0;
			}
		break;
			
		case 41://Esperando reconocimiento de producto canastilla
			if(Buffer_LCD2.ReconocimientoProducto==0x01){//Producto reconocido
				if(Buffer_LCD2.BandAutorCredCanasta==1){
					Buffer_LCD2.Estado_Mux=0xAB;//esta en espera de una venta por Canastilla en Credito
				}else{
					Buffer_LCD2.Estado_Mux=0xA1;//esta en espera 
				}
				set_imagen(2,69);	//Canastilla
				LCD_Canastilla(2);
	            flujo_LCD2=39;
				Buffer_LCD2.ReconocimientoProducto=0x02;//Para evitar conflictos al hacer una nueva validacion
			}
			if(count_protector2>=40){
				if(Buffer_LCD2.BandAutorCredCanasta==1){
					Buffer_LCD2.Estado_Mux=0xAB;//esta en espera de una venta por Canastilla en Credito
				}else{
					Buffer_LCD2.Estado_Mux=0xA1;//esta en espera 
				}
	            set_imagen(2,69);	//Canastilla
				LCD_Canastilla(2);
	            flujo_LCD2=39; 
			    count_protector2=0;
				Buffer_LCD2.ReconocimientoProducto=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
			
		case 42://Esperando aprobacion para fin de venta de canastilla
			if(Buffer_LCD2.AutorizacionVentaCanasta==0x01){//Autorizado
				set_imagen(2,50);//imprimiendo 4
				flujo_LCD2=100;//caso 38
				count_protector2=0;
				Buffer_LCD2.AutorizacionVentaCanasta=0x02;
			}
			if(count_protector2>=90){
	            set_imagen(2,35);	//Sin sistema total
	            flujo_LCD2=100; 
			    count_protector2=0;
				if(Buffer_LCD2.Estado_Mux==0xAB){
					Buffer_LCD2.Estado_Mux=0xFC;
				}else{
					Buffer_LCD2.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
				}
				Buffer_LCD2.AutorizacionVentaCanasta=0x02;//Para evitar conflictos al hacer una nueva validacion
		 	}
		break;
            
        case 43://Esperando impresion de ultima venta
            if(Buffer_LCD2.impresionultimaventa==0x01){//Autorizado
				set_imagen(2,50);	//imprimiendo 4
				flujo_LCD2=100; 
			    count_protector2=0;
				Buffer_LCD2.Estado_Mux=0xA1;//el modulo queda en espera
                Buffer_LCD2.impresionultimaventa=0x00;
			}
			if(count_protector2>=25){
	            set_imagen(2,50);	//imprimiendo 4
                if(impresion2==1){
                    print_logo(print2[1]);
    				imprimir(print2[1], producto2,0,lado.b.dir);
                    if(Buffer_LCD2.ConfirmacionImpresion=='2' && Buffer_LCD2.TipodeVenta=='0'){
                        print_logo(print2[1]);
        				imprimir(print2[1], producto2,0,lado.b.dir);
                    }
    				if(Buffer_LCD2.TipodeVenta=='1' || Buffer_LCD2.TipodeVenta=='2'){
    					print_logo(print2[1]);
    					imprimir(print2[1], producto2,1,lado.b.dir);
    				}  
                }else{
                    print_logo(print1[1]);
    				imprimir(print1[1], producto2,0,lado.b.dir);
                    if(Buffer_LCD2.ConfirmacionImpresion=='2' && Buffer_LCD2.TipodeVenta=='0'){
                        print_logo(print1[1]);
        				imprimir(print1[1], producto2,0,lado.b.dir);
                    }
    				if(Buffer_LCD2.TipodeVenta=='1' || Buffer_LCD2.TipodeVenta=='2'){
    					print_logo(print1[1]);
    					imprimir(print1[1], producto2,1,lado.b.dir);
    				}
                }
                impresion2=0;
                set_imagen(2,10);	//gracias
	            flujo_LCD2=100; 
			    count_protector2=0;
				Buffer_LCD2.Estado_Mux=0xA1;//Si no hay sistema, el modulo queda en espera
                Buffer_LCD2.impresionultimaventa=0x00;
		 	}
        break;
            
        case 44://Informacion de mux
            /*-------------HORA EN TIEMPO REAL---------------*/
            leer_hora();
            write_LCD(2,((rventa.hora[2]&0xF0)>>4)+48,1,100,1,185,0);
            write_LCD(2,(rventa.hora[2]&0x0F)+48,2,100,1,185,0);
            write_LCD(2,':',3,100,1,185,0);
            write_LCD(2,((rventa.hora[1]&0xF0)>>4)+48,4,100,1,185,0);
            write_LCD(2,(rventa.hora[1]&0x0F)+48,5,100,1,185,0);
            write_LCD(2,':',6,100,1,185,0);
            write_LCD(2,((rventa.hora[0]&0xF0)>>4)+48,1,1,2,185,0);
            write_LCD(2,(rventa.hora[0]&0x0F)+48,2,1,2,185,0);
            /*-------------HORA EN TIEMPO REAL---------------*/
            
            if(LCD_2_GetRxBufferSize()==8){	 
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
	                if(LCD_2_rxBuffer[3]==0x0D){//Atras
                        set_imagen(2,0);
                        flujo_LCD2=0;		//Caso 0
						LCD_2_ClearRxBuffer();
                    }
	            }
	            CyDelay(20);
	            LCD_2_ClearRxBuffer();
	        }
        break;
            
        case 45://Lectura Codigo de Barras Cliente
            if(LCD_2_GetRxBufferSize()==8){
	            if((LCD_2_rxBuffer[0]==0xAA) && (LCD_2_rxBuffer[6]==0xC3) && (LCD_2_rxBuffer[7]==0x3C)){
					if(LCD_2_rxBuffer[3]==0x0D){//Atras
                        if(Buffer_LCD2.CompID==3){
                            set_imagen(2,52);	//METODO ID
    						flujo_LCD2=15;	//caso 15
                            Buffer_LCD2.CompID=0;
                        }else if(Buffer_LCD2.CompID==25){
                            set_imagen(2,52);	//METODO ID
						    flujo_LCD2=36;	//caso 15
                            Buffer_LCD2.CompID=0;
                        }
					}
				}
				CyDelay(20);            
	            LCD_2_ClearRxBuffer();
			}
			if(codigodebarras()==1){
				for(x=1;x<=Rx_Pistola[0];x++){
					Buffer_LCD2.IdentCliente[x+1]=Rx_Pistola[x];
				}
                Buffer_LCD2.IdentCliente[0]=Rx_Pistola[0]+1;
                Buffer_LCD2.IdentCliente[1]='B';
                if(Buffer_LCD2.CompID==3){
                    Buffer_LCD2.Estado_Mux=0xB1;//Autorizacion para Venta por Contado Control o credito
    				Buffer_LCD2.AutorizacionControl=0x02;//Para evitar conflictos con la autorizacion
    				set_imagen(2,8);	//esperando 1
    				flujo_LCD2=18;	//Caso 18
    				Buffer_LCD2.CompID=0;
    				isr_4_StartEx(animacion2); 
    	         	Timer_Animacion2_Start();
    	         	count_protector2=0;
                }else if(Buffer_LCD2.CompID==25){
                    Buffer_LCD2.Estado_Mux=0xF7;//Autorizacion para Venta Canastilla credito
                    Buffer_LCD2.AutorizacionCreditoCanasta=0x02;//Para evitar conflictos con la autorizacion
					set_imagen(2,8);	//esperando 1
					flujo_LCD2=37;	//Caso 37
					Buffer_LCD2.CompID=0;
					isr_4_StartEx(animacion2); 
		         	Timer_Animacion2_Start();
		         	count_protector2=0;
                }
			}
        break;
	}
}


/*
************************************************************************************************************
*                                         void polling_compararVar()
*
* Description : Compara si alguna variable se ha cambiado para releerla de la EPROMM
*               
*
* Argument(s) : 	
*
* Return(s)   : none
*
* Caller(s)   : En cualquier momento que el CDG desee imprimir
*
* Note(s)     : none.
************************************************************************************************************
*/
void polling_compararVar(void){
	if(lado.c.versdig==5 || lado.c.versdig==6 || lado.c.versdig==7){
		
	}else{
		leer_eeprom(192,2);
		lado.c.versdig=buffer_i2c[1]&0x07;
        if(lado.c.versdig==5 || lado.c.versdig==6 || lado.c.versdig==7){
        
        }else{
            lado.c.versdig=6;
        }
	}
}

/*
************************************************************************************************************
*                                         void polling_recuperarventas()
*
* Description : Revisa si hay una venta pendiente por recuperar
*               
*
* Argument(s) : 	
*
* Return(s)   : none
*
* Caller(s)   : En el momento en que se resetee una venta por sistema
*
* Note(s)     : none.
************************************************************************************************************
*/
void polling_recuperarventas(void){
	if(Checkventa1==1){
		isr_3_Stop(); 
		Timer_Animacion_Stop(); 
		set_imagen(1,39);//Recuperando ventas
        if(Buffer_LCD1.VentasPendientesE>0){
            RecuperarVentas(lado.a.dir,2);
        }else{
            RecuperarVentas(lado.a.dir,1);
        }
		flujo_LCD=100;
		isr_3_StartEx(animacion);
		Timer_Animacion_Start();
	    count_protector=2;
		Buffer_LCD1.Estado_Mux=0xA6;
		Checkventa1=0;
		PC_ClearRxBuffer();
	}
	if(Checkventa2==1){
		isr_4_Stop(); 
		Timer_Animacion2_Stop();
		set_imagen(2,39);//Recuperando ventas
        if(Buffer_LCD2.VentasPendientesE>0){
            RecuperarVentas(lado.b.dir,2);
        }else{
            RecuperarVentas(lado.b.dir,1);
        }
		flujo_LCD2=100;
		isr_4_StartEx(animacion2);
		Timer_Animacion2_Start();
        count_protector2=2;
		Buffer_LCD2.Estado_Mux=0xA6;
		Checkventa2=0;
		PC_ClearRxBuffer();
	}
}

/*
*********************************************************************************************************
*                                         CY_ISR(animacion)
*
* Description : Interrupcion que temporiza las imagenes informativas que aparecen en la pantalla 1
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
CY_ISR(animacion){
    Timer_Animacion_ReadStatusRegister();
    if(flujo_LCD==1){										//Muestra el protector de la pantalla
        if(count_protector<=3){
            count_protector++;
            set_imagen(1,(iprotector+count_protector));  
        }
        else{
           count_protector=0; 
           set_imagen(1,(iprotector+count_protector));  
        }
    }
    else{													//Incrementa el contador 
        count_protector++;
    }
}

/*
*********************************************************************************************************
*                                         CY_ISR(animacion2)
*
* Description : Interrupcion que temporiza las imagenes informativas que aparecen en la pantalla 2
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
CY_ISR(animacion2){
    Timer_Animacion2_ReadStatusRegister();
    if(flujo_LCD2==1){
        if(count_protector2<=3){
            count_protector2++;
            set_imagen(2,(iprotector+count_protector2));  
        }
        else{
           count_protector2=0; 
           set_imagen(2,(iprotector+count_protector2));  
        }
    }
    else{
        count_protector2++;
    }
}

/*
*********************************************************************************************************
*                                         CY_ISR(Rf)
*
* Description : Interrupcion que temporiza tiempo de no recepcion del rf
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
CY_ISR(Rf){
    Timer_Rf_ReadStatusRegister();
    count_rf++;
}

/*
*********************************************************************************************************
*                                         main( void )
*
* Description : Ejecuta las funciones de inicio y verifica el estado de las pantallas
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
int main(){
    init();
	Direccion_Mux();
	init_surt();
    /*//Pruebas-- 
    lado.a.dir=1;
    lado.b.dir=2;
    Buffer_LCD1.Estado_Mux = 0xA1;//Estado inicial de Espera
    Buffer_LCD2.Estado_Mux = 0xA1;//Estado inicial de Espera*/
    for(;;){
		polling_recibe_RF();
		polling_procesa_CDG();
		polling_envia_CDG();
    	polling_LCD1();
		polling_LCD2();
		polling_recuperarventas();
		polling_compararVar();
    }	
}

/* [] END OF FILE */
