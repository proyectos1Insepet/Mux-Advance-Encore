/*
*********************************************************************************************************
*                                           GRP550M CODE
*
*                             (c) Copyright 2013; Sistemas Insepet LTDA
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                               GRP550M CODE
*
*                                             CYPRESS PSoC5LP
*                                                with the
*                                            CY8C5969AXI-LP035
*
* Filename      : LCD.c
* Version       : V1.00
* Programmer(s) : 
                  
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/
#include <device.h>
#include <math.h>
#include "VariablesG.h"
#include "I2C.h"

/*
*********************************************************************************************************
*                                        void set_imagen(uint8 lcd, uint16 id)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void set_imagen(uint8 lcd, uint16 id){
    if(lcd==1){
        LCD_1_PutChar(0xAA);
        LCD_1_PutChar(0x70);
        LCD_1_PutChar(((id>>8)&0xFF));
        LCD_1_PutChar((id&0xFF));
        LCD_1_PutChar(0xCC);
        LCD_1_PutChar(0x33);
        LCD_1_PutChar(0xC3);
        LCD_1_PutChar(0x3C);
    }
    else{
       	LCD_2_PutChar(0xAA);
        LCD_2_PutChar(0x70);
        LCD_2_PutChar(((id>>8)&0xFF));
        LCD_2_PutChar((id&0xFF));
        LCD_2_PutChar(0xCC);
        LCD_2_PutChar(0x33);
        LCD_2_PutChar(0xC3);
        LCD_2_PutChar(0x3C);   		 
    }
}

/*
*********************************************************************************************************
*                                 void write_LCD(uint8 lcd, uint8 dato, uint8 pos)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void write_LCD(uint8 lcd, uint8 dato, uint8 pos, uint8 posx1, uint8 posx2, uint8 posy1, uint8 posy2){
    if(lcd==1){
        LCD_1_PutChar(0xAA);
        LCD_1_PutChar(0x98);
        LCD_1_PutChar(posx2);
        LCD_1_PutChar((posx1)+(0x19*pos));
        LCD_1_PutChar(posy2);
        LCD_1_PutChar(posy1);
        LCD_1_PutChar(0x24);
        LCD_1_PutChar(0xC5);
        LCD_1_PutChar(0x02);
        LCD_1_PutChar(0x00);
        LCD_1_PutChar(0x00);
        LCD_1_PutChar(0xFF);
        LCD_1_PutChar(0xFF);
        LCD_1_PutChar(dato);
        LCD_1_PutChar(0xCC);
        LCD_1_PutChar(0x33);
        LCD_1_PutChar(0xC3);
        LCD_1_PutChar(0x3C);
    }
    else{
        LCD_2_PutChar(0xAA);
        LCD_2_PutChar(0x98);
        LCD_2_PutChar(posx2);
        LCD_2_PutChar((posx1)+(0x19*pos));
        LCD_2_PutChar(posy2);
        LCD_2_PutChar(posy1);
        LCD_2_PutChar(0x24);
        LCD_2_PutChar(0xC5);
        LCD_2_PutChar(0x02);
        LCD_2_PutChar(0x00);
        LCD_2_PutChar(0x00);
        LCD_2_PutChar(0xFF);
        LCD_2_PutChar(0xFF);
        LCD_2_PutChar(dato);
        LCD_2_PutChar(0xCC);
        LCD_2_PutChar(0x33);
        LCD_2_PutChar(0xC3);
        LCD_2_PutChar(0x3C);    
    }
}
/*
*********************************************************************************************************
*                                 			void LCD_Canastilla(void)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void LCD_Canastilla(uint8 lado){
	int digito;
    uint32 x,y,i;
	if(lado==1){
		Buffer_LCD1.ValorCant1=0;
		for(x=Buffer_LCD1.CantProducto1Canasta[0];x>=1;x--){
			Buffer_LCD1.ValorCant1+=((Buffer_LCD1.CantProducto1Canasta[x]&0x0f)*pow(10,(Buffer_LCD1.CantProducto1Canasta[0]-x)));
		}
		for(x=1;x<=3;x++){
			y=pow(10,x);
			Buffer_LCD1.CantProducto1Canasta[4-x] = (Buffer_LCD1.ValorCant1%y)/pow(10,x-1);
		}
		Buffer_LCD1.CantProducto1Canasta[0]=3;
		
		Buffer_LCD1.ValorProducto1=Buffer_LCD1.ValorProducto1Orig*Buffer_LCD1.ValorCant1;	
		for(x=1;x<=7;x++){
			y=pow(10,x);
			Buffer_LCD1.ValorProducto1Canasta[8-x] = (Buffer_LCD1.ValorProducto1%y)/pow(10,x-1);
		}
		Buffer_LCD1.ValorProducto1Canasta[0]=7;

		Buffer_LCD1.ValorCant2=0;
		for(x=Buffer_LCD1.CantProducto2Canasta[0];x>=1;x--){
			Buffer_LCD1.ValorCant2+=((Buffer_LCD1.CantProducto2Canasta[x]&0x0f)*pow(10,(Buffer_LCD1.CantProducto2Canasta[0]-x)));
		}
		for(x=1;x<=3;x++){
			y=pow(10,x);
			Buffer_LCD1.CantProducto2Canasta[4-x] = (Buffer_LCD1.ValorCant2%y)/pow(10,x-1);
		}
		Buffer_LCD1.CantProducto2Canasta[0]=3;
		
		Buffer_LCD1.ValorProducto2=Buffer_LCD1.ValorProducto2Orig*Buffer_LCD1.ValorCant2;	
		for(x=1;x<=7;x++){
			y=pow(10,x);
			Buffer_LCD1.ValorProducto2Canasta[8-x] = (Buffer_LCD1.ValorProducto2%y)/pow(10,x-1);
		}
		Buffer_LCD1.ValorProducto2Canasta[0]=7;
		
		Buffer_LCD1.ValorCant3=0;
		for(x=Buffer_LCD1.CantProducto3Canasta[0];x>=1;x--){
			Buffer_LCD1.ValorCant3+=((Buffer_LCD1.CantProducto3Canasta[x]&0x0f)*pow(10,(Buffer_LCD1.CantProducto3Canasta[0]-x)));
		}
		for(x=1;x<=3;x++){
			y=pow(10,x);
			Buffer_LCD1.CantProducto3Canasta[4-x] = (Buffer_LCD1.ValorCant3%y)/pow(10,x-1);
		}
		Buffer_LCD1.CantProducto3Canasta[0]=3;
		
		Buffer_LCD1.ValorProducto3=Buffer_LCD1.ValorProducto3Orig*Buffer_LCD1.ValorCant3;	
		for(x=1;x<=7;x++){
			y=pow(10,x);
			Buffer_LCD1.ValorProducto3Canasta[8-x] = (Buffer_LCD1.ValorProducto3%y)/pow(10,x-1);
		}
		Buffer_LCD1.ValorProducto3Canasta[0]=7;
		
		Buffer_LCD1.ValorCant4=0;
		for(x=Buffer_LCD1.CantProducto4Canasta[0];x>=1;x--){
			Buffer_LCD1.ValorCant4+=((Buffer_LCD1.CantProducto4Canasta[x]&0x0f)*pow(10,(Buffer_LCD1.CantProducto4Canasta[0]-x)));
		}
		for(x=1;x<=3;x++){
			y=pow(10,x);
			Buffer_LCD1.CantProducto4Canasta[4-x] = (Buffer_LCD1.ValorCant4%y)/pow(10,x-1);
		}
		Buffer_LCD1.CantProducto4Canasta[0]=3;
		
		Buffer_LCD1.ValorProducto4=Buffer_LCD1.ValorProducto4Orig*Buffer_LCD1.ValorCant4;	
		for(x=1;x<=7;x++){
			y=pow(10,x);
			Buffer_LCD1.ValorProducto4Canasta[8-x] = (Buffer_LCD1.ValorProducto4%y)/pow(10,x-1);
		}
		Buffer_LCD1.ValorProducto4Canasta[0]=7;
		
		Buffer_LCD1.ValorProductoTotal=Buffer_LCD1.ValorProducto1+Buffer_LCD1.ValorProducto2+Buffer_LCD1.ValorProducto3+Buffer_LCD1.ValorProducto4;
		for(x=1;x<=8;x++){
			y=pow(10,x);
			Buffer_LCD1.ValorTotalProdCanasta[9-x] = (Buffer_LCD1.ValorProductoTotal%y)/pow(10,x-1);
		}
		Buffer_LCD1.ValorTotalProdCanasta[0]=8;
		
		for(i=1;i<=10;i++){//Producto1
			write_LCD(1,(Buffer_LCD1.NombreProducto1Canasta[i]),i,0x03,0x00,0x1E,0x00);
			write_LCD(1,(Buffer_LCD1.NombreProducto2Canasta[i]),i,0x03,0x00,0x78,0x00);
			write_LCD(1,(Buffer_LCD1.NombreProducto3Canasta[i]),i,0x03,0x00,0xD2,0x00);
			write_LCD(1,(Buffer_LCD1.NombreProducto4Canasta[i]),i,0x03,0x00,0x2B,0x01);
		}
		digito=0;
		for(i=1;i<=Buffer_LCD1.CantProducto1Canasta[0];i++){//Cantidad1
			if(Buffer_LCD1.CantProducto1Canasta[i]==0 && digito==0){
				
			}else{
				write_LCD(1,(Buffer_LCD1.CantProducto1Canasta[i]+0x30),i,18,0x01,0x1E,0x00);
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD1.CantProducto2Canasta[0];i++){//Cantidad2
			if(Buffer_LCD1.CantProducto2Canasta[i]==0 && digito==0){
				
			}else{
				write_LCD(1,(Buffer_LCD1.CantProducto2Canasta[i]+0x30),i,18,0x01,0x78,0x00);
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD1.CantProducto3Canasta[0];i++){//Cantidad3
			if(Buffer_LCD1.CantProducto3Canasta[i]==0 && digito==0){
				
			}else{
				write_LCD(1,(Buffer_LCD1.CantProducto3Canasta[i]+0x30),i,18,0x01,0xD2,0x00);
				digito=1;
			}
			
		}
		digito=0;
		for(i=1;i<=Buffer_LCD1.CantProducto4Canasta[0];i++){//Cantidad4
			if(Buffer_LCD1.CantProducto4Canasta[i]==0 && digito==0){
				
			}else{
				write_LCD(1,(Buffer_LCD1.CantProducto4Canasta[i]+0x30),i,18,0x01,0x2B,0x01);
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD1.ValorProducto1Canasta[0];i++){//Valor1
			if(Buffer_LCD1.ValorProducto1Canasta[i]==0 && digito==0){
			
			}else{
				if(i<7){
					write_LCD(1,(Buffer_LCD1.ValorProducto1Canasta[i]+0x30),i,0x69,0x01,0x1E,0x00);
				}else if(i==7){
					write_LCD(1,(Buffer_LCD1.ValorProducto1Canasta[7]+0x30),1,0x00,0x02,0x1E,0x00);
				}
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD1.ValorProducto2Canasta[0];i++){//Valor2
			if(Buffer_LCD1.ValorProducto2Canasta[i]==0 && digito==0){
			
			}else{
				if(i<7){
					write_LCD(1,(Buffer_LCD1.ValorProducto2Canasta[i]+0x30),i,0x69,0x01,0x78,0x00);
				}else if(i==7){
					write_LCD(1,(Buffer_LCD1.ValorProducto2Canasta[7]+0x30),1,0x00,0x02,0x78,0x00);
				}
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD1.ValorProducto3Canasta[0];i++){//Valor3
			if(Buffer_LCD1.ValorProducto3Canasta[i]==0 && digito==0){
			
			}else{
				if(i<7){
					write_LCD(1,(Buffer_LCD1.ValorProducto3Canasta[i]+0x30),i,0x69,0x01,0xD2,0x00);
				}else if(i==7){
					write_LCD(1,(Buffer_LCD1.ValorProducto3Canasta[7]+0x30),1,0x00,0x02,0xD2,0x00);
				}
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD1.ValorProducto4Canasta[0];i++){//Valor4
			if(Buffer_LCD1.ValorProducto4Canasta[i]==0 && digito==0){
			
			}else{
				if(i<7){
					write_LCD(1,(Buffer_LCD1.ValorProducto4Canasta[i]+0x30),i,0x69,0x01,0x2B,0x01);
				}else if(i==7){
					write_LCD(1,(Buffer_LCD1.ValorProducto4Canasta[7]+0x30),1,0x00,0x02,0x2B,0x01);
				}
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD1.ValorTotalProdCanasta[0];i++){//TOTAL
			if(Buffer_LCD1.ValorTotalProdCanasta[i]==0 && digito==0){
				
			}else{
				if(i==1){
					write_LCD(1,(Buffer_LCD1.ValorTotalProdCanasta[i]+0x30),i,230,0x00,0x7F,0x01);//TOTAL
				}else{
					write_LCD(1,(Buffer_LCD1.ValorTotalProdCanasta[i]+0x30),i-1,0,0x01,0x7F,0x01);
				}
				digito=1;
			}
		}
	}else if(lado==2){
		Buffer_LCD2.ValorCant1=0;
		for(x=Buffer_LCD2.CantProducto1Canasta[0];x>=1;x--){
			Buffer_LCD2.ValorCant1+=((Buffer_LCD2.CantProducto1Canasta[x]&0x0f)*pow(10,(Buffer_LCD2.CantProducto1Canasta[0]-x)));
		}
		for(x=1;x<=3;x++){
			y=pow(10,x);
			Buffer_LCD2.CantProducto1Canasta[4-x] = (Buffer_LCD2.ValorCant1%y)/pow(10,x-1);
		}
		Buffer_LCD2.CantProducto1Canasta[0]=3;
		
		Buffer_LCD2.ValorProducto1=Buffer_LCD2.ValorProducto1Orig*Buffer_LCD2.ValorCant1;	
		for(x=1;x<=7;x++){
			y=pow(10,x);
			Buffer_LCD2.ValorProducto1Canasta[8-x] = (Buffer_LCD2.ValorProducto1%y)/pow(10,x-1);
		}
		Buffer_LCD2.ValorProducto1Canasta[0]=7;

		Buffer_LCD2.ValorCant2=0;
		for(x=Buffer_LCD2.CantProducto2Canasta[0];x>=1;x--){
			Buffer_LCD2.ValorCant2+=((Buffer_LCD2.CantProducto2Canasta[x]&0x0f)*pow(10,(Buffer_LCD2.CantProducto2Canasta[0]-x)));
		}
		for(x=1;x<=3;x++){
			y=pow(10,x);
			Buffer_LCD2.CantProducto2Canasta[4-x] = (Buffer_LCD2.ValorCant2%y)/pow(10,x-1);
		}
		Buffer_LCD2.CantProducto2Canasta[0]=3;
		
		Buffer_LCD2.ValorProducto2=Buffer_LCD2.ValorProducto2Orig*Buffer_LCD2.ValorCant2;	
		for(x=1;x<=7;x++){
			y=pow(10,x);
			Buffer_LCD2.ValorProducto2Canasta[8-x] = (Buffer_LCD2.ValorProducto2%y)/pow(10,x-1);
		}
		Buffer_LCD2.ValorProducto2Canasta[0]=7;
		
		Buffer_LCD2.ValorCant3=0;
		for(x=Buffer_LCD2.CantProducto3Canasta[0];x>=1;x--){
			Buffer_LCD2.ValorCant3+=((Buffer_LCD2.CantProducto3Canasta[x]&0x0f)*pow(10,(Buffer_LCD2.CantProducto3Canasta[0]-x)));
		}
		for(x=1;x<=3;x++){
			y=pow(10,x);
			Buffer_LCD2.CantProducto3Canasta[4-x] = (Buffer_LCD2.ValorCant3%y)/pow(10,x-1);
		}
		Buffer_LCD2.CantProducto3Canasta[0]=3;
		
		Buffer_LCD2.ValorProducto3=Buffer_LCD2.ValorProducto3Orig*Buffer_LCD2.ValorCant3;	
		for(x=1;x<=7;x++){
			y=pow(10,x);
			Buffer_LCD2.ValorProducto3Canasta[8-x] = (Buffer_LCD2.ValorProducto3%y)/pow(10,x-1);
		}
		Buffer_LCD2.ValorProducto3Canasta[0]=7;
		
		Buffer_LCD2.ValorCant4=0;
		for(x=Buffer_LCD2.CantProducto4Canasta[0];x>=1;x--){
			Buffer_LCD2.ValorCant4+=((Buffer_LCD2.CantProducto4Canasta[x]&0x0f)*pow(10,(Buffer_LCD2.CantProducto4Canasta[0]-x)));
		}
		for(x=1;x<=3;x++){
			y=pow(10,x);
			Buffer_LCD2.CantProducto4Canasta[4-x] = (Buffer_LCD2.ValorCant4%y)/pow(10,x-1);
		}
		Buffer_LCD2.CantProducto4Canasta[0]=3;
		
		Buffer_LCD2.ValorProducto4=Buffer_LCD2.ValorProducto4Orig*Buffer_LCD2.ValorCant4;	
		for(x=1;x<=7;x++){
			y=pow(10,x);
			Buffer_LCD2.ValorProducto4Canasta[8-x] = (Buffer_LCD2.ValorProducto4%y)/pow(10,x-1);
		}
		Buffer_LCD2.ValorProducto4Canasta[0]=7;
		
		Buffer_LCD2.ValorProductoTotal=Buffer_LCD2.ValorProducto1+Buffer_LCD2.ValorProducto2+Buffer_LCD2.ValorProducto3+Buffer_LCD2.ValorProducto4;
		for(x=1;x<=8;x++){
			y=pow(10,x);
			Buffer_LCD2.ValorTotalProdCanasta[9-x] = (Buffer_LCD2.ValorProductoTotal%y)/pow(10,x-1);
		}
		Buffer_LCD2.ValorTotalProdCanasta[0]=8;
		
		for(i=1;i<=10;i++){//Producto1
			write_LCD(2,(Buffer_LCD2.NombreProducto1Canasta[i]),i,0x03,0x00,0x1E,0x00);
			write_LCD(2,(Buffer_LCD2.NombreProducto2Canasta[i]),i,0x03,0x00,0x78,0x00);
			write_LCD(2,(Buffer_LCD2.NombreProducto3Canasta[i]),i,0x03,0x00,0xD2,0x00);
			write_LCD(2,(Buffer_LCD2.NombreProducto4Canasta[i]),i,0x03,0x00,0x2B,0x01);
		}
		digito=0;
		for(i=1;i<=Buffer_LCD2.CantProducto1Canasta[0];i++){//Cantidad1
			if(Buffer_LCD2.CantProducto1Canasta[i]==0 && digito==0){
				
			}else{
				write_LCD(2,(Buffer_LCD2.CantProducto1Canasta[i]+0x30),i,18,0x01,0x1E,0x00);
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD2.CantProducto2Canasta[0];i++){//Cantidad2
			if(Buffer_LCD2.CantProducto2Canasta[i]==0 && digito==0){
				
			}else{
				write_LCD(2,(Buffer_LCD2.CantProducto2Canasta[i]+0x30),i,18,0x01,0x78,0x00);
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD2.CantProducto3Canasta[0];i++){//Cantidad3
			if(Buffer_LCD2.CantProducto3Canasta[i]==0 && digito==0){
				
			}else{
				write_LCD(2,(Buffer_LCD2.CantProducto3Canasta[i]+0x30),i,18,0x01,0xD2,0x00);
				digito=1;
			}
			
		}
		digito=0;
		for(i=1;i<=Buffer_LCD2.CantProducto4Canasta[0];i++){//Cantidad4
			if(Buffer_LCD2.CantProducto4Canasta[i]==0 && digito==0){
				
			}else{
				write_LCD(2,(Buffer_LCD2.CantProducto4Canasta[i]+0x30),i,18,0x01,0x2B,0x01);
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD2.ValorProducto1Canasta[0];i++){//Valor1
			if(Buffer_LCD2.ValorProducto1Canasta[i]==0 && digito==0){
			
			}else{
				if(i<7){
					write_LCD(2,(Buffer_LCD2.ValorProducto1Canasta[i]+0x30),i,0x69,0x01,0x1E,0x00);
				}else if(i==7){
					write_LCD(2,(Buffer_LCD2.ValorProducto1Canasta[7]+0x30),1,0x00,0x02,0x1E,0x00);
				}
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD2.ValorProducto2Canasta[0];i++){//Valor2
			if(Buffer_LCD2.ValorProducto2Canasta[i]==0 && digito==0){
			
			}else{
				if(i<7){
					write_LCD(2,(Buffer_LCD2.ValorProducto2Canasta[i]+0x30),i,0x69,0x01,0x78,0x00);
				}else if(i==7){
					write_LCD(2,(Buffer_LCD2.ValorProducto2Canasta[7]+0x30),1,0x00,0x02,0x78,0x00);
				}
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD2.ValorProducto3Canasta[0];i++){//Valor3
			if(Buffer_LCD2.ValorProducto3Canasta[i]==0 && digito==0){
			
			}else{
				if(i<7){
					write_LCD(2,(Buffer_LCD2.ValorProducto3Canasta[i]+0x30),i,0x69,0x01,0xD2,0x00);
				}else if(i==7){
					write_LCD(2,(Buffer_LCD2.ValorProducto3Canasta[7]+0x30),1,0x00,0x02,0xD2,0x00);
				}
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD2.ValorProducto4Canasta[0];i++){//Valor4
			if(Buffer_LCD2.ValorProducto4Canasta[i]==0 && digito==0){
			
			}else{
				if(i<7){
					write_LCD(2,(Buffer_LCD2.ValorProducto4Canasta[i]+0x30),i,0x69,0x01,0x2B,0x01);
				}else if(i==7){
					write_LCD(2,(Buffer_LCD2.ValorProducto4Canasta[7]+0x30),1,0x00,0x02,0x2B,0x01);
				}
				digito=1;
			}
		}
		digito=0;
		for(i=1;i<=Buffer_LCD2.ValorTotalProdCanasta[0];i++){//TOTAL
			if(Buffer_LCD2.ValorTotalProdCanasta[i]==0 && digito==0){
				
			}else{
				if(i==1){
					write_LCD(2,(Buffer_LCD2.ValorTotalProdCanasta[i]+0x30),i,230,0x00,0x7F,0x01);//TOTAL
				}else{
					write_LCD(2,(Buffer_LCD2.ValorTotalProdCanasta[i]+0x30),i-1,0,0x01,0x7F,0x01);
				}
				digito=1;
			}
		}
	}
}


/*
*********************************************************************************************************
*                                         void publicarmensaje()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void publicarmensaje(uint8 posicion){
    uint32 i;
	if(posicion==1){
		for(i=0;i<=10;i++){
			write_LCD(1,(Buffer_LCD1.MensajePublicar[i]),i,5,0,21,0);
			write_LCD(1,(Buffer_LCD1.MensajePublicar[i+25]),i,5,0,65,0);
		}
		for(i=11;i<=20;i++){
			write_LCD(1,(Buffer_LCD1.MensajePublicar[i]),i-10,0,1,21,0);
			write_LCD(1,(Buffer_LCD1.MensajePublicar[i+25]),i-10,0,1,65,0);
		}
		for(i=21;i<=24;i++){
			write_LCD(1,(Buffer_LCD1.MensajePublicar[i]),i-20,0,2,21,0);
			write_LCD(1,(Buffer_LCD1.MensajePublicar[i+25]),i-20,0,2,65,0);
		}
	}else{
		for(i=0;i<=10;i++){
			write_LCD(2,(Buffer_LCD2.MensajePublicar[i]),i,5,0,21,0);
			write_LCD(2,(Buffer_LCD2.MensajePublicar[i+25]),i,5,0,65,0);
		}
		for(i=11;i<=20;i++){
			write_LCD(2,(Buffer_LCD2.MensajePublicar[i]),i-10,0,1,21,0);
			write_LCD(2,(Buffer_LCD2.MensajePublicar[i+25]),i-10,0,1,65,0);
		}
		for(i=21;i<=24;i++){
			write_LCD(2,(Buffer_LCD2.MensajePublicar[i]),i-20,0,2,21,0);
			write_LCD(2,(Buffer_LCD2.MensajePublicar[i+25]),i-20,0,2,65,0);
		}
	}
}


/*
*********************************************************************************************************
*                                         void publicmenprod()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void publicmenprod(uint8 posicion){
    uint32 i;
	if(posicion==1){
		for(i=1;i<=10;i++){
			write_LCD(1,(Buffer_LCD1.MensajeProducto[i]),i,5,0,130,1);
		}
		for(i=11;i<=20;i++){
			write_LCD(1,(Buffer_LCD1.MensajeProducto[i]),i-10,0,1,130,1);
		}
	}else{
		for(i=1;i<=10;i++){
			write_LCD(2,(Buffer_LCD2.MensajeProducto[i]),i,5,0,130,1);
		}
		for(i=11;i<=20;i++){
			write_LCD(2,(Buffer_LCD2.MensajeProducto[i]),i-10,0,1,130,1);
		}
	}
}

/* [] END OF FILE */
