/*
*********************************************************************************************************
*                                           GRP550/700 CODE
*
*                             (c) Copyright 2013; Sistemas Insepet LTDA
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                             GRP550/700 CODE
*
*                                             CYPRESS PSoC5LP
*                                                with the
*                                            CY8C5969AXI-LP035
*
* Filename      : EstructuraProtocolo.c
* Version       : V1.00
* Programmer(s) : 
                  
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/
#include <device.h>
#include "VariablesG.h"
#include "I2C.h"
#include "Protocolo.h"
#include "LCD.h"

/*
*********************************************************************************************************
*                                         void checksum()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void checksum(uint16 Tamano){
    uint32 i;
    uint8 index;
    uint8 table[256] = { 
    0, 94,188,226, 97, 63,221,131,194,156,126, 32,163,253, 31, 65,
    157,195, 33,127,252,162, 64, 30, 95,  1,227,189, 62, 96,130,220,
    35,125,159,193, 66, 28,254,160,225,191, 93,  3,128,222, 60, 98,
    190,224,  2, 92,223,129, 99, 61,124, 34,192,158, 29, 67,161,255,
    70, 24,250,164, 39,121,155,197,132,218, 56,102,229,187, 89,  7,
    219,133,103, 57,186,228,  6, 88, 25, 71,165,251,120, 38,196,154,
    101, 59,217,135,  4, 90,184,230,167,249, 27, 69,198,152,122, 36,
    248,166, 68, 26,153,199, 37,123, 58,100,134,216, 91,  5,231,185,
    140,210, 48,110,237,179, 81, 15, 78, 16,242,172, 47,113,147,205,
    17, 79,173,243,112, 46,204,146,211,141,111, 49,178,236, 14, 80,
    175,241, 19, 77,206,144,114, 44,109, 51,209,143, 12, 82,176,238,
    50,108,142,208, 83, 13,239,177,240,174, 76, 18,145,207, 45,115,
    202,148,118, 40,171,245, 23, 73,  8, 86,180,234,105, 55,213,139,
    87,  9,235,181, 54,104,138,212,149,203, 41,119,244,170, 72, 22,
    233,183, 85, 11,136,214, 52,106, 43,117,151,201, 74, 20,246,168,
    116, 42,200,150, 21, 75,169,247,182,232, 10, 84,215,137,107, 53}; 
    
	ResultadoCheck=0;
	for(i=1;i<=Tamano;i++){
        index = (uint8)(ResultadoCheck ^ Tx_CDG[i]);
        ResultadoCheck = table[index];
	}
}

/*
*********************************************************************************************************
*                                         void codigodebarras()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
uint8 codigodebarras(){
	uint32 tamano;
	if(Pistola_GetRxBufferSize() >= 1){
		CyDelay(100);
		tamano=1;
		while(Pistola_GetRxBufferSize()>0){
    		Rx_Pistola[tamano]=Pistola_ReadRxData();
    		tamano++;
    	}
		Rx_Pistola[0]=tamano-1;
		Pistola_ClearRxBuffer();
		CyDelay(5);
		return 1;
	}else{
		Pistola_ClearRxBuffer();
		CyDelay(5);
		return 0;
	}
	CyDelay(5);
	Pistola_ClearRxBuffer();
}


/*
*********************************************************************************************************
*                                         void envioventa()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void envioventa(uint8 producto, uint8 posicion){
    uint32 i,j,x,y;
    i=1;
	Tx_CDG[i]='M';
	i++;
	Tx_CDG[i]='U';
	i++;
	Tx_CDG[i]='X';
	i++;
	for(j=1;j<=10;j++){
		Tx_CDG[i]=(DirMuxDef[j]);
		i++;
	}
    Tx_CDG[i]=posicion;//Posicion
	i++;
	Tx_CDG[i]=i;//Byte informacion de la cantidad de datos a enviar
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=producto;
	i++;
	Tx_CDG[i]=';';
	i++;
    if(posicion==lado.a.dir){
		if((lado.c.versdig==5)||(lado.c.versdig==7)){
	        for(x=Buffer_LCD1.VentaDinero[0];x>1;x--){
				Tx_CDG[i]=Buffer_LCD1.VentaDinero[x]+48;
				i++;
			}
		}
		else{
			for(x=Buffer_LCD1.VentaDinero[0];x>=1;x--){
				if(x==decimalD){
					Tx_CDG[i]=44;
					i++;
			    }
				Tx_CDG[i]=Buffer_LCD1.VentaDinero[x]+48;
				i++;
			}
		}
		Tx_CDG[i]=';';
		i++;
		for(x=Buffer_LCD1.VentaVolumen[0];x>=5;x--){
			if(Buffer_LCD1.VentaVolumen[x]!=0){
			break;
			}
		}
		for(y=x;y>0;y--){
			if(y==decimalV){
				Tx_CDG[i]=',';
				i++;
			}
			Tx_CDG[i]=Buffer_LCD1.VentaVolumen[y]+48;
			i++;
		}
		Tx_CDG[i]=';';
		i++;	
		for(x=Buffer_LCD1.VentaPPU[0];x>=1;x--){
			Tx_CDG[i]=Buffer_LCD1.VentaPPU[x]+48;
			i++;
		}
		if(ppux10==1){
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
    	if(Buffer_LCD1.placa[0]>0){
    		j=1;
    		for(x=Buffer_LCD1.placa[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD1.placa[j];
    			j++;
    			i++;
                if(x>8){
                    x=8;
                }
    		}
    	}else{
    		Tx_CDG[i]='0';
    		i++;
    	}
    	Tx_CDG[i]=';';
    	i++;
    	if(Buffer_LCD1.cedula[0]>0){
    		j=1;
    		for(x=Buffer_LCD1.cedula[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD1.cedula[j];
    			j++;
    			i++;
                if(x>10){
                    x=10;
                }
    		}
    	}else{
    		Tx_CDG[i]='0';
    		i++;
    	}
    	Tx_CDG[i]=';';
    	i++;
    	if(Buffer_LCD1.Nit[0]>0){
    		j=1;
    		for(x=Buffer_LCD1.Nit[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD1.Nit[j];
    			j++;
    			i++;
                if(x>10){
                    x=10;
                }
    		}
    	}else{
    		Tx_CDG[i]='0';
    		i++;
    	}
    	Tx_CDG[i]=';';
    	i++;
    	if(Buffer_LCD1.km[0]>0){
    		j=1;
    		for(x=Buffer_LCD1.km[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD1.km[j];
    			j++;
    			i++;
                if(x>10){
                    x=10;
                }
    		}
    	}else{
    		Tx_CDG[i]='0';
    		i++;
    	}
		Tx_CDG[i]=';';
		i++;
		for(x=1;x<=Buffer_LCD1.FechaInicialVenta[0];x++){
			Tx_CDG[i]=Buffer_LCD1.FechaInicialVenta[x];
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		for(x=1;x<=Buffer_LCD1.FechaFinalVenta[0];x++){
			Tx_CDG[i]=Buffer_LCD1.FechaFinalVenta[x];
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		Tx_CDG[i]=Buffer_LCD1.PresetProgramado;
		i++;
		Tx_CDG[i]=';';
		i++;
		for(x=1;x<=Buffer_LCD1.ValorPreset[0];x++){
			Tx_CDG[i]=Buffer_LCD1.ValorPreset[x];
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		Tx_CDG[i]=Buffer_LCD1.TipodeVenta;
		i++;
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD1.IdentCliente[0]>0){
			j=1;
    		for(x=Buffer_LCD1.IdentCliente[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD1.IdentCliente[j];
    			j++;
    			i++;
    		}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		for(x=1;x<=Buffer_LCD1.TotalDineroAnterior[0];x++){
			Tx_CDG[i]=Buffer_LCD1.TotalDineroAnterior[x];
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		Tx_CDG[i]='0';
		i++;
		Tx_CDG[i]=';';
		i++;
		for(x=1;x<=Buffer_LCD1.TotalVolumenAnterior[0];x++){
			Tx_CDG[i]=Buffer_LCD1.TotalVolumenAnterior[x];
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		Tx_CDG[i]='0';
		i++;
		Tx_CDG[i]=';';
		i++;
		Tx_CDG[i]=Buffer_LCD1.ConfirmacionImpresion;
		i++;
		Tx_CDG[i]=';';
		i++;
		y=IdentVendedor[0];
		for(x=1;x<=y;x++){
			Tx_CDG[i]=IdentVendedor[x];
			i++;
			if(x>17){
				y=18;
			}
		}
		Tx_CDG[i]=';';
		i++;
    	Tx_CDG[15]=i;//Numero de Bytes a enviar
    }else if(posicion==lado.b.dir){
		if((lado.c.versdig==5)||(lado.c.versdig==7)){
	        for(x=Buffer_LCD2.VentaDinero[0];x>1;x--){
				Tx_CDG[i]=Buffer_LCD2.VentaDinero[x]+48;
				i++;
			}
		}
		else{
			for(x=Buffer_LCD2.VentaDinero[0];x>=1;x--){
				if(x==decimalD){
					Tx_CDG[i]=44;
					i++;
			    }
				Tx_CDG[i]=Buffer_LCD2.VentaDinero[x]+48;
				i++;
			}
		}
		Tx_CDG[i]=';';
		i++;
		for(x=Buffer_LCD2.VentaVolumen[0];x>=5;x--){
			if(Buffer_LCD2.VentaVolumen[x]!=0){
			break;
			}
		}
		for(y=x;y>0;y--){
			if(y==decimalV){
				Tx_CDG[i]=',';
				i++;
			}
			Tx_CDG[i]=Buffer_LCD2.VentaVolumen[y]+48;
			i++;
		}
		Tx_CDG[i]=';';
		i++;	
		for(x=Buffer_LCD2.VentaPPU[0];x>=1;x--){
			Tx_CDG[i]=Buffer_LCD2.VentaPPU[x]+48;
			i++;
		}
		if(ppux10==1){
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
    	if(Buffer_LCD2.placa[0]>0){
    		j=1;
    		for(x=Buffer_LCD2.placa[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD2.placa[j];
    			j++;
    			i++;
                if(x>8){
                    x=8;
                }
    		}
    	}else{
    		Tx_CDG[i]='0';
    		i++;
    	}
    	Tx_CDG[i]=';';
    	i++;
    	if(Buffer_LCD2.cedula[0]>0){
    		j=1;
    		for(x=Buffer_LCD2.cedula[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD2.cedula[j];
    			j++;
    			i++;
                if(x>10){
                    x=10;
                }
    		}
    	}else{
    		Tx_CDG[i]='0';
    		i++;
    	}
    	Tx_CDG[i]=';';
    	i++;
    	if(Buffer_LCD2.Nit[0]>0){
    		j=1;
    		for(x=Buffer_LCD2.Nit[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD2.Nit[j];
    			j++;
    			i++;
                if(x>10){
                    x=10;
                }
    		}
    	}else{
    		Tx_CDG[i]='0';
    		i++;
    	}
    	Tx_CDG[i]=';';
    	i++;
    	if(Buffer_LCD2.km[0]>0){
    		j=1;
    		for(x=Buffer_LCD2.km[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD2.km[j];
    			j++;
    			i++;
                if(x>10){
                    x=10;
                }
    		}
    	}else{
    		Tx_CDG[i]='0';
    		i++;
    	}
		Tx_CDG[i]=';';
		i++;
		for(x=1;x<=Buffer_LCD2.FechaInicialVenta[0];x++){
			Tx_CDG[i]=Buffer_LCD2.FechaInicialVenta[x];
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		for(x=1;x<=Buffer_LCD2.FechaFinalVenta[0];x++){
			Tx_CDG[i]=Buffer_LCD2.FechaFinalVenta[x];
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		Tx_CDG[i]=Buffer_LCD2.PresetProgramado;
		i++;
		Tx_CDG[i]=';';
		i++;
		for(x=1;x<=Buffer_LCD2.ValorPreset[0];x++){
			Tx_CDG[i]=Buffer_LCD2.ValorPreset[x];
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		Tx_CDG[i]=Buffer_LCD2.TipodeVenta;
		i++;
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD2.IdentCliente[0]>0){
			j=1;
    		for(x=Buffer_LCD2.IdentCliente[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD2.IdentCliente[j];
    			j++;
    			i++;
    		}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		for(x=1;x<=Buffer_LCD2.TotalDineroAnterior[0];x++){
			Tx_CDG[i]=Buffer_LCD2.TotalDineroAnterior[x];
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		Tx_CDG[i]='0';
		i++;
		Tx_CDG[i]=';';
		i++;
		for(x=1;x<=Buffer_LCD2.TotalVolumenAnterior[0];x++){
			Tx_CDG[i]=Buffer_LCD2.TotalVolumenAnterior[x];
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		Tx_CDG[i]='0';
		i++;
		Tx_CDG[i]=';';
		i++;
		Tx_CDG[i]=Buffer_LCD2.ConfirmacionImpresion;
		i++;
		Tx_CDG[i]=';';
		i++;
		y=IdentVendedor[0];
		for(x=1;x<=y;x++){
			Tx_CDG[i]=IdentVendedor[x];
			i++;
			if(x>17){
				y=18;
			}
		}
		Tx_CDG[i]=';';
		i++;
    	Tx_CDG[15]=i;//Numero de Bytes a enviar
    }
}

/*
*********************************************************************************************************
*                                         void RecuperarVentas()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void RecuperarVentas(uint8 posicion, uint8 memoria){
    uint32 x;
    switch(memoria){
        case 1: //Recupera de la RAM
            if(posicion==lado.a.dir){                                       
                producto1=Buffer_LCD1.ventaspendientesRAM[1+(186*(Buffer_LCD1.VentasPendientesR-1))];               //Manguera Surtidor
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[2+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){         //Dinero
        			Buffer_LCD1.VentaDinero[x]=Buffer_LCD1.ventaspendientesRAM[(2+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[11+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){        //Volumen   
        			Buffer_LCD1.VentaVolumen[x]=Buffer_LCD1.ventaspendientesRAM[(11+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[20+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){        //PPU
        			Buffer_LCD1.VentaPPU[x]=Buffer_LCD1.ventaspendientesRAM[(20+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[27+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){        //Placa
        			Buffer_LCD1.placa[x]=Buffer_LCD1.ventaspendientesRAM[(27+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[36+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){        //Cedula
        			Buffer_LCD1.cedula[x]=Buffer_LCD1.ventaspendientesRAM[(36+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[47+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){        //Nit
        			Buffer_LCD1.Nit[x]=Buffer_LCD1.ventaspendientesRAM[(47+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[58+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){        //Kilometraje
        			Buffer_LCD1.km[x]=Buffer_LCD1.ventaspendientesRAM[(58+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[69+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){        //Fecha Surtiendo
        			Buffer_LCD1.FechaInicialVenta[x]=Buffer_LCD1.ventaspendientesRAM[(69+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[84+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){        //Fecha Fin Venta
        			Buffer_LCD1.FechaFinalVenta[x]=Buffer_LCD1.ventaspendientesRAM[(84+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                Buffer_LCD1.PresetProgramado=Buffer_LCD1.ventaspendientesRAM[100+(186*(Buffer_LCD1.VentasPendientesR-1))];//Tipo de Preset Programado
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[101+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){       //Cantidad Programada
        			Buffer_LCD1.ValorPreset[x]=Buffer_LCD1.ventaspendientesRAM[(101+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                Buffer_LCD1.TipodeVenta=Buffer_LCD1.ventaspendientesRAM[110+(186*(Buffer_LCD1.VentasPendientesR-1))];//Tipo de Venta
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[111+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){       //Identificacion de cliente
        			Buffer_LCD1.IdentCliente[x]=Buffer_LCD1.ventaspendientesRAM[(111+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[129+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){       //Total Manguera Dinero antes
        			Buffer_LCD1.TotalDineroAnterior[x]=Buffer_LCD1.ventaspendientesRAM[(129+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[142+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){       //Total Manguera Volumen antes
        			Buffer_LCD1.TotalVolumenAnterior[x]=Buffer_LCD1.ventaspendientesRAM[(142+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];
        		}
                Buffer_LCD1.ConfirmacionImpresion='0';                      //Confirmacion impresion en 0
                for(x=0;x<=Buffer_LCD1.ventaspendientesRAM[156+(186*(Buffer_LCD1.VentasPendientesR-1))];x++){
        			IdentVendedor[x]=Buffer_LCD1.ventaspendientesRAM[(156+x)+(186*(Buffer_LCD1.VentasPendientesR-1))];//Identificacion Vendedor
        		}
        	}else{
        		producto2=Buffer_LCD2.ventaspendientesRAM[1+(186*(Buffer_LCD2.VentasPendientesR-1))];               //Manguera Surtidor
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[2+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){         //Dinero
        			Buffer_LCD2.VentaDinero[x]=Buffer_LCD2.ventaspendientesRAM[(2+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[11+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){        //Volumen 
        			Buffer_LCD2.VentaVolumen[x]=Buffer_LCD2.ventaspendientesRAM[(11+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[20+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){        //PPU
        			Buffer_LCD2.VentaPPU[x]=Buffer_LCD2.ventaspendientesRAM[(20+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[27+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){        //Placa
        			Buffer_LCD2.placa[x]=Buffer_LCD2.ventaspendientesRAM[(27+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[36+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){        //Cedula
        			Buffer_LCD2.cedula[x]=Buffer_LCD2.ventaspendientesRAM[(36+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[47+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){        //Nit
        			Buffer_LCD2.Nit[x]=Buffer_LCD2.ventaspendientesRAM[(47+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[58+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){        //Kilometraje
        			Buffer_LCD2.km[x]=Buffer_LCD2.ventaspendientesRAM[(58+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[69+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){        //Fecha Surtiendo
        			Buffer_LCD2.FechaInicialVenta[x]=Buffer_LCD2.ventaspendientesRAM[(69+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[84+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){        //Fecha Fin Venta
        			Buffer_LCD2.FechaFinalVenta[x]=Buffer_LCD2.ventaspendientesRAM[(84+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                Buffer_LCD2.PresetProgramado=Buffer_LCD2.ventaspendientesRAM[100+(186*(Buffer_LCD2.VentasPendientesR-1))];//Tipo de Preset Programado
        	    for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[101+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){       //Cantidad Programada
        			Buffer_LCD2.ValorPreset[x]=Buffer_LCD2.ventaspendientesRAM[(101+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                Buffer_LCD2.TipodeVenta=Buffer_LCD2.ventaspendientesRAM[110+(186*(Buffer_LCD2.VentasPendientesR-1))];//Tipo de Venta
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[111+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){       //Identificacion de cliente
        			Buffer_LCD2.IdentCliente[x]=Buffer_LCD2.ventaspendientesRAM[(111+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[129+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){       //Total Manguera Dinero antes
        			Buffer_LCD2.TotalDineroAnterior[x]=Buffer_LCD2.ventaspendientesRAM[(129+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[142+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){       //Total Manguera Volumen antes
        			Buffer_LCD2.TotalVolumenAnterior[x]=Buffer_LCD2.ventaspendientesRAM[(142+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];
        		}
                Buffer_LCD2.ConfirmacionImpresion='0';                      //Confirmacion impresion en 0
                for(x=0;x<=Buffer_LCD2.ventaspendientesRAM[156+(186*(Buffer_LCD2.VentasPendientesR-1))];x++){
        			IdentVendedor[x]=Buffer_LCD2.ventaspendientesRAM[(156+x)+(186*(Buffer_LCD2.VentasPendientesR-1))];//Identificacion Vendedor
        		}
            }
        break;
            
        case 2://Recupera de la EEPROM
            if(posicion==lado.a.dir){
        		leer_eeprom(514+(512*(Buffer_LCD1.VentasPendientesE-1)),2);	//Manguera Surtidor	
        		producto1=buffer_i2c[1];
                leer_eeprom(516+(512*(Buffer_LCD1.VentasPendientesE-1)),9);	//Dinero
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.VentaDinero[x]=buffer_i2c[x];
        		}
                leer_eeprom(525+(512*(Buffer_LCD1.VentasPendientesE-1)),9);	//Volumen
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.VentaVolumen[x]=buffer_i2c[x];
        		}
                leer_eeprom(534+(512*(Buffer_LCD1.VentasPendientesE-1)),7);	//PPU
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.VentaPPU[x]=buffer_i2c[x];
        		}
                leer_eeprom(576+(512*(Buffer_LCD1.VentasPendientesE-1)),9);	//Placa
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.placa[x]=buffer_i2c[x];
        		}
                leer_eeprom(585+(512*(Buffer_LCD1.VentasPendientesE-1)),11);	//Cedula
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.cedula[x]=buffer_i2c[x];
        		}
                leer_eeprom(596+(512*(Buffer_LCD1.VentasPendientesE-1)),11);	//Nit
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.Nit[x]=buffer_i2c[x];
        		}
                leer_eeprom(640+(512*(Buffer_LCD1.VentasPendientesE-1)),11);	//Kilometraje
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.km[x]=buffer_i2c[x];
        		}
                leer_eeprom(704+(512*(Buffer_LCD1.VentasPendientesE-1)),15);	//Fecha Surtiendo
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.FechaInicialVenta[x]=buffer_i2c[x];
        		}
                leer_eeprom(719+(512*(Buffer_LCD1.VentasPendientesE-1)),15);	//Fecha Fin Venta
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.FechaFinalVenta[x]=buffer_i2c[x];
        		}
                leer_eeprom(768+(512*(Buffer_LCD1.VentasPendientesE-1)),2);	//Tipo de Preset Programado
        		Buffer_LCD1.PresetProgramado=buffer_i2c[1];
                leer_eeprom(770+(512*(Buffer_LCD1.VentasPendientesE-1)),8);	//Cantidad Programada
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.ValorPreset[x]=buffer_i2c[x];
        		}
                leer_eeprom(778+(512*(Buffer_LCD1.VentasPendientesE-1)),2);	//Tipo de Venta
        		Buffer_LCD1.TipodeVenta=buffer_i2c[1];
                leer_eeprom(780+(512*(Buffer_LCD1.VentasPendientesE-1)),18);	//Identificacion de cliente
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.IdentCliente[x]=buffer_i2c[x];
        		}
                leer_eeprom(832+(512*(Buffer_LCD1.VentasPendientesE-1)),13);	//Total Manguera Dinero antes
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.TotalDineroAnterior[x]=buffer_i2c[x];
        		}
                leer_eeprom(896+(512*(Buffer_LCD1.VentasPendientesE-1)),14);	//Total Manguera Volumen antes
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD1.TotalVolumenAnterior[x]=buffer_i2c[x];
        		}
                Buffer_LCD1.ConfirmacionImpresion='0';						//Confirmacion impresion en 0
                leer_eeprom(960+(512*(Buffer_LCD1.VentasPendientesE-1)),18);	//Identificacion Vendedor
                for(x=0;x<=buffer_i2c[0];x++){
        		    IdentVendedor[x]=buffer_i2c[x];
        	    }
        	}else{
        		leer_eeprom(545+(512*(Buffer_LCD2.VentasPendientesE-1)),2);	//Manguera Surtidor
        		producto2=buffer_i2c[1];
                leer_eeprom(547+(512*(Buffer_LCD2.VentasPendientesE-1)),9);	//Dinero
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.VentaDinero[x]=buffer_i2c[x];
        		}
                leer_eeprom(556+(512*(Buffer_LCD2.VentasPendientesE-1)),9);	//Volumen
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.VentaVolumen[x]=buffer_i2c[x];
        		}
                leer_eeprom(565+(512*(Buffer_LCD2.VentasPendientesE-1)),7);	//PPU
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.VentaPPU[x]=buffer_i2c[x];
        		}
                leer_eeprom(607+(512*(Buffer_LCD2.VentasPendientesE-1)),9);	//Placa
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.placa[x]=buffer_i2c[x];
        		}
                leer_eeprom(616+(512*(Buffer_LCD2.VentasPendientesE-1)),11);	//Cedula
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.cedula[x]=buffer_i2c[x];
        		}
                leer_eeprom(627+(512*(Buffer_LCD2.VentasPendientesE-1)),11);	//Nit
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.Nit[x]=buffer_i2c[x];
        		}
                leer_eeprom(671+(512*(Buffer_LCD2.VentasPendientesE-1)),11);	//Kilometraje
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.km[x]=buffer_i2c[x];
        		}
        		leer_eeprom(735+(512*(Buffer_LCD2.VentasPendientesE-1)),15);	//Fecha Surtiendo
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.FechaInicialVenta[x]=buffer_i2c[x];
        		}
        		leer_eeprom(750+(512*(Buffer_LCD2.VentasPendientesE-1)),15);	//Fecha Fin Venta
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.FechaFinalVenta[x]=buffer_i2c[x];
        		}
        		leer_eeprom(799+(512*(Buffer_LCD2.VentasPendientesE-1)),2);	//Tipo de Preset Programado
        		Buffer_LCD2.PresetProgramado=buffer_i2c[1];
        		leer_eeprom(801+(512*(Buffer_LCD2.VentasPendientesE-1)),8);	//Cantidad Programada
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.ValorPreset[x]=buffer_i2c[x];
        		}
        		leer_eeprom(809+(512*(Buffer_LCD2.VentasPendientesE-1)),2);	//Tipo de Venta
        		Buffer_LCD2.TipodeVenta=buffer_i2c[1];
        		leer_eeprom(811+(512*(Buffer_LCD2.VentasPendientesE-1)),18);	//Identificacion de cliente
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.IdentCliente[x]=buffer_i2c[x];
        		}
        		leer_eeprom(863+(512*(Buffer_LCD2.VentasPendientesE-1)),13);	//Total Manguera Dinero antes
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.TotalDineroAnterior[x]=buffer_i2c[x];
        		}
        		leer_eeprom(927+(512*(Buffer_LCD2.VentasPendientesE-1)),14);	//Total Manguera Volumen antes
        		for(x=0;x<=buffer_i2c[0];x++){
        			Buffer_LCD2.TotalVolumenAnterior[x]=buffer_i2c[x];
        		}
        		Buffer_LCD2.ConfirmacionImpresion='0';						//Confirmacion impresion en 0
        		leer_eeprom(991+(512*(Buffer_LCD2.VentasPendientesE-1)),18);	//Identificacion Vendedor
                for(x=0;x<=buffer_i2c[0];x++){
        		    IdentVendedor[x]=buffer_i2c[x];
        	    }
        	}
        break;
    }
}

/*
*********************************************************************************************************
*                                         void envioid()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void envioid(uint8 posicion, uint8 id){
    uint32 i,j,x,y;
	i=1;
	Tx_CDG[i]='M';
	i++;
	Tx_CDG[i]='U';
	i++;
	Tx_CDG[i]='X';
	i++;
	for(j=1;j<=10;j++){
		Tx_CDG[i]=(DirMuxDef[j]);
		i++;
	}
    Tx_CDG[i]=posicion;//Posicion
	i++;
	Tx_CDG[i]=i;//Byte informacion de la cantidad de datos a enviar
	i++;
	Tx_CDG[i]=';';
	i++;
	if(posicion==lado.a.dir){
		if(id==0xB1 || id==0xF7){//Contado Control ó credito ó Canastilla credito
			j=1;
    		for(x=Buffer_LCD1.IdentCliente[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD1.IdentCliente[j];
    			j++;
    			i++;
    		}
			Tx_CDG[i]=';';
			i++;
			j=1;
    		for(x=Buffer_LCD1.KmID[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD1.KmID[j];
    			j++;
    			i++;
    		}
			Tx_CDG[i]=';';
			i++;
			if(id==0xB1){
				Tx_CDG[i]='1';//1 si es ID Combustible
				i++;	
			}else{
				Tx_CDG[i]='0';//0 si es ID Canastilla
				i++;
			}
			Tx_CDG[i]=';';
			i++;
		}else if(id==0xFD){//Reconocimiento de producto en Canastilla
    		for(x=1;x<=Rx_Pistola[0];x++){
    			Tx_CDG[i]=Rx_Pistola[x];
    			i++;
    		}
			Tx_CDG[i]=';';
			i++;
		}else if(id==0xA8){//Venta finalizada en canastilla
    		for(x=1;x<=Buffer_LCD1.FechaVentaCanastilla[0];x++){//Fecha venta canastilla
    			Tx_CDG[i]=Buffer_LCD1.FechaVentaCanastilla[x];
    			i++;
    		}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.CodigoProductoCanasta1[0]>0){		//Codigo producto 1
				for(x=1;x<=Buffer_LCD1.CodigoProductoCanasta1[0];x++){
	    			Tx_CDG[i]=Buffer_LCD1.CodigoProductoCanasta1[x];
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.CantProducto1Canasta[0]>0){		//Cantidad producto 1
				for(x=1;x<=Buffer_LCD1.CantProducto1Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD1.CantProducto1Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.ValorProducto1Canasta[0]>0){		//Valor producto 1
				for(x=1;x<=Buffer_LCD1.ValorProducto1Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD1.ValorProducto1Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.CodigoProductoCanasta2[0]>0){		//Codigo producto 2
				for(x=1;x<=Buffer_LCD1.CodigoProductoCanasta2[0];x++){
	    			Tx_CDG[i]=Buffer_LCD1.CodigoProductoCanasta2[x];
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.CantProducto2Canasta[0]>0){		//Cantidad producto 2
				for(x=1;x<=Buffer_LCD1.CantProducto2Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD1.CantProducto2Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.ValorProducto2Canasta[0]>0){		//Valor producto 2
				for(x=1;x<=Buffer_LCD1.ValorProducto2Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD1.ValorProducto2Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.CodigoProductoCanasta3[0]>0){		//Codigo producto 3
				for(x=1;x<=Buffer_LCD1.CodigoProductoCanasta3[0];x++){
	    			Tx_CDG[i]=Buffer_LCD1.CodigoProductoCanasta3[x];
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.CantProducto3Canasta[0]>0){		//Cantidad producto 3
				for(x=1;x<=Buffer_LCD1.CantProducto3Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD1.CantProducto3Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.ValorProducto3Canasta[0]>0){		//Valor producto 3
				for(x=1;x<=Buffer_LCD1.ValorProducto3Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD1.ValorProducto3Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.CodigoProductoCanasta4[0]>0){		//Codigo producto 4
				for(x=1;x<=Buffer_LCD1.CodigoProductoCanasta4[0];x++){
	    			Tx_CDG[i]=Buffer_LCD1.CodigoProductoCanasta4[x];
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.CantProducto4Canasta[0]>0){		//Cantidad producto 4
				for(x=1;x<=Buffer_LCD1.CantProducto4Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD1.CantProducto4Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.ValorProducto4Canasta[0]>0){		//Valor producto 4
				for(x=1;x<=Buffer_LCD1.ValorProducto4Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD1.ValorProducto4Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.ValorTotalProdCanasta[0]>0){		//Valor TOTAL
				for(x=1;x<=Buffer_LCD1.ValorTotalProdCanasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD1.ValorTotalProdCanasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			Tx_CDG[i]=Buffer_LCD1.TipodeVentaCanasta;		//Tipo de venta
			i++;
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD1.IdentCliente[0]>0){		//Identificacion cliente
				for(x=1;x<=Buffer_LCD1.IdentCliente[0];x++){
	    			Tx_CDG[i]=Buffer_LCD1.IdentCliente[x];
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			Tx_CDG[i]='2';		//Confirmacion para impresion
			i++;
			Tx_CDG[i]=';';
			i++;
			y=IdentVendedor[0];
			for(x=1;x<=y;x++){
				Tx_CDG[i]=IdentVendedor[x];	//Identificacion Vendedor
				i++;
				if(x>17){
					y=18;
				}
			}
			Tx_CDG[i]=';';
			i++;
		}
	}else if(posicion==lado.b.dir){
		if(id==0xB1 || id==0xF7){//Contado Control ó credito ó Canastilla credito
			j=1;
    		for(x=Buffer_LCD2.IdentCliente[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD2.IdentCliente[j];
    			j++;
    			i++;
    		}
			Tx_CDG[i]=';';
			i++;
			j=1;
    		for(x=Buffer_LCD2.KmID[0];x>0;x--){
    			Tx_CDG[i]=Buffer_LCD2.KmID[j];
    			j++;
    			i++;
    		}
			Tx_CDG[i]=';';
			i++;
			if(id==0xB1){
				Tx_CDG[i]='1';//1 si es ID Combustible
				i++;	
			}else{
				Tx_CDG[i]='0';//0 si es ID Canastilla
				i++;
			}
			Tx_CDG[i]=';';
			i++;
		}else if(id==0xFD){//Reconocimiento de producto en Canastilla
			for(x=1;x<=Rx_Pistola[0];x++){
    			Tx_CDG[i]=Rx_Pistola[x];
    			i++;
    		}
			Tx_CDG[i]=';';
			i++;
		}else if(id==0xA8){//Venta finalizada en canastilla
			for(x=1;x<=Buffer_LCD2.FechaVentaCanastilla[0];x++){//Fecha venta canastilla
    			Tx_CDG[i]=Buffer_LCD2.FechaVentaCanastilla[x];
    			i++;
    		}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.CodigoProductoCanasta1[0]>0){		//Codigo producto 1
				for(x=1;x<=Buffer_LCD2.CodigoProductoCanasta1[0];x++){
	    			Tx_CDG[i]=Buffer_LCD2.CodigoProductoCanasta1[x];
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.CantProducto1Canasta[0]>0){		//Cantidad producto 1
				for(x=1;x<=Buffer_LCD2.CantProducto1Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD2.CantProducto1Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.ValorProducto1Canasta[0]>0){		//Valor producto 1
				for(x=1;x<=Buffer_LCD2.ValorProducto1Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD2.ValorProducto1Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.CodigoProductoCanasta2[0]>0){		//Codigo producto 2
				for(x=1;x<=Buffer_LCD2.CodigoProductoCanasta2[0];x++){
	    			Tx_CDG[i]=Buffer_LCD2.CodigoProductoCanasta2[x];
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.CantProducto2Canasta[0]>0){		//Cantidad producto 2
				for(x=1;x<=Buffer_LCD2.CantProducto2Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD2.CantProducto2Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.ValorProducto2Canasta[0]>0){		//Valor producto 2
				for(x=1;x<=Buffer_LCD2.ValorProducto2Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD2.ValorProducto2Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.CodigoProductoCanasta3[0]>0){		//Codigo producto 3
				for(x=1;x<=Buffer_LCD2.CodigoProductoCanasta3[0];x++){
	    			Tx_CDG[i]=Buffer_LCD2.CodigoProductoCanasta3[x];
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.CantProducto3Canasta[0]>0){		//Cantidad producto 3
				for(x=1;x<=Buffer_LCD2.CantProducto3Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD2.CantProducto3Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.ValorProducto3Canasta[0]>0){		//Valor producto 3
				for(x=1;x<=Buffer_LCD2.ValorProducto3Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD2.ValorProducto3Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.CodigoProductoCanasta4[0]>0){		//Codigo producto 4
				for(x=1;x<=Buffer_LCD2.CodigoProductoCanasta4[0];x++){
	    			Tx_CDG[i]=Buffer_LCD2.CodigoProductoCanasta4[x];
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.CantProducto4Canasta[0]>0){		//Cantidad producto 4
				for(x=1;x<=Buffer_LCD2.CantProducto4Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD2.CantProducto4Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.ValorProducto4Canasta[0]>0){		//Valor producto 4
				for(x=1;x<=Buffer_LCD2.ValorProducto4Canasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD2.ValorProducto4Canasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.ValorTotalProdCanasta[0]>0){		//Valor TOTAL
				for(x=1;x<=Buffer_LCD2.ValorTotalProdCanasta[0];x++){
	    			Tx_CDG[i]=(Buffer_LCD2.ValorTotalProdCanasta[x]&0x0f)+0x30;
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			Tx_CDG[i]=Buffer_LCD2.TipodeVentaCanasta;		//Tipo de venta
			i++;
			Tx_CDG[i]=';';
			i++;
			if(Buffer_LCD2.IdentCliente[0]>0){		//Identificacion cliente
				for(x=1;x<=Buffer_LCD2.IdentCliente[0];x++){
	    			Tx_CDG[i]=Buffer_LCD2.IdentCliente[x];
	    			i++;
	    		}
			}else{
				Tx_CDG[i]='0';
				i++;
			}
			Tx_CDG[i]=';';
			i++;
			Tx_CDG[i]='2';		//Confirmacion para impresion
			i++;
			Tx_CDG[i]=';';
			i++;
			y=IdentVendedor[0];
			for(x=1;x<=y;x++){
				Tx_CDG[i]=IdentVendedor[x];	//Identificacion Vendedor
				i++;
				if(x>17){
					y=18;
				}
			}
			Tx_CDG[i]=';';
			i++;
		}
	}
	Tx_CDG[15]=i;//Numero de Bytes a enviar
}

/*
*********************************************************************************************************
*                                         void envioturno()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void envioturno(uint8 posicion){
	uint8 digito2;
    uint32 i,j,x;
	i=1;
	Tx_CDG[i]='M';
	i++;
	Tx_CDG[i]='U';
	i++;
	Tx_CDG[i]='X';
	i++;
	for(j=1;j<=10;j++){
		Tx_CDG[i]=(DirMuxDef[j]);
		i++;
	}
    Tx_CDG[i]=posicion;//Posicion
	i++;
	Tx_CDG[i]=i;//Byte informacion de la cantidad de datos a enviar
	i++;
	Tx_CDG[i]=';';
	i++;
	j=1;
	for(x=IdentVendedor[0];x>0;x--){	//Identificacion del vendedor
		Tx_CDG[i]=IdentVendedor[j];
		j++;
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	for(x=1;x<=FechaInicialTurno[0];x++){			//Fecha inicial turno
		Tx_CDG[i]=FechaInicialTurno[x];
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=lado.a.dir;							//Posicion Lado 1
	i++;
	Tx_CDG[i]=';';
	i++;
	digito2=0;
	if(PPU1Lado1[0]>0){
		for(x=1;x<=PPU1Lado1[0];x++){				//PPU 1 Lado 1
			if((PPU1Lado1[x]==0)&&(digito2==0)){
				
			}else{
				digito2=1;
				Tx_CDG[i]=PPU1Lado1[x]+0x30;
				i++;
			}
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalDinero1Lado1[0]>0){
		for(x=1;x<=TotalDinero1Lado1[0];x++){		//Dinero 1 Lado 1
			Tx_CDG[i]=TotalDinero1Lado1[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalVolumen1Lado1[0]>0){
		for(x=1;x<=TotalVolumen1Lado1[0];x++){		//Volumen 1 Lado 1
			Tx_CDG[i]=TotalVolumen1Lado1[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	digito2=0;
	if(PPU2Lado1[0]>0){
		for(x=1;x<=PPU2Lado1[0];x++){				//PPU 2 Lado 1
			if((PPU2Lado1[x]==0)&&(digito2==0)){
			
			}else{
				digito2=1;
				Tx_CDG[i]=PPU2Lado1[x]+0x30;
				i++;
			}
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalDinero2Lado1[0]>0){
		for(x=1;x<=TotalDinero2Lado1[0];x++){		//Dinero 2 Lado 1
			Tx_CDG[i]=TotalDinero2Lado1[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalVolumen2Lado1[0]>0){
		for(x=1;x<=TotalVolumen2Lado1[0];x++){		//Volumen 2 Lado 1
			Tx_CDG[i]=TotalVolumen2Lado1[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	digito2=0;
	if(PPU3Lado1[0]>0){
		for(x=1;x<=PPU3Lado1[0];x++){				//PPU 3 Lado 1
			if((PPU3Lado1[x]==0)&&(digito2==0)){
			
			}else{
				digito2=1;
				Tx_CDG[i]=PPU3Lado1[x]+0x30;
				i++;
			}
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalDinero3Lado1[0]>0){
		for(x=1;x<=TotalDinero3Lado1[0];x++){		//Dinero 3 Lado 1
			Tx_CDG[i]=TotalDinero3Lado1[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalVolumen3Lado1[0]>0){
		for(x=1;x<=TotalVolumen3Lado1[0];x++){		//Volumen 3 Lado 1
			Tx_CDG[i]=TotalVolumen3Lado1[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=lado.b.dir;
	i++;
	Tx_CDG[i]=';';
	i++;
	digito2=0;
	if(PPU1Lado2[0]>0){
		for(x=1;x<=PPU1Lado2[0];x++){				//PPU 1 Lado 2
			if((PPU1Lado2[x]==0)&&(digito2==0)){
			
			}else{
				digito2=1;
				Tx_CDG[i]=PPU1Lado2[x]+0x30;
				i++;
			}
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalDinero1Lado2[0]>0){
		for(x=1;x<=TotalDinero1Lado2[0];x++){		//Dinero 1 Lado 2
			Tx_CDG[i]=TotalDinero1Lado2[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalVolumen1Lado2[0]>0){
		for(x=1;x<=TotalVolumen1Lado2[0];x++){		//Volumen 1 Lado 2
			Tx_CDG[i]=TotalVolumen1Lado2[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	digito2=0;
	if(PPU2Lado2[0]>0){
		for(x=1;x<=PPU2Lado2[0];x++){				//PPU2 Lado 2
			if((PPU2Lado2[x]==0)&&(digito2==0)){
			
			}else{
				digito2=1;
				Tx_CDG[i]=PPU2Lado2[x]+0x30;
				i++;
			}
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalDinero2Lado2[0]>0){
		for(x=1;x<=TotalDinero2Lado2[0];x++){		//Dinero 2 Lado 2
			Tx_CDG[i]=TotalDinero2Lado2[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalVolumen2Lado2[0]>0){
		for(x=1;x<=TotalVolumen2Lado2[0];x++){		//Volumen 2 Lado 2
			Tx_CDG[i]=TotalVolumen2Lado2[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	digito2=0;
	if(PPU3Lado2[0]>0){
		for(x=1;x<=PPU3Lado2[0];x++){				//PPU 3 Lado 2
			if((PPU3Lado2[x]==0)&&(digito2==0)){
			
			}else{
				digito2=1;
				Tx_CDG[i]=PPU3Lado2[x]+0x30;
				i++;
			}
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalDinero3Lado2[0]>0){
		for(x=1;x<=TotalDinero3Lado2[0];x++){		//Dinero 3 Lado 2
			Tx_CDG[i]=TotalDinero3Lado2[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	if(TotalVolumen3Lado2[0]>0){
		for(x=1;x<=TotalVolumen3Lado2[0];x++){		//Volumen 3 Lado 2
			Tx_CDG[i]=TotalVolumen3Lado2[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=(!lado.d.turno)+0x30;						//Turno abierto o cerrado
	i++;	
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[15]=i;//Numero de Bytes a enviar
}

/*
*********************************************************************************************************
*                                         void programarPPUID()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void programarPPUID(uint8 lado_LCD){
    uint32 x;
	if(lado_LCD==1){
		if(Buffer_LCD1.NumManguera[1]==1){//Manguera 1
			for(x=0;x<=Buffer_LCD1.PPUClienteID1[0];x++){
			ValorPPU[x]=Buffer_LCD1.PPUClienteID1[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD1.NumManguera[1];
			if(cambiar_precio(lado.a.dir)!=0){
				Buffer_LCD1.BanPPUid=1;//Se activo el cambio de precio
			}
		}
		if(Buffer_LCD1.NumManguera[2]==2){//Manguera 2
			for(x=0;x<=Buffer_LCD1.PPUClienteID2[0];x++){
				ValorPPU[x]=Buffer_LCD1.PPUClienteID2[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD1.NumManguera[2];
			if(cambiar_precio(lado.a.dir)!=0){
				Buffer_LCD1.BanPPUid=1;//Se activo el cambio de precio
			}
		}
		if(Buffer_LCD1.NumManguera[3]==3){//Manguera 3
			for(x=0;x<=Buffer_LCD1.PPUClienteID3[0];x++){
				ValorPPU[x]=Buffer_LCD1.PPUClienteID3[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD1.NumManguera[3];
			if(cambiar_precio(lado.a.dir)!=0){
				Buffer_LCD1.BanPPUid=1;//Se activo el cambio de precio
			}
		}
	}else if(lado_LCD==2){
		if(Buffer_LCD2.NumManguera[1]==1){//Manguera 1
			for(x=0;x<=Buffer_LCD2.PPUClienteID1[0];x++){
			ValorPPU[x]=Buffer_LCD2.PPUClienteID1[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD2.NumManguera[1];
			if(cambiar_precio(lado.b.dir)!=0){
				Buffer_LCD2.BanPPUid=1;//Se activo el cambio de precio
			}
		}
		if(Buffer_LCD2.NumManguera[2]==2){//Manguera 2
			for(x=0;x<=Buffer_LCD2.PPUClienteID2[0];x++){
				ValorPPU[x]=Buffer_LCD2.PPUClienteID2[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD2.NumManguera[2];
			if(cambiar_precio(lado.b.dir)!=0){
				Buffer_LCD2.BanPPUid=1;//Se activo el cambio de precio
			}
		}
		if(Buffer_LCD2.NumManguera[3]==3){//Manguera 3
			for(x=0;x<=Buffer_LCD2.PPUClienteID3[0];x++){
				ValorPPU[x]=Buffer_LCD2.PPUClienteID3[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD2.NumManguera[3];
			if(cambiar_precio(lado.b.dir)!=0){
				Buffer_LCD2.BanPPUid=1;//Se activo el cambio de precio
			}
		}
	}
}

/*
*********************************************************************************************************
*                                         void programarPPUContado()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void programarPPUContado(uint8 lado_LCD){
    uint32 x;
	if(lado_LCD==1){
		if(Buffer_LCD1.NumManguera[1]==1){//Manguera 1
			for(x=0;x<=Buffer_LCD1.PPUClienteContado1[0];x++){
			ValorPPU[x]=Buffer_LCD1.PPUClienteContado1[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD1.NumManguera[1];
			Buffer_LCD1.BanPPUid=0;//Se volvio al ppu contado
			if(cambiar_precio(lado.a.dir)!=0){
				write_eeprom(128,ValorPPU);
			}
		}
		if(Buffer_LCD1.NumManguera[2]==2){//Manguera 2
			for(x=0;x<=Buffer_LCD1.PPUClienteContado2[0];x++){
			ValorPPU[x]=Buffer_LCD1.PPUClienteContado2[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD1.NumManguera[2];
			Buffer_LCD1.BanPPUid=0;//Se volvio al ppu contado
			if(cambiar_precio(lado.a.dir)!=0){
				write_eeprom(136,ValorPPU);
			}
		}
		if(Buffer_LCD1.NumManguera[3]==3){//Manguera 3
			for(x=0;x<=Buffer_LCD1.PPUClienteContado3[0];x++){
			ValorPPU[x]=Buffer_LCD1.PPUClienteContado3[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD1.NumManguera[3];
			Buffer_LCD1.BanPPUid=0;//Se volvio al ppu contado
			if(cambiar_precio(lado.a.dir)!=0){
				write_eeprom(144,ValorPPU);
			}
		}
	}else if(lado_LCD==2){
		if(Buffer_LCD2.NumManguera[1]==1){//Manguera 1
			for(x=0;x<=Buffer_LCD2.PPUClienteContado1[0];x++){
			ValorPPU[x]=Buffer_LCD2.PPUClienteContado1[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD2.NumManguera[1];
			Buffer_LCD2.BanPPUid=0;//Se volvio al ppu contado
			if(cambiar_precio(lado.b.dir)!=0){
				write_eeprom(159,ValorPPU);
			}
		}
		if(Buffer_LCD2.NumManguera[2]==2){//Manguera 2
			for(x=0;x<=Buffer_LCD2.PPUClienteContado2[0];x++){
			ValorPPU[x]=Buffer_LCD2.PPUClienteContado2[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD2.NumManguera[2];
			Buffer_LCD2.BanPPUid=0;//Se volvio al ppu contado
			if(cambiar_precio(lado.b.dir)!=0){
				write_eeprom(167,ValorPPU);
			}
		}
		if(Buffer_LCD2.NumManguera[3]==3){//Manguera 3
			for(x=0;x<=Buffer_LCD2.PPUClienteContado3[0];x++){
			ValorPPU[x]=Buffer_LCD2.PPUClienteContado3[x];
			}
			Digitosppu=ValorPPU[0];
			rventa.producto=Buffer_LCD2.NumManguera[3];
			Buffer_LCD2.BanPPUid=0;//Se volvio al ppu contado
			if(cambiar_precio(lado.b.dir)!=0){
				write_eeprom(175,ValorPPU);
			}
		}
	}
}


/*
*********************************************************************************************************
*                                         void programarEquipo()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void programarEquipo(){
	uint8 ProgramarDig[4],ProgramarC1[4],ProgramarE1[4],ProgramarD1[4],ProgramarC2[4],ProgramarE2[4];
    uint8 ProgramarD2[4],ProgramarPPU[4],ProgramarPO[4],ProgramarDD[4],ProgramarDV[4];
	uint32 i,j;
	rventa.fecha[2]=(Rx_CDG[17]&0x0F)<<4;	//Decenas de año
	rventa.fecha[2]|=(Rx_CDG[18]&0x0F);		//Unidades de año
	rventa.fecha[1]=(Rx_CDG[19]&0x0F)<<4;	//Decenas de mes
	rventa.fecha[1]|=(Rx_CDG[20]&0x0F);		//Unidades de mes
	rventa.fecha[0]=(Rx_CDG[21]&0x0F)<<4; 	//Decenas de dia
	rventa.fecha[0]|=(Rx_CDG[22]&0x0F);		//Unidades de dia
	write_fecha();
	rventa.hora[2]=(Rx_CDG[23]&0x0F)<<4;	//Decenas de hora
	rventa.hora[2]|=(Rx_CDG[24]&0x0F);		//Unidades de Hora
	rventa.hora[1]=(Rx_CDG[25]&0x0F)<<4;	//Decenas de Minutos
	rventa.hora[1]|=(Rx_CDG[26]&0x0F);		//Unidades de Minutos
    rventa.hora[0]=(Rx_CDG[27]&0x0F)<<4;	//Decenas de Segundos
	rventa.hora[0]|=(Rx_CDG[28]&0x0F);		//Unidades de Segundos
	write_hora();
	lado.c.versdig=Rx_CDG[29]&0x07;//Version de digitos del surtidor
	ProgramarDig[0]=1;
	ProgramarDig[1]=lado.c.versdig;//Version de digitos del surtidor
	write_eeprom(192,ProgramarDig);
	corriente=Rx_CDG[30]&0x03;
    ProgramarC1[0]=1;
	ProgramarC1[1]=corriente;//Manguera Corriente 1 del surtidor
	write_eeprom(194,ProgramarC1);
    extra=Rx_CDG[31]&0x03;
	ProgramarE1[0]=1;
	ProgramarE1[1]=extra;//Manguera Extra 1 del surtidor
	write_eeprom(196,ProgramarE1);
    diesel=Rx_CDG[32]&0x03;
	ProgramarD1[0]=1;
	ProgramarD1[1]=diesel;//Manguera Diesel 1 del surtidor
	write_eeprom(198,ProgramarD1);
    corriente2=Rx_CDG[33]&0x03;
	ProgramarC2[0]=1;
	ProgramarC2[1]=corriente2;//Manguera Corriente 2 del surtidor
	write_eeprom(200,ProgramarC2);
    extra2=Rx_CDG[34]&0x03;
	ProgramarE2[0]=1;
	ProgramarE2[1]=extra2;//Manguera Extra 2 del surtidor
	write_eeprom(202,ProgramarE2);
    diesel2=Rx_CDG[35]&0x03;
	ProgramarD2[0]=1;
	ProgramarD2[1]=diesel2;//Manguera Diesel 2 del surtidor
	write_eeprom(204,ProgramarD2);
    ppux10=Rx_CDG[36]&0x01;
	ProgramarPPU[0]=1;
	ProgramarPPU[1]=ppux10;//PPU x 10 del surtidor
	write_eeprom(206,ProgramarPPU);
    Placa_Contado=Rx_CDG[37]&0x01;
	ProgramarPO[0]=1;
	ProgramarPO[1]=Placa_Contado;//Placa obligatoria
	write_eeprom(208,ProgramarPO);
    decimalD=Rx_CDG[38]&0x0F;
	ProgramarDD[0]=1;
	ProgramarDD[1]=decimalD;//Decimales de dinero
	write_eeprom(210,ProgramarDD);
    decimalV=Rx_CDG[39]&0x0F;
	ProgramarDV[0]=1;
	ProgramarDV[1]=decimalV;//Decimales de volumen
	write_eeprom(212,ProgramarDV);
	rventa.nombre[0]=30;
	for(i=1;i<=30;i++){
		rventa.nombre[i]=Rx_CDG[i+39];	//Nombre de la estación
	}
	write_eeprom(0,rventa.nombre);
	rventa.direccion[0]=30;
	for(i=1;i<=30;i++){
		rventa.direccion[i]=Rx_CDG[i+69];//Direccion de la estación
	}
	write_eeprom(64,rventa.direccion);
	rventa.lema1[0]=30;
	for(i=1;i<=30;i++){
		rventa.lema1[i]=Rx_CDG[i+99];	//lema1 de la estación
	}
	write_eeprom(31,rventa.lema1);
	rventa.lema2[0]=30;
	for(i=1;i<=30;i++){
		rventa.lema2[i]=Rx_CDG[i+129];	//lema2 de la estación
	}
	write_eeprom(95,rventa.lema2);
    j=lado.c.versdig;
    Buffer_LCD1.P1[0]=lado.c.versdig;
    Buffer_LCD2.P1[0]=lado.c.versdig;
    for(i=1;i<=lado.c.versdig;i++){     //Preset P1
        Buffer_LCD1.P1[i]=Rx_CDG[i+159];
        Buffer_LCD2.P1[i]=Rx_CDG[i+159];
    }
    write_eeprom(655,Buffer_LCD1.P1);
    Buffer_LCD1.P2[0]=lado.c.versdig;
    Buffer_LCD2.P2[0]=lado.c.versdig;
    for(i=1;i<=lado.c.versdig;i++){     //Preset P2
        Buffer_LCD1.P2[i]=Rx_CDG[j+i+159];
        Buffer_LCD2.P2[i]=Rx_CDG[j+i+159];
    }
    write_eeprom(663,Buffer_LCD1.P2);
    Buffer_LCD1.P3[0]=lado.c.versdig;
    Buffer_LCD2.P3[0]=lado.c.versdig;
    for(i=1;i<=lado.c.versdig;i++){     //Preset P3
        Buffer_LCD1.P3[i]=Rx_CDG[(j*2)+i+159];
        Buffer_LCD2.P3[i]=Rx_CDG[(j*2)+i+159];
    }
    write_eeprom(983,Buffer_LCD1.P3);
}

/*
*********************************************************************************************************
*                                         void DatosTurno()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void DatosTurno(){
    uint32 x,i;
	if(leer_fecha()==1){//Lectura de Fecha Apertura
		FechaInicialTurno[0]=14;
		FechaInicialTurno[1]=0x32;
		FechaInicialTurno[2]=0x30;
		FechaInicialTurno[3]=(((rventa.fecha[2]&0xF0)>>4)+48);
		FechaInicialTurno[4]=((rventa.fecha[2]&0x0F)+48);
		FechaInicialTurno[5]=(((rventa.fecha[1]&0x10)>>4)+48);
		FechaInicialTurno[6]=((rventa.fecha[1]&0x0F)+48);
		FechaInicialTurno[7]=(((rventa.fecha[0]&0x30)>>4)+48);
		FechaInicialTurno[8]=((rventa.fecha[0]&0x0F)+48);
	}
	if(leer_hora()==1){//Lectura de Hora Apertura
		FechaInicialTurno[9]=(((rventa.hora[2]&0xF0)>>4)+48);	
		FechaInicialTurno[10]=((rventa.hora[2]&0x0F)+48);
		FechaInicialTurno[11]=(((rventa.hora[1]&0xF0)>>4)+48);
		FechaInicialTurno[12]=((rventa.hora[1]&0x0F)+48);
		FechaInicialTurno[13]=(((rventa.hora[0]&0xF0)>>4)+48);
		FechaInicialTurno[14]=((rventa.hora[0]&0x0F)+48);
	}
	leer_eeprom(128,8);	//PPU Lado1 manguera 1
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			PPU1Lado1[x]=buffer_i2c[x];
		}
	}else{
		PPU1Lado1[0]=0;
	}
	leer_eeprom(136,8);	//PPU Lado1 manguera 2
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			PPU2Lado1[x]=buffer_i2c[x];
		}
	}else{
		PPU2Lado1[0]=0;
	}
	leer_eeprom(144,8);	//PPU Lado1 manguera 3
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			PPU3Lado1[x]=buffer_i2c[x];
		}
	}else{
		PPU3Lado1[0]=0;
	}
	leer_eeprom(159,8);	//PPU Lado2 manguera 1
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			PPU1Lado2[x]=buffer_i2c[x];
		}
	}else{
		PPU1Lado2[0]=0;
	}
	leer_eeprom(167,8);	//PPU Lado2 manguera 2
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			PPU2Lado2[x]=buffer_i2c[x];
		}
	}else{
		PPU2Lado2[0]=0;
	}
	leer_eeprom(175,8);	//PPU Lado2 manguera 3
	if(buffer_i2c[0]>0){
		for(x=0;x<=buffer_i2c[0];x++){
			PPU3Lado2[x]=buffer_i2c[x];
		}
	}else{
		PPU3Lado2[0]=0;
	}
	Buffer_LCD1.TotalVolumen1[0]=0;
	Buffer_LCD1.TotalDinero1[0]=0;
	Buffer_LCD1.TotalVolumen2[0]=0;
	Buffer_LCD1.TotalDinero2[0]=0;
	Buffer_LCD1.TotalVolumen3[0]=0;
	Buffer_LCD1.TotalDinero3[0]=0;
	if(get_totales(lado.a.dir)!=0){
		if(Buffer_LCD1.TotalVolumen1[0]>0){
			for(i=0;i<=Buffer_LCD1.TotalVolumen1[0];i++){
				TotalVolumen1Lado1[i]=Buffer_LCD1.TotalVolumen1[i];
				TotalDinero1Lado1[i]=Buffer_LCD1.TotalDinero1[i];
			}
		}else{
			TotalVolumen1Lado1[0]=0;
			TotalDinero1Lado1[0]=0;
		}
		if(Buffer_LCD1.TotalVolumen2[0]>0){
			for(i=0;i<=Buffer_LCD1.TotalVolumen2[0];i++){
				TotalVolumen2Lado1[i]=Buffer_LCD1.TotalVolumen2[i];
				TotalDinero2Lado1[i]=Buffer_LCD1.TotalDinero2[i];
			}
		}else{
			TotalVolumen2Lado1[0]=0;
			TotalDinero2Lado1[0]=0;
		}
		if(Buffer_LCD1.TotalVolumen3[0]>0){
			for(i=0;i<=Buffer_LCD1.TotalVolumen3[0];i++){
				TotalVolumen3Lado1[i]=Buffer_LCD1.TotalVolumen3[i];
				TotalDinero3Lado1[i]=Buffer_LCD1.TotalDinero3[i];
			}
		}else{
			TotalVolumen3Lado1[0]=0;
			TotalDinero3Lado1[0]=0;
		}
	}
	Buffer_LCD2.TotalVolumen1[0]=0;
	Buffer_LCD2.TotalDinero1[0]=0;
	Buffer_LCD2.TotalVolumen2[0]=0;
	Buffer_LCD2.TotalDinero2[0]=0;
	Buffer_LCD2.TotalVolumen3[0]=0;
	Buffer_LCD2.TotalDinero3[0]=0;
	if(get_totales(lado.b.dir)!=0){
		if(Buffer_LCD2.TotalVolumen1[0]>0){
			for(i=0;i<=Buffer_LCD2.TotalVolumen1[0];i++){
				TotalVolumen1Lado2[i]=Buffer_LCD2.TotalVolumen1[i];
				TotalDinero1Lado2[i]=Buffer_LCD2.TotalDinero1[i];
			}
		}else{
			TotalVolumen1Lado2[0]=0;
			TotalDinero1Lado2[0]=0;
		}
		if(Buffer_LCD2.TotalVolumen2[0]>0){
			for(i=0;i<=Buffer_LCD2.TotalVolumen2[0];i++){
				TotalVolumen2Lado2[i]=Buffer_LCD2.TotalVolumen2[i];
				TotalDinero2Lado2[i]=Buffer_LCD2.TotalDinero2[i];
			}
		}else{
			TotalVolumen2Lado2[0]=0;
			TotalDinero2Lado2[0]=0;
		}
		if(Buffer_LCD2.TotalVolumen3[0]>0){
			for(i=0;i<=Buffer_LCD2.TotalVolumen3[0];i++){
				TotalVolumen3Lado2[i]=Buffer_LCD2.TotalVolumen3[i];
				TotalDinero3Lado2[i]=Buffer_LCD2.TotalDinero3[i];
			}
		}else{
			TotalVolumen3Lado2[0]=0;
			TotalDinero3Lado2[0]=0;
		}
	}
}

/*
*********************************************************************************************************
*                                         void AbrirTurno()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void AbrirTurno(){
	uint8 ProgramarTurno[2];
    ProgramarTurno[0]=1;
	ProgramarTurno[1]=1;
	lado.d.turno=1;
	write_eeprom(256,ProgramarTurno);//Guarga que el turno esta abierto
	CyDelay(10);
	write_eeprom(287,FechaInicialTurno);//Guarga Fecha inicial Turno
	CyDelay(10);
	write_eeprom(128,PPU1Lado1);		//Guarga PPU1 Lado1
	CyDelay(10);
	write_eeprom(136,PPU2Lado1);		//Guarga PPU2 Lado1
	CyDelay(10);
	write_eeprom(144,PPU3Lado1);		//Guarga PPU3 Lado1
	CyDelay(10);
	write_eeprom(159,PPU1Lado2);		//Guarga PPU1 Lado2
	CyDelay(10);
	write_eeprom(167,PPU2Lado2);		//Guarga PPU2 Lado2
	CyDelay(10);
	write_eeprom(175,PPU3Lado2);		//Guarga PPU3 Lado2
	CyDelay(10);
	write_eeprom(320,TotalDinero1Lado1);//Guarga Dinero1 Lado1
	CyDelay(10);
	write_eeprom(333,TotalVolumen1Lado1);//Guarga Volumen1 Lado1
	CyDelay(10);
	write_eeprom(384,TotalDinero2Lado1);//Guarga Dinero2 Lado1
	CyDelay(10);
	write_eeprom(397,TotalVolumen2Lado1);//Guarga Volumen2 Lado1
	CyDelay(10);
	write_eeprom(448,TotalDinero3Lado1);//Guarga Dinero3 Lado1
	CyDelay(10);
	write_eeprom(461,TotalVolumen3Lado1);//Guarga Volumen3 Lado1
	CyDelay(10);
	write_eeprom(351,TotalDinero1Lado2);//Guarga Dinero1 Lado2
	CyDelay(10);
	write_eeprom(364,TotalVolumen1Lado2);//Guarga Volumen1 Lado2
	CyDelay(10);
	write_eeprom(415,TotalDinero2Lado2);//Guarga Dinero2 Lado2
	CyDelay(10);
	write_eeprom(428,TotalVolumen2Lado2);//Guarga Volumen2 Lado2
	CyDelay(10);
	write_eeprom(479,TotalDinero3Lado2);//Guarga Dinero3 Lado2
	CyDelay(10);
	write_eeprom(492,TotalVolumen3Lado2);//Guarga Volumen3 Lado2
	CyDelay(10);
	write_eeprom(223,NombreVendedor);//Guarga Nombre del Vendedor
	CyDelay(10);
	write_eeprom(244,CedulaVendedor);//Guarga Cedula del Vendedor
	//write_eeprom(258,IdentVendedor);//Guarga ID del Vendedor
	//CyDelay(10);
}

/*
*********************************************************************************************************
*                                         void DatosEquipo()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void DatosEquipo(uint8 posicion){
    uint32 i,j,x;
	i=1;
	Tx_CDG[i]='M';
	i++;
	Tx_CDG[i]='U';
	i++;
	Tx_CDG[i]='X';
	i++;
	for(j=1;j<=10;j++){
		Tx_CDG[i]=(DirMuxDef[j]);
		i++;
	}
    Tx_CDG[i]=posicion;//Posicion
	i++;
	Tx_CDG[i]=i;//Byte informacion de la cantidad de datos a enviar
	i++;
	Tx_CDG[i]=';';
	i++;
	if(leer_fecha()==1){//Lectura de Fecha Apertura
		FechaInicialTurno[0]=14;
		Tx_CDG[i]=0x32;
		i++;
		Tx_CDG[i]=0x30;
		i++;
		Tx_CDG[i]=(((rventa.fecha[2]&0xF0)>>4)+48);
		i++;
		Tx_CDG[i]=((rventa.fecha[2]&0x0F)+48);
		i++;
		Tx_CDG[i]=(((rventa.fecha[1]&0x10)>>4)+48);
		i++;
		Tx_CDG[i]=((rventa.fecha[1]&0x0F)+48);
		i++;
		Tx_CDG[i]=(((rventa.fecha[0]&0x30)>>4)+48);
		i++;
		Tx_CDG[i]=((rventa.fecha[0]&0x0F)+48);
		i++;
	}
	if(leer_hora()==1){//Lectura de Hora Apertura
		Tx_CDG[i]=(((rventa.hora[2]&0xF0)>>4)+48);	
		i++;
		Tx_CDG[i]=((rventa.hora[2]&0x0F)+48);
		i++;
		Tx_CDG[i]=(((rventa.hora[1]&0xF0)>>4)+48);
		i++;
		Tx_CDG[i]=((rventa.hora[1]&0x0F)+48);
		i++;
		Tx_CDG[i]=(((rventa.hora[0]&0xF0)>>4)+48);
		i++;
		Tx_CDG[i]=((rventa.hora[0]&0x0F)+48);
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=lado.c.versdig;
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=corriente;
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=extra;
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=diesel;
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=corriente2;
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=extra2;
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=diesel2;
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=ppux10;
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=Placa_Contado;
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=decimalD;
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=decimalV;
	i++;
	Tx_CDG[i]=';';
	i++;
	for(x=1;x<=rventa.nombre[0];x++){
		Tx_CDG[i]=rventa.nombre[x];
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	for(x=1;x<=rventa.direccion[0];x++){
		Tx_CDG[i]=rventa.direccion[x];
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	for(x=1;x<=rventa.lema1[0];x++){
		Tx_CDG[i]=rventa.lema1[x];
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	for(x=1;x<=rventa.lema2[0];x++){
		Tx_CDG[i]=rventa.lema2[x];
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[15]=i;//Numero de Bytes a enviar
}

/*
*********************************************************************************************************
*                                         void DatosUltimoTurno()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void DatosUltimoTurno(uint8 posicion){
    uint32 i,j,x;
	i=1;
	Tx_CDG[i]='M';
	i++;
	Tx_CDG[i]='U';
	i++;
	Tx_CDG[i]='X';
	i++;
	for(j=1;j<=10;j++){
		Tx_CDG[i]=(DirMuxDef[j]);
		i++;
	}
    Tx_CDG[i]=posicion;//Posicion
	i++;
	Tx_CDG[i]=i;//Byte informacion de la cantidad de datos a enviar
	i++;
	Tx_CDG[i]=';';
	i++;
	leer_eeprom(287,15);
	if(buffer_i2c[0]>0){
		for(x=1;x<=buffer_i2c[0];x++){
			Tx_CDG[i]=buffer_i2c[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	leer_eeprom(302,15);
	if(buffer_i2c[0]>0){
		for(x=1;x<=buffer_i2c[0];x++){
			Tx_CDG[i]=buffer_i2c[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	leer_eeprom(258,18);
	if(buffer_i2c[0]>0){
		for(x=1;x<=buffer_i2c[0];x++){
			Tx_CDG[i]=buffer_i2c[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	leer_eeprom(256,2);
	if(buffer_i2c[0]>0){
		for(x=1;x<=buffer_i2c[0];x++){
			Tx_CDG[i]=buffer_i2c[x];
			i++;
		}
	}else{
		Tx_CDG[i]='0';
		i++;
	}
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[15]=i;//Numero de Bytes a enviar
}


/*
*********************************************************************************************************
*                                         void DatosTotalesTurno()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void DatosTotalesTurno(uint8 posicion){
    uint32 i,j,x;
	i=1;
	Tx_CDG[i]='M';
	i++;
	Tx_CDG[i]='U';
	i++;
	Tx_CDG[i]='X';
	i++;
	for(j=1;j<=10;j++){
		Tx_CDG[i]=(DirMuxDef[j]);
		i++;
	}
    Tx_CDG[i]=posicion;//Posicion
	i++;
	Tx_CDG[i]=i;//Byte informacion de la cantidad de datos a enviar
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=lado.a.dir;
	i++;
	Tx_CDG[i]=';';
	i++;
	for(j=0;j<=128;j+=64){
		leer_eeprom(320+j,13);
		if(buffer_i2c[0]>0){
			for(x=1;x<=buffer_i2c[0];x++){
				Tx_CDG[i]=buffer_i2c[x];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		leer_eeprom(333+j,14);
		if(buffer_i2c[0]>0){
			for(x=1;x<=buffer_i2c[0];x++){
				Tx_CDG[i]=buffer_i2c[x];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
	}
	Tx_CDG[i]=lado.b.dir;
	i++;
	Tx_CDG[i]=';';
	i++;
	for(j=0;j<=128;j+=64){
		leer_eeprom(351+j,13);
		if(buffer_i2c[0]>0){
			for(x=1;x<=buffer_i2c[0];x++){
				Tx_CDG[i]=buffer_i2c[x];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		leer_eeprom(364+j,14);
		if(buffer_i2c[0]>0){
			for(x=1;x<=buffer_i2c[0];x++){
				Tx_CDG[i]=buffer_i2c[x];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
	}
	Tx_CDG[15]=i;//Numero de Bytes a enviar
}

/*
*********************************************************************************************************
*                                         void DatosTotalesActuales()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void DatosTotalesActuales(uint8 posicion){
    uint32 i,j;
	i=1;
	Tx_CDG[i]='M';
	i++;
	Tx_CDG[i]='U';
	i++;
	Tx_CDG[i]='X';
	i++;
	for(j=1;j<=10;j++){
		Tx_CDG[i]=(DirMuxDef[j]);
		i++;
	}
    Tx_CDG[i]=posicion;//Posicion
	i++;
	Tx_CDG[i]=i;//Byte informacion de la cantidad de datos a enviar
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=lado.a.dir;
	i++;
	Tx_CDG[i]=';';
	i++;
	Buffer_LCD1.TotalDinero1[0]=0;
	Buffer_LCD1.TotalVolumen1[0]=0;
	Buffer_LCD1.TotalDinero2[0]=0;
	Buffer_LCD1.TotalVolumen2[0]=0;
	Buffer_LCD1.TotalDinero3[0]=0;
	Buffer_LCD1.TotalVolumen3[0]=0;
	if(get_totales(lado.a.dir)!=0){
		if(Buffer_LCD1.TotalDinero1[0]>0){
			for(j=1;j<=Buffer_LCD1.TotalDinero1[0];j++){
				Tx_CDG[i]=Buffer_LCD1.TotalDinero1[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD1.TotalVolumen1[0]>0){
			for(j=1;j<=Buffer_LCD1.TotalVolumen1[0];j++){
				Tx_CDG[i]=Buffer_LCD1.TotalVolumen1[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD1.TotalDinero2[0]>0){
			for(j=1;j<=Buffer_LCD1.TotalDinero2[0];j++){
				Tx_CDG[i]=Buffer_LCD1.TotalDinero2[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD1.TotalVolumen2[0]>0){
			for(j=1;j<=Buffer_LCD1.TotalVolumen2[0];j++){
				Tx_CDG[i]=Buffer_LCD1.TotalVolumen2[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD1.TotalDinero3[0]>0){
			for(j=1;j<=Buffer_LCD1.TotalDinero3[0];j++){
				Tx_CDG[i]=Buffer_LCD1.TotalDinero3[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD1.TotalVolumen3[0]>0){
			for(j=1;j<=Buffer_LCD1.TotalVolumen3[0];j++){
				Tx_CDG[i]=Buffer_LCD1.TotalVolumen3[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
	}
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=lado.b.dir;
	i++;
	Tx_CDG[i]=';';
	i++;
	Buffer_LCD2.TotalDinero1[0]=0;
	Buffer_LCD2.TotalVolumen1[0]=0;
	Buffer_LCD2.TotalDinero2[0]=0;
	Buffer_LCD2.TotalVolumen2[0]=0;
	Buffer_LCD2.TotalDinero3[0]=0;
	Buffer_LCD2.TotalVolumen3[0]=0;
	if(get_totales(lado.b.dir)!=0){
		if(Buffer_LCD2.TotalDinero1[0]>0){
			for(j=1;j<=Buffer_LCD2.TotalDinero1[0];j++){
				Tx_CDG[i]=Buffer_LCD2.TotalDinero1[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD2.TotalVolumen1[0]>0){
			for(j=1;j<=Buffer_LCD2.TotalVolumen1[0];j++){
				Tx_CDG[i]=Buffer_LCD2.TotalVolumen1[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD2.TotalDinero2[0]>0){
			for(j=1;j<=Buffer_LCD2.TotalDinero2[0];j++){
				Tx_CDG[i]=Buffer_LCD2.TotalDinero2[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD2.TotalVolumen2[0]>0){
			for(j=1;j<=Buffer_LCD2.TotalVolumen2[0];j++){
				Tx_CDG[i]=Buffer_LCD2.TotalVolumen2[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD2.TotalDinero3[0]>0){
			for(j=1;j<=Buffer_LCD2.TotalDinero3[0];j++){
				Tx_CDG[i]=Buffer_LCD2.TotalDinero3[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
		if(Buffer_LCD2.TotalVolumen3[0]>0){
			for(j=1;j<=Buffer_LCD2.TotalVolumen3[0];j++){
				Tx_CDG[i]=Buffer_LCD2.TotalVolumen3[j];
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
	}
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[15]=i;//Numero de Bytes a enviar
}

/*
*********************************************************************************************************
*                                         void DatosPPUActuales()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void DatosPPUActuales(uint8 posicion){
    uint32 i,j,x;
	i=1;
	Tx_CDG[i]='M';
	i++;
	Tx_CDG[i]='U';
	i++;
	Tx_CDG[i]='X';
	i++;
	for(j=1;j<=10;j++){
		Tx_CDG[i]=(DirMuxDef[j]);
		i++;
	}
    Tx_CDG[i]=posicion;//Posicion
	i++;
	Tx_CDG[i]=i;//Byte informacion de la cantidad de datos a enviar
	i++;
	Tx_CDG[i]=';';
	i++;
	Tx_CDG[i]=lado.a.dir;
	i++;
	Tx_CDG[i]=';';
	i++;
	for(j=0;j<=16;j+=8){
		leer_eeprom(128+j,8);
		if(buffer_i2c[0]>0){
			for(x=1;x<=buffer_i2c[0];x++){
				Tx_CDG[i]=buffer_i2c[x]+0x30;
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
	}
	Tx_CDG[i]=lado.b.dir;
	i++;
	Tx_CDG[i]=';';
	i++;
	for(j=0;j<=16;j+=8){
		leer_eeprom(159+j,8);
		if(buffer_i2c[0]>0){
			for(x=1;x<=buffer_i2c[0];x++){
				Tx_CDG[i]=buffer_i2c[x]+0x30;
				i++;
			}
		}else{
			Tx_CDG[i]='0';
			i++;
		}
		Tx_CDG[i]=';';
		i++;
	}
	Tx_CDG[15]=i;//Numero de Bytes a enviar
}

/*
*********************************************************************************************************
*                                         void resetvariables()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void resetvariables(uint8 lado_LCD){
    uint32 i;
	if(lado_LCD==1){
		if(Buffer_LCD1.Estado_Mux==0xA6){
			Buffer_LCD1.Estado_Mux=0xA1;
		}
		for(i=0;i<17;i++){	//Para Borrar si se ha digitado Cliente anteriormente
			Buffer_LCD1.IdentCliente[i]=0;
		}
		for(i=0;i<=8;i++){	//Para Borrar si se ha digitado placa anteriormente
			Buffer_LCD1.placa[i]=0;
		}
		for(i=0;i<=10;i++){	//Para Borrar si se ha digitado cedula anteriormente
			Buffer_LCD1.cedula[i]=0;
		}
		for(i=0;i<=10;i++){	//Para Borrar si se ha digitado nit anteriormente
			Buffer_LCD1.Nit[i]=0;
		}
		for(i=0;i<=10;i++){	//Para Borrar si se ha digitado kilometraje anteriormente
			Buffer_LCD1.km[i]=0;
		}
		for(i=0;i<10;i++){  //Para Borrar si se ha digitado Kilometraje ID anteriormente
			Buffer_LCD1.KmID[i]=0;
		}
	}else if(lado_LCD==2){
		if(Buffer_LCD2.Estado_Mux==0xA6){
			Buffer_LCD2.Estado_Mux=0xA1;
		}
		for(i=0;i<17;i++){	//Para Borrar si se ha digitado Cliente anteriormente
			Buffer_LCD2.IdentCliente[i]=0;
		}
		for(i=0;i<=8;i++){	//Para Borrar si se ha digitado placa anteriormente
			Buffer_LCD2.placa[i]=0;
		}
		for(i=0;i<=10;i++){	//Para Borrar si se ha digitado cedula anteriormente
			Buffer_LCD2.cedula[i]=0;
		}
		for(i=0;i<=10;i++){	//Para Borrar si se ha digitado nit anteriormente
			Buffer_LCD2.Nit[i]=0;
		}
		for(i=0;i<=10;i++){	//Para Borrar si se ha digitado kilometraje anteriormente
			Buffer_LCD2.km[i]=0;
		}
		for(i=0;i<10;i++){  //Para Borrar si se ha digitado Kilometraje ID anteriormente
			Buffer_LCD2.KmID[i]=0;
		}
	}
}

/*
*********************************************************************************************************
*                                         void resetvariableslcd()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void resetvariableslcd(uint8 lado_LCD){
    uint32 x,i;
	if(lado_LCD==1){
		for(x=0;x<=20;x++){
			Buffer_LCD1.NombreProducto1Canasta[x]=0;
			Buffer_LCD1.NombreProducto2Canasta[x]=0;
			Buffer_LCD1.NombreProducto3Canasta[x]=0;
			Buffer_LCD1.NombreProducto4Canasta[x]=0;
		}
		for(x=1;x<=20;x++){
			Buffer_LCD1.NombreProducto1Canasta[x]='-';
			Buffer_LCD1.NombreProducto2Canasta[x]='-';
			Buffer_LCD1.NombreProducto3Canasta[x]='-';
			Buffer_LCD1.NombreProducto4Canasta[x]='-';
		}
		for(x=0;x<=20;x++){
			Buffer_LCD1.CodigoProductoCanasta1[x]=0;
			Buffer_LCD1.CodigoProductoCanasta2[x]=0;
			Buffer_LCD1.CodigoProductoCanasta3[x]=0;
			Buffer_LCD1.CodigoProductoCanasta4[x]=0;
		}
		Buffer_LCD1.ValorProducto1Orig=0;
		Buffer_LCD1.ValorProducto2Orig=0;
		Buffer_LCD1.ValorProducto3Orig=0;
		Buffer_LCD1.ValorProducto4Orig=0;
		Buffer_LCD1.ProductoCanasta=0;
		Buffer_LCD1.ValorCant1=0;//Inicializa Valores
		Buffer_LCD1.ValorProducto1=0;//Inicializa Valores
		Buffer_LCD1.ValorCant2=0;//Inicializa Valores
		Buffer_LCD1.ValorProducto2=0;//Inicializa Valores
		Buffer_LCD1.ValorCant3=0;//Inicializa Valores
		Buffer_LCD1.ValorProducto3=0;//Inicializa Valores
		Buffer_LCD1.ValorCant4=0;//Inicializa Valores
		Buffer_LCD1.ValorProducto4=0;//Inicializa Valores
		
		for(i=0;i<=10;i++){//Inicializa productos en cero
			Buffer_LCD1.Producto1Canasta[i]='-';
			Buffer_LCD1.Producto2Canasta[i]='-';
			Buffer_LCD1.Producto3Canasta[i]='-';
			Buffer_LCD1.Producto4Canasta[i]='-';
		}
		for(i=0;i<=3;i++){//Inicializa cantidades en cero
			Buffer_LCD1.CantProducto1Canasta[i]=0;
			Buffer_LCD1.CantProducto2Canasta[i]=0;
			Buffer_LCD1.CantProducto3Canasta[i]=0;
			Buffer_LCD1.CantProducto4Canasta[i]=0;
		}
		for(i=0;i<=7;i++){//Inicializa Valores en cero
			Buffer_LCD1.ValorProducto1Canasta[i]=0;
			Buffer_LCD1.ValorProducto2Canasta[i]=0;
			Buffer_LCD1.ValorProducto3Canasta[i]=0;
			Buffer_LCD1.ValorProducto4Canasta[i]=0;
		}
		for(i=0;i<=8;i++){//Inicializa Total en ceros
			Buffer_LCD1.ValorTotalProdCanasta[i]=0;
		}
	}else if(lado_LCD==2){
		for(x=0;x<=20;x++){
			Buffer_LCD2.NombreProducto1Canasta[x]=0;
			Buffer_LCD2.NombreProducto2Canasta[x]=0;
			Buffer_LCD2.NombreProducto3Canasta[x]=0;
			Buffer_LCD2.NombreProducto4Canasta[x]=0;
		}
		for(x=1;x<=20;x++){
			Buffer_LCD2.NombreProducto1Canasta[x]='-';
			Buffer_LCD2.NombreProducto2Canasta[x]='-';
			Buffer_LCD2.NombreProducto3Canasta[x]='-';
			Buffer_LCD2.NombreProducto4Canasta[x]='-';
		}
		for(x=0;x<=20;x++){
			Buffer_LCD2.CodigoProductoCanasta1[x]=0;
			Buffer_LCD2.CodigoProductoCanasta2[x]=0;
			Buffer_LCD2.CodigoProductoCanasta3[x]=0;
			Buffer_LCD2.CodigoProductoCanasta4[x]=0;
		}
		Buffer_LCD2.ValorProducto1Orig=0;
		Buffer_LCD2.ValorProducto2Orig=0;
		Buffer_LCD2.ValorProducto3Orig=0;
		Buffer_LCD2.ValorProducto4Orig=0;
		Buffer_LCD2.ProductoCanasta=0;
		Buffer_LCD2.ValorCant1=0;//Inicializa Valores
		Buffer_LCD2.ValorProducto1=0;//Inicializa Valores
		Buffer_LCD2.ValorCant2=0;//Inicializa Valores
		Buffer_LCD2.ValorProducto2=0;//Inicializa Valores
		Buffer_LCD2.ValorCant3=0;//Inicializa Valores
		Buffer_LCD2.ValorProducto3=0;//Inicializa Valores
		Buffer_LCD2.ValorCant4=0;//Inicializa Valores
		Buffer_LCD2.ValorProducto4=0;//Inicializa Valores
		
		for(i=0;i<=10;i++){//Inicializa productos en cero
			Buffer_LCD2.Producto1Canasta[i]='-';
			Buffer_LCD2.Producto2Canasta[i]='-';
			Buffer_LCD2.Producto3Canasta[i]='-';
			Buffer_LCD2.Producto4Canasta[i]='-';
		}
		for(i=0;i<=3;i++){//Inicializa cantidades en cero
			Buffer_LCD2.CantProducto1Canasta[i]=0;
			Buffer_LCD2.CantProducto2Canasta[i]=0;
			Buffer_LCD2.CantProducto3Canasta[i]=0;
			Buffer_LCD2.CantProducto4Canasta[i]=0;
		}
		for(i=0;i<=7;i++){//Inicializa Valores en cero
			Buffer_LCD2.ValorProducto1Canasta[i]=0;
			Buffer_LCD2.ValorProducto2Canasta[i]=0;
			Buffer_LCD2.ValorProducto3Canasta[i]=0;
			Buffer_LCD2.ValorProducto4Canasta[i]=0;
		}
		for(i=0;i<=8;i++){//Inicializa Total en ceros
			Buffer_LCD2.ValorTotalProdCanasta[i]=0;
		}
	}
}

/*
*********************************************************************************************************
*                                         void escribir_ram()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void escribir_ram(uint16 page, uint8 *valor, uint8 pos){
    uint32 i;
    if(pos==1){
        for(i=0;i<=valor[0];i++){
            Buffer_LCD1.ventaspendientesRAM[page+i]=valor[i];
        }
    }else{
        for(i=0;i<=valor[0];i++){
            Buffer_LCD2.ventaspendientesRAM[page+i]=valor[i];
        }
    }
}


/* [] END OF FILE */
