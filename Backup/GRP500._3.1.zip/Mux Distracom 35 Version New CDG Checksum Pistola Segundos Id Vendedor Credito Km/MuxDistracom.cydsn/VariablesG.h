/*
*********************************************************************************************************
*                                           GRP550/700 CODE
*
*                             (c) Copyright 2013; Sistemas Insepet LTDA
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                             GRP550/700 CODE
*
*                                             CYPRESS PSoC5LP
*                                                with the
*                                            CY8C5969AXI-LP035
*
* Filename      : VariablesG.h
* Version       : V1.00
* Programmer(s) : 
                  
*********************************************************************************************************
*/

#ifndef VARIABLESG_H
#define VARIABLESG_H
#include <device.h>	
#define iprotector     30 //Protector de Pantalla
	
/*  
-------------------------------------polling_LCD-----------------------------------	
100	Inicio de protector
0   Protector de Pantalla
1   Esperando a presionar la pantalla
2   Pasa a pantalla inicial de opciones y limpia el buffer
3	Menu Principal
4	Venta de Combustibles
5	Venta Combustible de Contado
6	Digite valor a tanquear
7	Esperando a subir la manija para programar el equipo
8	Coloca datos digitados durante el tanqueo en pantalla
9	Tanqueando, introduzca datos 
10	Digite Placa para datos
11	Digite Placa Obligatoria
12	Teclado para digitar Cedula, Nit, Km y N° de Fuel Control
13	Imprimir Venta Combustible
14	Esperando trama de impresion por sistema
15	Venta Combustible de Credito
16	Lectura de Ibutton
17	Lectura de Tarjeta RFID
18	Esperando Autorizacion para venta de Contado Control
19	Suministro autorizado
20	Suministro NO autorizado
21	Seleccion de venta en dinero, volumen o full
22	Full no autorizado
23	Digite valor a tanquear para Credito y Contado Control
24	Esperando a subir la manija para programar el equipo por sistema autorizado
25	Tanqueando sin datos
26	Esperando autorizacion para traslados o calibracion
27	Menu para Turnos
28	Esperando ID del Vendedor para apertura de turno
29	Recopilando datos para apertura de turno
30	Esperando Autorizacion para Apertura de Turno
31  Abrir turno sin sistema
32	Confirmacion para cierre de Turno
33	Esperando Autorizacion para Cierre de Turno
34	Esperando trama de impresion para cierre de turno	
35	Menu de canastilla
36	Venta Canastilla de Credito
37	Esperando Autorizacion para Venta de Canastilla en Credito
38	Suministro autorizado de canastilla
39	Formulario de Canastilla
40	Lectura de codigo de barras
41	Esperando reconocimiento de producto canastilla
42	Esperando aprobacion para fin de venta de canastilla
43  Esperando impresion de ultima venta
44  Informacion Mux
45  Lectura Codigo de Barras Cliente
-----------------------------------------------------------------------------------
*/
	
uint8 flujo_LCD,flujo_LCD2,flujo_DirMux,flujo_Pro_CDG,flujo_envia_CDG,flujo_pos_surt;
uint32 count_protector,count_protector2;		    			        //Contadores del protector de pantalla
uint64 count_rf;                                                        //Contadores de recepcion RF
uint8 teclas1,teclas2, comas1, comas2;  							    //Auxiliares para las funciones del teclado y organizacion de datos
uint8 Digitosppu;														//Carga la cantidad de digitos a cambia ppu	
uint8 versurt;															//Determina la version entre (1)no_extendida y (2)extendida
uint8 extra,diesel,corriente,extra2,corriente2,diesel2;					//Banderas para saber que productos hay
uint16 buffer_i2c[64];													//Buffer de lectura del i2c 
uint16 resultado[17];													//Buffer que almacena el resultado de una operacion				
uint8 ppux10;															//Indica si el PPU esta x10		
uint8 decimalV;															//Cantidad de Decimales en volumen
uint8 decimalD;															//Cantidad de decimales en dinero
uint8 print1[2], print2[2];												//Puerto de las impresoras
uint16 Rx_CDG[1600];													//Recibe datos del CDG 
uint16 Tx_CDG[1000];													//Envia datos al CDG
uint8 Rx_Pistola[50];													//Recibe datos de la pistola de codigo de barras
uint8 DireccionMux;														//Bandera que habilita colocar direccion de Mux ó no
uint8 FechaInicialTurno[18];											//Al momento de Abrir un turno, se registra la hora
uint8 FechaFinalTurno[18];												//Al momento de Cerrar un turno, se registra la hora
uint8 TotalVolumen1Lado1[20];											//Guarda el total de volumen de la manguera 1 Lado 1			
uint8 TotalDinero1Lado1[20];											//Guarda el total de dinero de la manguera 1 Lado 1
uint8 PPU1Lado1[10];													//Guarda el PPU de la manguera 1 Lado 1
uint8 TotalVolumen2Lado1[20];											//Guarda el total de volumen de la manguera 2 Lado 1			
uint8 TotalDinero2Lado1[20];											//Guarda el total de dinero de la manguera 2 Lado 1
uint8 PPU2Lado1[10];													//Guarda el PPU de la manguera 2 Lado 1
uint8 TotalVolumen3Lado1[20];											//Guarda el total de volumen de la manguera 3 Lado 1			
uint8 TotalDinero3Lado1[20];											//Guarda el total de dinero de la manguera 2 Lado 1
uint8 PPU3Lado1[10];													//Guarda el PPU de la manguera 3 Lado 1
uint8 TotalVolumen1Lado2[20];											//Guarda el total de volumen de la manguera 1 Lado 2			
uint8 TotalDinero1Lado2[20];											//Guarda el total de dinero de la manguera 1 Lado 2
uint8 PPU1Lado2[10];													//Guarda el PPU de la manguera 1 Lado 2
uint8 TotalVolumen2Lado2[20];											//Guarda el total de volumen de la manguera 2 Lado 2			
uint8 TotalDinero2Lado2[20];											//Guarda el total de dinero de la manguera 2 Lado 2
uint8 PPU2Lado2[10];													//Guarda el PPU de la manguera 2 Lado 2
uint8 TotalVolumen3Lado2[20];											//Guarda el total de volumen de la manguera 3 Lado 2			
uint8 TotalDinero3Lado2[20];											//Guarda el total de dinero de la manguera 2 Lado 2
uint8 PPU3Lado2[10];													//Guarda el PPU de la manguera 3 Lado 2
uint8 NombreVendedor[25];												//Guarda el Nombre del vendedor que envian por sistema
uint8 CedulaVendedor[14];												//Guarda la Cedula del vendedor que envian por sistema
uint8 IdentVendedor[20];												//Carga el valor de indentificacion del vendedor
uint8 ValorPPU[30];														//Dentro del metodo Cambiar precio
uint8 DirMuxPrueba[18];													//Dato para validar direccion de Mux
uint8 DirMuxDef[18];													//direccion de Mux
uint8 Placa_Contado;													//Habilita placa obligatoria o No
uint8 ResultadoCheck;													//Da el resultado checksum de la trama a enviar
	

struct buffer{
    uint8 P1[10];                           //Carga un preset definido por el sistema
    uint8 P2[10];                           //Carga un preset definido por el sistema               
    uint8 P3[10];                           //Carga un preset definido por el sistema
	uint8 IdentCliente[30];					//Carga el valor de indentificacion del cliente
	uint8 FechaCliente[12];					//Guarda la fecha de vencimiento del recibo
	uint8 NombreCliente[45];				//Guarda el Nombre del cliente al realizar una validacion
	uint8 NitCliente[14];					//Guarda el Nit del cliente al realizar una validacion
	uint8 DireccionCliente[45];				//Guarda la Direccion del cliente al realizar una validacion
	uint8 PlacaCliente[14];					//Guarda la Placa del cliente al realizar una validacion
	uint8 TelCliente[15];					//Guarda el Telefono del cliente al realizar una validacion	
	uint8 valor[30];						//Guarda el valor para programar el equipo
	uint8 preset;							//Identifica por cual preset se va a realizar la programacion del equipo
	uint8 placa[12];						//Obtiene los datos digitados de placa
	uint8 cedula[14];						//Obtiene los datos digitados de cedula
	uint8 Nit[14];							//Obtiene los datos digitados de Nit
	uint8 km[14];							//Obtiene los datos digitados de Kilometraje
	uint8 Numeros[14];						//Guarda por un instante los datos digitados de ced, nit y Km y luego los guarda en sus respectivas variables
	uint8 CompTeclado;						//Compara que teclado se selecciono para direccionar los datos a ced, nit, Km o N° Fuel Control
	uint8 CompID;							//Compara que Flujo se selccionopara direccionar Ibutton o RFID
	uint8 id[18];							//Captura por un instante datos de ibutton y Tarjeta RFID
	uint8 FechaInicialVenta[18];			//Al momento de autorizar el surtidor, se registra la hora a la que se levanta la manija o al final venta
	uint8 FechaFinalVenta[18];				//Al momento de autorizar el surtidor, se registra la hora al final venta
	uint8 PresetProgramado;					//Carga que preset se selecciono, Dinero (D), Volumen(V), o Full(F)
	uint8 TipodeVenta;						//Carga que tipo de venta se genero, si Contado, Contado Control, Credito, Calibracion o Traslados
	uint8 ValorPreset[30];					//Guarda el valor del preset, al tiempo que lo hace la variable valor
	uint8 NumManguera[7];					//Guarda el numero de manguera a programar ppu
	uint8 PPUClienteID1[14];				//Cuando se autoriza una venta por credito, se almacena el ppu autorizado para cambiar el PPU de manguera 1
	uint8 PPUClienteContado1[14];			//Es el PPU autorizado para vernder por contado  de manguera 1
	uint8 PPUClienteID2[14];				//Cuando se autoriza una venta por credito, se almacena el ppu autorizado para cambiar el PPU de manguera 2
	uint8 PPUClienteContado2[14];			//Es el PPU autorizado para vernder por contado  de manguera 2
	uint8 PPUClienteID3[14];				//Cuando se autoriza una venta por credito, se almacena el ppu autorizado para cambiar el PPU de manguera 30
	uint8 PPUClienteContado3[14];			//Es el PPU autorizado para vernder por contado  de manguera 3
	uint8 BanPPUid;							//Bandera para volver al ppu normal despues de haber finalizado un tanqueo
	uint8 BanImpFin;						//Bandera que avisa cuando se termino la trama de la impresion
	uint8 KmID[11];							//Obtiene el dato digitado de Kilometraje para validacion de cliente ID (Credito y Contado Control)
	float preset_entero, max_din, max_volu;	//Auxiliares para operaciones grandes
	uint8 TotalVolumen1[20];				//Guarda el total de volumen de la manguera 1 			
	uint8 TotalDinero1[20];					//Guarda el total de dinero de la manguera 1 
	uint8 TotalVolumen2[20];				//Guarda el total de volumen de la manguera 2 			
	uint8 TotalDinero2[20];					//Guarda el total de dinero de la manguera 2 
	uint8 TotalVolumen3[20];				//Guarda el total de volumen de la manguera 3 			
	uint8 TotalDinero3[20];					//Guarda el total de dinero de la manguera 3 
	uint8 TotalVolumenAnterior[20];			//Guarda el total de volumen de la manguera seleccionada antes de la venta	
	uint8 TotalDineroAnterior[20];			//Guarda el total de dinero de la manguera seleccionada antes de la venta 	
	uint8 AutorizacionTrasCali;				//Bandera que autoriza Tanquear pór Traslados o Calibracion
	uint8 AutorizacionApertTurno;			//Bandera que autoriza Abrir Turno
	uint8 AutorizacionCierreTurno;			//Bandera que autoriza Cerrar Turno
	uint8 ConfirmacionImpresion;			//Bandera que confirma si se espera formato de impresion o NO se espera
	uint8 MensajePublicar[55];				//Mensajes a publicar por sistema
	uint8 VentaPPU[10];						//Guarda la venta de PPU actual
    uint8 VentaDinero[14];					//Guarda la venta de Dinero actual
    uint8 VentaVolumen[14];					//Guarda la venta de Volumen actual
	uint8 AutorizacionControl;              
	uint8 PresetAutControl;
	uint8 FullAutControl;
	uint8 ValorTanqueoControl[14];
	uint8 VentasPendientesE;				//Almacena 50 ventas que no se han solicitado por sistema en la EEPROM
    uint8 VentasPendientesR;                //Almacena 3 ventas que no se han solicitado por sistema en la RAM
	uint8 AutorizacionCreditoCanasta;		//Bandera que autoriza el credito de canastilla
	uint8 ValorCupoCanasta[14];				//Guarda el cupo que tiene para comprar en canastilla en vectores
	uint32 ValorCupoCanastaOri;				//Guarda el cupo que tiene para comprar en canastilla numericamente
	uint8 TipodeVentaCanasta;				//Carga que tipo de venta se genero en canastilla, si Contado ó Credito
	uint8 ProductoCanasta;					//Almacena que numero de producto se selecciono	en canastilla
	uint8 CodigoProductoCanasta1[20];		//Guarda el codigo de barras del producto 1 de canastilla
	uint8 CodigoProductoCanasta2[20];		//Guarda el codigo de barras del producto 2 de canastilla
	uint8 CodigoProductoCanasta3[20];		//Guarda el codigo de barras del producto 3 de canastilla
	uint8 CodigoProductoCanasta4[20];		//Guarda el codigo de barras del producto 4 de canastilla
	uint8 NombreProducto1Canasta[24];		//Guarda el nombre del producto 1 para mostrar al usuario
	uint8 NombreProducto2Canasta[24];		//Guarda el nombre del producto 2 para mostrar al usuario
	uint8 NombreProducto3Canasta[24];		//Guarda el nombre del producto 3 para mostrar al usuario
	uint8 NombreProducto4Canasta[24];		//Guarda el nombre del producto 4 para mostrar al usuario
	uint8 BandAutorCredCanasta;				//Verifica si era una venta de credito en canastilla al momento de reconocer productos
	uint8 ValorProducto1Canasta[10];		//Guarda el valor del producto 1 reconocido en caracteres
	uint8 ValorProducto2Canasta[10];		//Guarda el valor del producto 2 reconocido en caracteres
	uint8 ValorProducto3Canasta[10];		//Guarda el valor del producto 3 reconocido en caracteres
	uint8 ValorProducto4Canasta[10];		//Guarda el valor del producto 4 reconocido en caracteres
	uint32 ValorProducto1Orig;				//Guarda el valor del producto 1 reconocido numericamente
	uint32 ValorProducto2Orig;				//Guarda el valor del producto 2 reconocido numericamente
	uint32 ValorProducto3Orig;				//Guarda el valor del producto 3 reconocido numericamente
	uint32 ValorProducto4Orig;				//Guarda el valor del producto 4 reconocido numericamente
	uint32 ValorProducto1;					//Para realizar multiplicaciones dependiendo de la cantidad 
	uint32 ValorProducto2;					//Para realizar multiplicaciones dependiendo de la cantidad 
	uint32 ValorProducto3;					//Para realizar multiplicaciones dependiendo de la cantidad 
	uint32 ValorProducto4;					//Para realizar multiplicaciones dependiendo de la cantidad 
	uint8 CantProducto1Canasta[7];			//Guarda la cantidad del producto 1 en caracteres
	uint8 CantProducto2Canasta[7];			//Guarda la cantidad del producto 2 en caracteres
	uint8 CantProducto3Canasta[7];			//Guarda la cantidad del producto 3 en caracteres
	uint8 CantProducto4Canasta[7];			//Guarda la cantidad del producto 4 en caracteres
	uint32 ValorCant1;						//Guarda la cantidad del producto 1 numericamente
	uint32 ValorCant2;						//Guarda la cantidad del producto 2 numericamente
	uint32 ValorCant3;						//Guarda la cantidad del producto 3 numericamente
	uint32 ValorCant4;						//Guarda la cantidad del producto 4 numericamente
	uint8 ValorTotalProdCanasta[12];		//Guarda la cantidad total de la suma de productos en caracteres
	uint32 ValorProductoTotal;				//Guarda la cantidad total de la suma de productos numericamente
	uint8 AutorizacionVentaCanasta;		    //Bandera que autoriza la venta de canastilla
	uint8 FechaVentaCanastilla[18];			//Fecha de venta canastilla
	uint8 MensajeProducto[25];				//Mensajes a publicar para el producto de canastilla
	uint8 CodigoBarras[30];
	uint8 ReconocimientoProducto;
	uint8 Producto1Canasta[14];
	uint8 Producto2Canasta[14];
	uint8 Producto3Canasta[14];
	uint8 Producto4Canasta[14];
	uint8 Impresionmux;	
    uint8 ventaspendientesRAM[600];
    uint8 Estado_Mux;
    uint8 impresionultimaventa;             //Bandera para sacar del estado de impresion al mux
    uint8 recepcionrf;                      //Bandera para verificar que ya tomo datos el rf 
};
struct buffer Buffer_LCD1;
struct buffer Buffer_LCD2;

/**********************************************/

struct pos{
    uint8 dir;
    uint8 versdig;      //version de digitos del surtidor
    uint8 turno;		//Bandera que habilita la apertura o el cierre del turno
};

struct surtidor{
   struct pos a;
   struct pos b;
   struct pos c;
   struct pos d; 
};

struct recibo{
    uint8 nombre[35];
    uint8 nit[18];
    uint8 telefono[25];
    uint8 direccion[35];
	uint8 lema1[35];
	uint8 lema2[35];
    uint8 fecha[10];
    uint8 hora[10];
    uint8 posicion;
    uint8 producto;
    uint8 ppu[10];
    uint8 dinero[12];	
    uint8 volumen[12];
};

uint8  producto1; 
uint8  producto2;
uint8  producto;

struct surtidor lado;   //lado del surtidor
struct recibo rventa;   //datos de la venta, la estacion y totales
struct recibo rventa2;   //datos de la venta, la estacion y totales

#endif

//[] END OF FILE
