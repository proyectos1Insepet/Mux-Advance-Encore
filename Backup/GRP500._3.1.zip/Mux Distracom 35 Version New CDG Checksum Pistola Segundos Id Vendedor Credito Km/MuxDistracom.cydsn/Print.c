/*
*********************************************************************************************************
*                                           GRP500 CODE
*
*                             (c) Copyright 2013; Sistemas Insepet LTDA
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                               GRP500 CODE
*
*                                             CYPRESS PSoC5LP
*                                                with the
*                                            CY8C5969AXI-LP035
*
* Filename      : Print.c
* Version       : V1.00
* Programmer(s) : 
                  
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/
#include <device.h>
#include "VariablesG.h"
#include "I2C.h"
#include "Protocolo.h"
#include "Logos.h"
#include "Print.h"
#include <math.h>

/*
*********************************************************************************************************
*                                            MENSAJES
*********************************************************************************************************
*/
uint8 msn_dis[14]="DISTRACOM S.A.";
uint8 msn_nitDis[18]="NIT: 811.009.788.8";
uint8 msn_reg[13]="Regimen Comun";
uint8 msn_con[28]="Somos Grandes Contribuyentes";
uint8 msn_res[30]="Res. No. 15353 del 21 dic 2006";
uint8 msn_eds[20]="ESTACION DE SERVICIO";
uint8 msn_fecha[11]="Fecha:     ";
uint8 msn_fechaVenc[21]="Fecha de Vencimiento ";
uint8 msn_entrego[8]="ENTREGO:";
uint8 msn_recibi[8]="RECIBI: ";
uint8 msn_nombre[8]="NOMBRE: ";
uint8 msn_hora[11]="Hora:      ";
uint8 msn_pos[11]="Posicion:  ";
uint8 msn_ppu[15]="PPU:       $/G ";
uint8 msn_vol[13]="Volumen:   G ";
uint8 msn_din[13]="Dinero:    $ ";
uint8 msn_placa[11]="Placa:     ";
uint8 msn_cedula[11]="Cedula:    ";
uint8 msn_Nit[11]="Nit:       ";
uint8 msn_km[11]="Km:        ";
uint8 msn_cliente[11]="Cliente:   ";
uint8 msn_direccion[11]="Direccion: ";
uint8 msn_telefono[11]="Telefono:  ";
uint8 msn_cuenta[11]="Cuenta:    ";
uint8 msn_C[6]="Cedula";
uint8 msn_P[5]="Placa";
uint8 msn_I[7]="Ibutton";
uint8 msn_F[15]="No Fuel Control";
uint8 msn_T[12]="Tarjeta RFID";
uint8 msn_id[11]="Tipo Id:   ";
uint8 msn_NumID[11]="Numero:    ";
uint8 msn_copia[20]="COPIA ADMINISTRATIVA";
uint8 msn_corriente[9]="CORRIENTE";
uint8 msn_diesel[7]="DIESEL";
uint8 msn_extra[5]="EXTRA";
uint8 msn_producto[11]="Producto:  ";
uint8 msn_fturno[16]="Fecha de Turno: ";
uint8 msn_hturno[16]="Hora de Turno:  ";
uint8 msn_fcorte[16]="Fecha de Corte: ";
uint8 msn_hcorte[16]="Hora de Corte:  ";
uint8 msn_VIniciales[7]="Inicial";
uint8 msn_VPosteriores[7]="Final  ";
uint8 msn_Producto1D[15] ="Corriente:   $ ";
uint8 msn_Producto1V[15] ="             G ";
uint8 msn_Producto2D[15] ="Extra:       $ ";
uint8 msn_Producto2V[15] ="             G ";
uint8 msn_Producto3D[15] ="Diesel:      $ ";
uint8 msn_Producto3V[15] ="             G ";
uint8 msn_Producto4D[15] ="Manguera ?:  $ ";
uint8 msn_TOTAL[15] ="TOTAL:.......$ ";
uint8 msn_Vend[10] = "Vendedor: ";
uint8 msn_Cedula[10] = "Identif.: ";
uint8 msn_Arqueo[30]="************ARQUEO************";

/*
*********************************************************************************************************
*                          				void print_logo(uint8 val, uint8 logo)
*
* Description : Envia por I2C los datos de los vectores de los logos.
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void print_logo(uint8 val){
    write_psoc1(val,0x1C);
	write_psoc1(val,0x70);
	write_psoc1(val,0x01);
	write_psoc1(val,0x00);
    write_psoc1(val,10);
}

/*
*********************************************************************************************************
*                          				void print_arqueo(uint8 val)
*
* Description : Envia por I2C los datos de los vectores de los logos.
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void print_arqueo(uint8 val){
	uint32 i;
	for(i=0;i<=29;i++){
		write_psoc1(val,msn_Arqueo[i]);
	}
	write_psoc1(val,10);
}

/*
*********************************************************************************************************
*                                         void imprimir(uint8 val)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void imprimir(uint8 val, uint8 producto, uint8 copia, uint8 pos){
    uint8 digito;
    uint32 x,w,y,i;
	
	for(x=0;x<=((31-14)/2);x++){
		write_psoc1(val,0x20);			
	}
	for(x=0;x<=13;x++){										//DISTRACOM S.A.
		write_psoc1(val,msn_dis[x]);
	}
	
	write_psoc1(val,10);
	for(x=0;x<=((31-18)/2);x++){
		write_psoc1(val,0x20);			
	}
	for(x=0;x<=17;x++){										//NIT: 811.009.788.8
		write_psoc1(val,msn_nitDis[x]);
	}
	
	write_psoc1(val,10);
	for(x=0;x<=((31-13)/2);x++){
		write_psoc1(val,0x20);			
	}
	for(x=0;x<=12;x++){										//Regimen Comun
		write_psoc1(val,msn_reg[x]);
	}
	
	write_psoc1(val,10);
	for(x=0;x<=((31-28)/2);x++){
		write_psoc1(val,0x20);			
	}
	for(x=0;x<=27;x++){										//Somos Grandes Contribuyentes
		write_psoc1(val,msn_con[x]);
	}
	
	write_psoc1(val,10);
	for(x=0;x<=((31-30)/2);x++){
		write_psoc1(val,0x20);			
	}
	for(x=0;x<=29;x++){										//Res. No. 15353 del 21 dic 2006
		write_psoc1(val,msn_res[x]);
	}
	
	write_psoc1(val,10);
	for(x=0;x<=((31-20)/2);x++){
		write_psoc1(val,0x20);			
	}		
	for(x=0;x<=19;x++){										//ESTACION DE SERVICIO
		write_psoc1(val,msn_eds[x]);
	}
	
    write_psoc1(val,10);
	for(x=0;x<=((31-rventa.nombre[0])/2);x++){				//NOMBRE
		write_psoc1(val,0x20);		
	}
	for(x=1;x<=rventa.nombre[0];x++){
		write_psoc1(val,rventa.nombre[x]);			
	}
	
    write_psoc1(val,10);
	for(x=0;x<=((31-rventa.direccion[0])/2);x++){			//DIRECCION
		write_psoc1(val,0x20);			
	}
	for(x=1;x<=rventa.direccion[0];x++){
		write_psoc1(val,rventa.direccion[x]);			
	}
	
	write_psoc1(val,10);
	for(x=0;x<=((31-rventa.lema1[0])/2);x++){					//LEMAS
		write_psoc1(val,0x20);			
	}
	for(x=1;x<=rventa.lema1[0];x++){
		write_psoc1(val,rventa.lema1[x]);			
	}
    write_psoc1(val,10);
	for(x=0;x<=((31-rventa.lema2[0])/2);x++){
		write_psoc1(val,0x20);			
	}
	for(x=1;x<=rventa.lema2[0];x++){
		write_psoc1(val,rventa.lema2[x]);
	}
    write_psoc1(val,10);
    write_psoc1(val,10);
    write_psoc1(val,10);
	for(x=0;x<=10;x++){										//FECHA								
		write_psoc1(val,msn_fecha[x]);
	}	
	if(leer_fecha()==1){
		write_psoc1(val,(((rventa.fecha[0]&0x30)>>4)+48));
		write_psoc1(val,((rventa.fecha[0]&0x0F)+48));
		write_psoc1(val,'/');
		write_psoc1(val,(((rventa.fecha[1]&0x10)>>4)+48));
		write_psoc1(val,((rventa.fecha[1]&0x0F)+48));	
		write_psoc1(val,'/');
		write_psoc1(val,(((rventa.fecha[2]&0xF0)>>4)+48));
		write_psoc1(val,((rventa.fecha[2]&0x0F)+48));			
	}			
    write_psoc1(val,10);
	for(x=0;x<=10;x++){									
		write_psoc1(val,msn_hora[x]);
	}
	if(leer_hora()==1){										//HORA
		write_psoc1(val,(((rventa.hora[2]&0xF0)>>4)+48));
		write_psoc1(val,((rventa.hora[2]&0x0F)+48));
		write_psoc1(val,':');
		write_psoc1(val,(((rventa.hora[1]&0xF0)>>4)+48));
		write_psoc1(val,((rventa.hora[1]&0x0F)+48));
	}
	if(copia==1){											//COPIA
	    write_psoc1(val,10);
	    write_psoc1(val,10); 
		for(w=0;w<=((31-20)/2);w++){
			write_psoc1(val,0x20);			
		}
		for(x=0;x<=19;x++){									
			write_psoc1(val,msn_copia[x]);
		}
	}
    write_psoc1(val,10);
    write_psoc1(val,10);
	for(x=0;x<=10;x++){										//POSICION								
		write_psoc1(val,msn_pos[x]);
	}
    write_psoc1(val,((pos/10)+48));
	write_psoc1(val,((pos%10)+48));
    write_psoc1(val,10); 
	for(x=0;x<=10;x++){										//PRODUCTO								
		write_psoc1(val,msn_producto[x]);
	}
    if(((producto==(extra&0x0f))&&(pos==lado.a.dir))||((producto==(extra2&0x0f))&&(pos==lado.b.dir))){
		for(x=0;x<=4;x++){																			
			write_psoc1(val,msn_extra[x]);
		}
    }
    if(((producto==(corriente&0x0f))&&(pos==lado.a.dir))||((producto==(corriente2&0x0f))&&(pos==lado.b.dir))){
		for(x=0;x<=8;x++){																		
			write_psoc1(val,msn_corriente[x]);
		} 
    }
    if(((producto==(diesel&0x0f))&&(pos==lado.a.dir))||((producto==(diesel2&0x0f))&&(pos==lado.b.dir))){
		for(x=0;x<=6;x++){																			
			write_psoc1(val,msn_diesel[x]);
		} 
    }		
    write_psoc1(val,10);
	for(x=0;x<=14;x++){											//PPU								
		write_psoc1(val,msn_ppu[x]);
	}
    digito=0;
	if(pos==lado.a.dir){
		for(x=Buffer_LCD1.VentaPPU[0];x>=1;x--){
	        if((Buffer_LCD1.VentaPPU[x]==0)&&(digito==0)){
	            
	        }
	        else{
	            digito=1;
	            write_psoc1(val,(Buffer_LCD1.VentaPPU[x]+48));
	        }
		}
	}else{
		for(x=Buffer_LCD2.VentaPPU[0];x>=1;x--){
	        if((Buffer_LCD2.VentaPPU[x]==0)&&(digito==0)){
	            
	        }
	        else{
	            digito=1;
	            write_psoc1(val,(Buffer_LCD2.VentaPPU[x]+48));
	        }
		}	
	}
	if(ppux10==1){
		write_psoc1(val,48);	
	}
    write_psoc1(val,10);
	for(x=0;x<=12;x++){											//VOLUMEN							
		write_psoc1(val,msn_vol[x]);
	}
	if(pos==lado.a.dir){
		for(x=Buffer_LCD1.VentaVolumen[0];x>=5;x--){
	        if(Buffer_LCD1.VentaVolumen[x]!=0){
				
	            break;
	        }
	    }
	    for(y=x;y>0;y--){
	        if(y==decimalV){
	            write_psoc1(val,44);
	        }
	        write_psoc1(val,(Buffer_LCD1.VentaVolumen[y]+48));
	    }
	}
	else{
		for(x=Buffer_LCD2.VentaVolumen[0];x>=5;x--){
	        if(Buffer_LCD2.VentaVolumen[x]!=0){
				
	            break;
	        }
	    }
	    for(y=x;y>0;y--){
	        if(y==decimalV){
	            write_psoc1(val,44);
	        }
	        write_psoc1(val,(Buffer_LCD2.VentaVolumen[y]+48));
	    }	
	}
    write_psoc1(val,10);
	for(x=0;x<=12;x++){											//DINERO							
		write_psoc1(val,msn_din[x]);
	} 
    digito=0;
	if(pos==lado.a.dir){
		if((lado.c.versdig==5)||(lado.c.versdig==7)){
			for(x=Buffer_LCD1.VentaDinero[0];x>1;x--){
	            if((Buffer_LCD1.VentaDinero[x]==0)&&(digito==0)){
	            }
	            else{
	                digito=1;
	                write_psoc1(val,(Buffer_LCD1.VentaDinero[x]+48));
	            }
			}
		}
		else{
			for(x=Buffer_LCD1.VentaDinero[0];x>=1;x--){
	            if((Buffer_LCD1.VentaDinero[x]==0)&&(digito==0)){
	            }
	            else{
			        if(x==decimalD){
			            write_psoc1(val,44);
			        }				
	                digito=1;
	                write_psoc1(val,(Buffer_LCD1.VentaDinero[x]+48));
	            }
			}		
		}
	}
	else{
		if((lado.c.versdig==5)||(lado.c.versdig==7)){
			for(x=Buffer_LCD2.VentaDinero[0];x>1;x--){
	            if((Buffer_LCD2.VentaDinero[x]==0)&&(digito==0)){  
	            }
	            else{
	                digito=1;
	                write_psoc1(val,(Buffer_LCD2.VentaDinero[x]+48));
	            }
			}
		}
		else{
			for(x=Buffer_LCD2.VentaDinero[0];x>=1;x--){
	            if((Buffer_LCD2.VentaDinero[x]==0)&&(digito==0)){
	            }
	            else{
			        if(x==decimalD){
			            write_psoc1(val,44);
			        }				
	                digito=1;
	                write_psoc1(val,(Buffer_LCD2.VentaDinero[x]+48));
	            }
			}		
		}	
	}
	write_psoc1(val,10);
	if(pos==lado.a.dir){										//DATOS LCD 1
		if(Buffer_LCD1.IdentCliente[0]>0){						//DATOS ID
			if(Buffer_LCD1.FechaCliente[0]>0){					//Fecha cliente
				write_psoc1(val,10);
				for(x=0;x<=20;x++){																		
					write_psoc1(val,msn_fechaVenc[x]);
				}
				for(x=1;x<=Buffer_LCD1.FechaCliente[0];x++){
					write_psoc1(val,Buffer_LCD1.FechaCliente[x]);	
				}
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_id[x]);
			}
			if(Buffer_LCD1.IdentCliente[1]=='C'){
				for(x=0;x<=5;x++){
					write_psoc1(val,msn_C[x]);	
				}
				write_psoc1(val,10);
			}else if(Buffer_LCD1.IdentCliente[1]=='P'){
				for(x=0;x<=4;x++){
					write_psoc1(val,msn_P[x]);	
				}
				write_psoc1(val,10);
			}else if(Buffer_LCD1.IdentCliente[1]=='I'){
				for(x=0;x<=6;x++){
					write_psoc1(val,msn_I[x]);	
				}
				write_psoc1(val,10);
			}else if(Buffer_LCD1.IdentCliente[1]=='F'){
				for(x=0;x<=14;x++){
					write_psoc1(val,msn_F[x]);	
				}
				write_psoc1(val,10);
			}else if(Buffer_LCD1.IdentCliente[1]=='T'){
				for(x=0;x<=11;x++){
					write_psoc1(val,msn_T[x]);	
				}
				write_psoc1(val,10);
			}
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_NumID[x]);
			}
			i=2;
			for(x=Buffer_LCD1.IdentCliente[0]-1;x>0;x--){
				write_psoc1(val,Buffer_LCD1.IdentCliente[i]);
				i++;
			}
			if(Buffer_LCD1.NombreCliente[0]>0){					//Nombre cliente
				write_psoc1(val,10);
				for(x=0;x<=10;x++){																		
					write_psoc1(val,msn_cliente[x]);
				}
				for(x=1;x<=20;x++){
					write_psoc1(val,Buffer_LCD1.NombreCliente[x]);	
				}
				if(Buffer_LCD1.NombreCliente[21]!=0x20){
					write_psoc1(val,10);
					for(x=0;x<=10;x++){																		
						write_psoc1(val,' ');
					}
					for(x=21;x<=40;x++){
						write_psoc1(val,Buffer_LCD1.NombreCliente[x]);	
					}
				}
			}
			if(Buffer_LCD1.NitCliente[0]>0){					//Nit Cliente
				write_psoc1(val,10);
				for(x=0;x<=10;x++){																		
					write_psoc1(val,msn_Nit[x]);
				}
				for(x=1;x<=Buffer_LCD1.NitCliente[0];x++){
					write_psoc1(val,Buffer_LCD1.NitCliente[x]);	
				}
			}
			if(Buffer_LCD1.DireccionCliente[0]>0){					//Direccion Cliente
				write_psoc1(val,10);
				for(x=0;x<=10;x++){																		
					write_psoc1(val,msn_direccion[x]);
				}
				for(x=1;x<=20;x++){
					write_psoc1(val,Buffer_LCD1.DireccionCliente[x]);	
				}
				if(Buffer_LCD1.DireccionCliente[21]!=0){
					write_psoc1(val,10);
					for(x=0;x<=10;x++){																		
						write_psoc1(val,' ');
					}
					for(x=21;x<=40;x++){
						write_psoc1(val,Buffer_LCD1.DireccionCliente[x]);	
					}
				}
				
			}
			if(Buffer_LCD1.TelCliente[0]>0){					//Telefono Cliente
				write_psoc1(val,10);
				for(x=0;x<=10;x++){																		
					write_psoc1(val,msn_telefono[x]);
				}
				for(x=1;x<=Buffer_LCD1.TelCliente[0];x++){
					write_psoc1(val,Buffer_LCD1.TelCliente[x]);	
				}
			}
			if(Buffer_LCD1.PlacaCliente[0]>0){					//placa Cliente
				write_psoc1(val,10);
				for(x=0;x<=10;x++){																		
					write_psoc1(val,msn_placa[x]);
				}
				for(x=1;x<=Buffer_LCD1.PlacaCliente[0];x++){
					write_psoc1(val,Buffer_LCD1.PlacaCliente[x]);	
				}
			}
		}
		if(Buffer_LCD1.cedula[0]>0){								//CEDULA
			write_psoc1(val,10);
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_cedula[x]);
			}
			for(x=1;x<=Buffer_LCD1.cedula[0];x++){
				write_psoc1(val,Buffer_LCD1.cedula[x]);	
			}
		}
		if(Buffer_LCD1.Nit[0]>0){								//NIT
			write_psoc1(val,10);
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_Nit[x]);
			}
			for(x=1;x<=Buffer_LCD1.Nit[0];x++){
				write_psoc1(val,Buffer_LCD1.Nit[x]);	
			}
		}
		if(Buffer_LCD1.placa[0]>0){									//PLACA
			write_psoc1(val,10);
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_placa[x]);
			}
			for(x=1;x<=Buffer_LCD1.placa[0];x++){
				write_psoc1(val,Buffer_LCD1.placa[x]);	
			}
		}
		if(Buffer_LCD1.km[0]>0){								//KILOMETRAJE
			write_psoc1(val,10);
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_km[x]);
			}
			for(x=1;x<=Buffer_LCD1.km[0];x++){
				write_psoc1(val,Buffer_LCD1.km[x]);	
			}
		}
		if(Buffer_LCD1.IdentCliente[1]>0){
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=7;x++){																		
				write_psoc1(val,msn_entrego[x]);
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=30;x++){																		
				write_psoc1(val,'-');
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=7;x++){																		
				write_psoc1(val,msn_recibi[x]);
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=30;x++){																		
				write_psoc1(val,'-');
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=7;x++){																		
				write_psoc1(val,msn_nombre[x]);
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=30;x++){																		
				write_psoc1(val,'-');
			}
		}
	}
	else{															//DATOS LCD 2
		if(Buffer_LCD2.IdentCliente[0]>0){						//DATOS ID
			if(Buffer_LCD2.FechaCliente[0]>0){					//Fecha cliente
				write_psoc1(val,10);
				for(x=0;x<=20;x++){																		
					write_psoc1(val,msn_fechaVenc[x]);
				}
				for(x=1;x<=Buffer_LCD2.FechaCliente[0];x++){
					write_psoc1(val,Buffer_LCD2.FechaCliente[x]);	
				}
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_id[x]);
			}
			if(Buffer_LCD2.IdentCliente[1]=='C'){
				for(x=0;x<=5;x++){
					write_psoc1(val,msn_C[x]);	
				}
				write_psoc1(val,10);
			}else if(Buffer_LCD2.IdentCliente[1]=='P'){
				for(x=0;x<=4;x++){
					write_psoc1(val,msn_P[x]);	
				}
				write_psoc1(val,10);
			}else if(Buffer_LCD2.IdentCliente[1]=='I'){
				for(x=0;x<=6;x++){
					write_psoc1(val,msn_I[x]);	
				}
				write_psoc1(val,10);
			}else if(Buffer_LCD2.IdentCliente[1]=='F'){
				for(x=0;x<=14;x++){
					write_psoc1(val,msn_F[x]);	
				}
				write_psoc1(val,10);
			}else if(Buffer_LCD2.IdentCliente[1]=='T'){
				for(x=0;x<=11;x++){
					write_psoc1(val,msn_T[x]);	
				}
				write_psoc1(val,10);
			}
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_NumID[x]);
			}
			i=2;
			for(x=Buffer_LCD2.IdentCliente[0]-1;x>0;x--){
				write_psoc1(val,Buffer_LCD2.IdentCliente[i]);
				i++;
			}
			if(Buffer_LCD2.NombreCliente[0]>0){					//Nombre cliente
				write_psoc1(val,10);
				for(x=0;x<=10;x++){																		
					write_psoc1(val,msn_cliente[x]);
				}
				for(x=1;x<=20;x++){
					write_psoc1(val,Buffer_LCD2.NombreCliente[x]);	
				}
				if(Buffer_LCD2.NombreCliente[21]!=0x20){
					write_psoc1(val,10);
					for(x=0;x<=10;x++){																		
						write_psoc1(val,' ');
					}
					for(x=21;x<=40;x++){
						write_psoc1(val,Buffer_LCD2.NombreCliente[x]);	
					}
				}
			}
			if(Buffer_LCD2.NitCliente[0]>0){					//Nit Cliente
				write_psoc1(val,10);
				for(x=0;x<=10;x++){																		
					write_psoc1(val,msn_Nit[x]);
				}
				for(x=1;x<=Buffer_LCD2.NitCliente[0];x++){
					write_psoc1(val,Buffer_LCD2.NitCliente[x]);	
				}
			}
			if(Buffer_LCD2.DireccionCliente[0]>0){					//Direccion Cliente
				write_psoc1(val,10);
				for(x=0;x<=10;x++){																		
					write_psoc1(val,msn_direccion[x]);
				}
				for(x=1;x<=20;x++){
					write_psoc1(val,Buffer_LCD2.DireccionCliente[x]);	
				}
				if(Buffer_LCD2.DireccionCliente[21]!=0x20){
					write_psoc1(val,10);
					for(x=0;x<=10;x++){																		
						write_psoc1(val,' ');
					}
					for(x=21;x<=40;x++){
						write_psoc1(val,Buffer_LCD2.DireccionCliente[x]);	
					}
				}
				
			}
			if(Buffer_LCD2.TelCliente[0]>0){					//Telefono Cliente
				write_psoc1(val,10);
				for(x=0;x<=10;x++){																		
					write_psoc1(val,msn_telefono[x]);
				}
				for(x=1;x<=Buffer_LCD2.TelCliente[0];x++){
					write_psoc1(val,Buffer_LCD2.TelCliente[x]);	
				}
			}
			if(Buffer_LCD2.PlacaCliente[0]>0){					//placa Cliente
				write_psoc1(val,10);
				for(x=0;x<=10;x++){																		
					write_psoc1(val,msn_placa[x]);
				}
				for(x=1;x<=Buffer_LCD2.PlacaCliente[0];x++){
					write_psoc1(val,Buffer_LCD2.PlacaCliente[x]);	
				}
			}
		}
		if(Buffer_LCD2.cedula[0]>0){								//CEDULA
			write_psoc1(val,10);
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_cedula[x]);
			}
			for(x=1;x<=Buffer_LCD2.cedula[0];x++){
				write_psoc1(val,Buffer_LCD2.cedula[x]);	
			}
		}
		if(Buffer_LCD2.Nit[0]>0){								//NIT
			write_psoc1(val,10);
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_Nit[x]);
			}
			for(x=1;x<=Buffer_LCD2.Nit[0];x++){
				write_psoc1(val,Buffer_LCD2.Nit[x]);	
			}
		}
		if(Buffer_LCD2.placa[0]>0){									//PLACA
			write_psoc1(val,10);
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_placa[x]);
			}
			for(x=1;x<=Buffer_LCD2.placa[0];x++){
				write_psoc1(val,Buffer_LCD2.placa[x]);	
			}
		}
		if(Buffer_LCD2.km[0]>0){								//KILOMETRAJE
			write_psoc1(val,10);
			for(x=0;x<=10;x++){																		
				write_psoc1(val,msn_km[x]);
			}
			for(x=1;x<=Buffer_LCD2.km[0];x++){
				write_psoc1(val,Buffer_LCD2.km[x]);	
			}
		}
		if(Buffer_LCD2.IdentCliente[1]>0){
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=7;x++){																		
				write_psoc1(val,msn_entrego[x]);
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=30;x++){																		
				write_psoc1(val,'-');
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=7;x++){																		
				write_psoc1(val,msn_recibi[x]);
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=30;x++){																		
				write_psoc1(val,'-');
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=7;x++){																		
				write_psoc1(val,msn_nombre[x]);
			}
			write_psoc1(val,10);
			write_psoc1(val,10);
			for(x=0;x<=30;x++){																		
				write_psoc1(val,'-');
			}
		}
	}
    write_psoc1(val,10); 
    write_psoc1(val,10); 
    write_psoc1(val,10);
    write_psoc1(val,10);
	write_psoc1(val,10);
	write_psoc1(val,0x1D);
    write_psoc1(val,0x56);
	write_psoc1(val,0x31);
}

/*
*********************************************************************************************************
*                                       void imprimir_corte(void)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void imprimir_corte(uint8 PuertoImp){
	int digito;
	uint8 minuendo[14],sustraendo[14];
    uint32 x,z;
	for(x=0;x<=((31-14)/2);x++){
		write_psoc1(PuertoImp,0x20);			
	}
	for(x=0;x<=13;x++){										//DISTRACOM S.A.
		write_psoc1(PuertoImp,msn_dis[x]);
	}
	
	write_psoc1(PuertoImp,10);
	for(x=0;x<=((31-18)/2);x++){
		write_psoc1(PuertoImp,0x20);			
	}
	for(x=0;x<=17;x++){										//NIT: 811.009.788.8
		write_psoc1(PuertoImp,msn_nitDis[x]);
	}
	write_psoc1(PuertoImp,10);
	write_psoc1(PuertoImp,10);
	for(x=1;x<=30;x++){
		write_psoc1(PuertoImp,'-');
	}
	write_psoc1(PuertoImp,10);
	for(x=0;x<=9;x++){										//Nombre Vendedor
		write_psoc1(PuertoImp,msn_Vend[x]);
	}
	leer_eeprom(223,21);
	for(x=1;x<=buffer_i2c[0];x++){
		write_psoc1(PuertoImp,buffer_i2c[x]);
	}
	write_psoc1(PuertoImp,10);
	for(x=0;x<=9;x++){										//Cedula Vendedor
		write_psoc1(PuertoImp,msn_Cedula[x]);
	}
	leer_eeprom(244,11);
	for(x=1;x<=buffer_i2c[0];x++){
		write_psoc1(PuertoImp,buffer_i2c[x]);
	}
	write_psoc1(PuertoImp,10);
	for(x=0;x<=15;x++){									
		write_psoc1(PuertoImp,msn_fturno[x]);			//Fecha de Turno
	}
	leer_eeprom(287,15);
	write_psoc1(PuertoImp,buffer_i2c[7]);
	write_psoc1(PuertoImp,buffer_i2c[8]);
	write_psoc1(PuertoImp,'/');
	write_psoc1(PuertoImp,buffer_i2c[5]);
	write_psoc1(PuertoImp,buffer_i2c[6]);
	write_psoc1(PuertoImp,'/');
	write_psoc1(PuertoImp,buffer_i2c[3]);
	write_psoc1(PuertoImp,buffer_i2c[4]);
    write_psoc1(PuertoImp,10);
	for(x=0;x<=15;x++){									
		write_psoc1(PuertoImp,msn_hturno[x]);			//Hora de Turno
	}
	write_psoc1(PuertoImp,buffer_i2c[9]);
	write_psoc1(PuertoImp,buffer_i2c[10]);
	write_psoc1(PuertoImp,':');
	write_psoc1(PuertoImp,buffer_i2c[11]);
	write_psoc1(PuertoImp,buffer_i2c[12]);
	write_psoc1(PuertoImp,10);
	for(x=0;x<=15;x++){									
		write_psoc1(PuertoImp,msn_fcorte[x]);			//Fecha de Corte
	}
	if(leer_fecha()==1){
		write_psoc1(PuertoImp,(((rventa.fecha[0]&0x30)>>4)+48));
		write_psoc1(PuertoImp,((rventa.fecha[0]&0x0F)+48));
		write_psoc1(PuertoImp,'/');
		write_psoc1(PuertoImp,(((rventa.fecha[1]&0x10)>>4)+48));
		write_psoc1(PuertoImp,((rventa.fecha[1]&0x0F)+48));	
		write_psoc1(PuertoImp,'/');
		write_psoc1(PuertoImp,(((rventa.fecha[2]&0xF0)>>4)+48));
		write_psoc1(PuertoImp,((rventa.fecha[2]&0x0F)+48));			
	}
    write_psoc1(PuertoImp,10);
	for(x=0;x<=15;x++){									
		write_psoc1(PuertoImp,msn_hcorte[x]);			//Hora de Corte
	}
	if(leer_hora()==1){						
		write_psoc1(PuertoImp,(((rventa.hora[2]&0xF0)>>4)+48));
		write_psoc1(PuertoImp,((rventa.hora[2]&0x0F)+48));
		write_psoc1(PuertoImp,':');
		write_psoc1(PuertoImp,(((rventa.hora[1]&0xF0)>>4)+48));
		write_psoc1(PuertoImp,((rventa.hora[1]&0x0F)+48));
	}
	write_psoc1(PuertoImp,10);
	for(x=1;x<=30;x++){
		write_psoc1(PuertoImp,'-');
	}
	write_psoc1(PuertoImp,10);
	
	get_totales(lado.a.dir);
	
	for(x=0;x<=10;x++){										//POSICION	1							
		write_psoc1(PuertoImp,msn_pos[x]);
	}
    write_psoc1(PuertoImp,((lado.a.dir/10)+48));
	write_psoc1(PuertoImp,((lado.a.dir%10)+48));
    write_psoc1(PuertoImp,10);
	
	for(x=1;x<=30;x++){
		write_psoc1(PuertoImp,'-');
	}
	write_psoc1(PuertoImp,10);
	if(corriente==1 || extra==1 || diesel==1){
        for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VIniciales[x]);			//Valores Iniciales
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.a.dir,1,PuertoImp);				//Manguera 1
    	leer_eeprom(320,13);
    	
    	for(z=0;z<Buffer_LCD1.TotalDinero1[0];z++){
    		minuendo[Buffer_LCD1.TotalDinero1[0]-z]=Buffer_LCD1.TotalDinero1[z+1]&0x0f;
    	}
    	minuendo[0]=Buffer_LCD1.TotalDinero1[0]&0x0f;
    	for(z=0;z<buffer_i2c[0];z++){
    		sustraendo[buffer_i2c[0]-z]=buffer_i2c[z+1]&0x0f;
    	}
    	sustraendo[0]=buffer_i2c[0]&0x0f;
    	
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 1							
    		write_psoc1(PuertoImp,msn_Producto1V[x]);
    	}
    	leer_eeprom(333,14);
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	
    	for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VPosteriores[x]);			//Valores Corte
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.a.dir,1,PuertoImp);			//Manguera 1
    	digito=0;
    	for(x=1;x<=Buffer_LCD1.TotalDinero1[0];x++){
    		if((Buffer_LCD1.TotalDinero1[x]=='0')&&(digito==0)){
            
    		}
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD1.TotalDinero1[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 1							
    		write_psoc1(PuertoImp,msn_Producto1V[x]);
    	}
    	digito=0;
    	for(x=1;x<=Buffer_LCD1.TotalVolumen1[0];x++){
    		if((Buffer_LCD1.TotalVolumen1[x]=='0')&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD1.TotalVolumen1[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){									
    		write_psoc1(PuertoImp,msn_TOTAL[x]);			//TOTAL
    	}
    	
    	operacion(minuendo,sustraendo);
    	digito=0;
    	for(x=resultado[0];x>=1;x--){
    		if((resultado[x]==0)&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,resultado[x]+48);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	
    	for(x=1;x<=30;x++){
    		write_psoc1(PuertoImp,'-');
    	}
    	write_psoc1(PuertoImp,10);
    }
	if(corriente==2 || extra==2 || diesel==2){
	
    	for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VIniciales[x]);			//Valores Iniciales
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.a.dir,2,PuertoImp);				//Manguera 2
    	leer_eeprom(384,13);
    	
    	for(z=0;z<=Buffer_LCD1.TotalDinero2[0];z++){
    		minuendo[Buffer_LCD1.TotalDinero2[0]-z]=Buffer_LCD1.TotalDinero2[z+1]&0x0f;
    	}
    	minuendo[0]=Buffer_LCD1.TotalDinero2[0]&0x0f;
    	for(z=0;z<=buffer_i2c[0];z++){
    		sustraendo[buffer_i2c[0]-z]=buffer_i2c[z+1]&0x0f;
    	}
    	sustraendo[0]=buffer_i2c[0]&0x0f;
    	
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 2							
    		write_psoc1(PuertoImp,msn_Producto2V[x]);
    	}
    	leer_eeprom(397,14);
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	
    	for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VPosteriores[x]);			//Valores Corte
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.a.dir,2,PuertoImp);				//Manguera 2
    	digito=0;
    	for(x=1;x<=Buffer_LCD1.TotalDinero2[0];x++){
    		if((Buffer_LCD1.TotalDinero2[x]=='0')&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD1.TotalDinero2[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 2							
    		write_psoc1(PuertoImp,msn_Producto2V[x]);
    	}
    	digito=0;
    	for(x=1;x<=Buffer_LCD1.TotalVolumen2[0];x++){
    		if((Buffer_LCD1.TotalVolumen2[x]=='0')&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD1.TotalVolumen2[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){									
    		write_psoc1(PuertoImp,msn_TOTAL[x]);			//TOTAL
    	}
    	
    	operacion(minuendo,sustraendo);
    	digito=0;
    	for(x=resultado[0];x>=1;x--){
    		if((resultado[x]==0)&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,resultado[x]+48);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	
    	for(x=1;x<=30;x++){
    		write_psoc1(PuertoImp,'-');
    	}
    	write_psoc1(PuertoImp,10);
	}
    if(corriente==3 || extra==3 || diesel==3){
    	for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VIniciales[x]);			//Valores Iniciales
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.a.dir,3,PuertoImp);				//Manguera 3
    	leer_eeprom(448,13);
    	
    	for(z=0;z<=Buffer_LCD1.TotalDinero3[0];z++){
    		minuendo[Buffer_LCD1.TotalDinero3[0]-z]=Buffer_LCD1.TotalDinero3[z+1]&0x0f;
    	}
    	minuendo[0]=Buffer_LCD1.TotalDinero3[0]&0x0f;
    	for(z=0;z<=buffer_i2c[0];z++){
    		sustraendo[buffer_i2c[0]-z]=buffer_i2c[z+1]&0x0f;
    	}
    	sustraendo[0]=buffer_i2c[0]&0x0f;
    	
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 3							
    		write_psoc1(PuertoImp,msn_Producto3V[x]);
    	}
    	leer_eeprom(461,14);
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VPosteriores[x]);			//Valores Corte
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.a.dir,3,PuertoImp);				//Manguera 3
    	digito=0;
    	for(x=1;x<=Buffer_LCD1.TotalDinero3[0];x++){
    		if((Buffer_LCD1.TotalDinero3[x]=='0')&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD1.TotalDinero3[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 3							
    		write_psoc1(PuertoImp,msn_Producto3V[x]);
    	}
    	digito=0;
    	for(x=1;x<=Buffer_LCD1.TotalVolumen3[0];x++){
    		if((Buffer_LCD1.TotalVolumen3[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD1.TotalVolumen3[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){									
    		write_psoc1(PuertoImp,msn_TOTAL[x]);			//TOTAL
    	}
    	
    	operacion(minuendo,sustraendo);
    	digito=0;
    	for(x=resultado[0];x>=1;x--){
    		if((resultado[x]==0)&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,resultado[x]+48);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	
    	for(x=1;x<=30;x++){
    		write_psoc1(PuertoImp,'-');
    	}
    	write_psoc1(PuertoImp,10);
	}
	get_totales(lado.b.dir);
	
	for(x=0;x<=10;x++){										//POSICION	2							
		write_psoc1(PuertoImp,msn_pos[x]);
	}
    write_psoc1(PuertoImp,((lado.b.dir/10)+48));
	write_psoc1(PuertoImp,((lado.b.dir%10)+48));
    write_psoc1(PuertoImp,10);
	
	for(x=1;x<=30;x++){
		write_psoc1(PuertoImp,'-');
	}
	write_psoc1(PuertoImp,10);
	if(corriente2==1 || extra2==1 || diesel2==1){
    	for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VIniciales[x]);			//Valores Iniciales
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.b.dir,1,PuertoImp);				//Manguera 1
    	leer_eeprom(351,13);
    	
    	for(z=0;z<=Buffer_LCD2.TotalDinero1[0];z++){
    		minuendo[Buffer_LCD2.TotalDinero1[0]-z]=Buffer_LCD2.TotalDinero1[z+1]&0x0f;
    	}
    	minuendo[0]=Buffer_LCD2.TotalDinero1[0]&0x0f;
    	for(z=0;z<=buffer_i2c[0];z++){
    		sustraendo[buffer_i2c[0]-z]=buffer_i2c[z+1]&0x0f;
    	}
    	sustraendo[0]=buffer_i2c[0]&0x0f;
    	
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 1							
    		write_psoc1(PuertoImp,msn_Producto1V[x]);
    	}
    	leer_eeprom(364,14);
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	
    	for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VPosteriores[x]);			//Valores Corte
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.b.dir,1,PuertoImp);			//Manguera 1
    	digito=0;
    	for(x=1;x<=Buffer_LCD2.TotalDinero1[0];x++){
    		if((Buffer_LCD2.TotalDinero1[x]=='0')&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD2.TotalDinero1[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 1							
    		write_psoc1(PuertoImp,msn_Producto1V[x]);
    	}
    	digito=0;
    	for(x=1;x<=Buffer_LCD2.TotalVolumen1[0];x++){
    		if((Buffer_LCD2.TotalVolumen1[x]=='0')&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD2.TotalVolumen1[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){									
    		write_psoc1(PuertoImp,msn_TOTAL[x]);			//TOTAL
    	}
    	
    	operacion(minuendo,sustraendo);
    	digito=0;
    	for(x=resultado[0];x>=1;x--){
    		if((resultado[x]==0)&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,resultado[x]+48);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	
    	for(x=1;x<=30;x++){
    		write_psoc1(PuertoImp,'-');
    	}
    	write_psoc1(PuertoImp,10);
	}
    if(corriente2==2 || extra2==2 || diesel2==2){
    	for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VIniciales[x]);			//Valores Iniciales
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.b.dir,2,PuertoImp);				//Manguera 2
    	leer_eeprom(415,13);
    	
    	for(z=0;z<=Buffer_LCD2.TotalDinero2[0];z++){
    		minuendo[Buffer_LCD2.TotalDinero2[0]-z]=Buffer_LCD2.TotalDinero2[z+1]&0x0f;
    	}
    	minuendo[0]=Buffer_LCD2.TotalDinero2[0]&0x0f;
    	for(z=0;z<=buffer_i2c[0];z++){
    		sustraendo[buffer_i2c[0]-z]=buffer_i2c[z+1]&0x0f;
    	}
    	sustraendo[0]=buffer_i2c[0]&0x0f;
    	
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 2							
    		write_psoc1(PuertoImp,msn_Producto2V[x]);
    	}
    	leer_eeprom(428,14);
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	
    	for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VPosteriores[x]);			//Valores Corte
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.b.dir,2,PuertoImp);			//Manguera 2
    	digito=0;
    	for(x=1;x<=Buffer_LCD2.TotalDinero2[0];x++){
    		if((Buffer_LCD2.TotalDinero2[x]=='0')&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD2.TotalDinero2[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 2							
    		write_psoc1(PuertoImp,msn_Producto2V[x]);
    	}
    	digito=0;
    	for(x=1;x<=Buffer_LCD2.TotalVolumen2[0];x++){
    		if((Buffer_LCD2.TotalVolumen2[x]=='0')&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD2.TotalVolumen2[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){									
    		write_psoc1(PuertoImp,msn_TOTAL[x]);			//TOTAL
    	}
    	
    	operacion(minuendo,sustraendo);
    	digito=0;
    	for(x=resultado[0];x>=1;x--){
    		if((resultado[x]==0)&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,resultado[x]+48);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	
    	for(x=1;x<=30;x++){
    		write_psoc1(PuertoImp,'-');
    	}
    	write_psoc1(PuertoImp,10);
	}
    if(corriente2==3 || extra2==3 || diesel2==3){
    	for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VIniciales[x]);			//Valores Iniciales
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.b.dir,3,PuertoImp);				//Manguera 3
    	leer_eeprom(479,13);
    	
    	for(z=0;z<=Buffer_LCD2.TotalDinero3[0];z++){
    		minuendo[Buffer_LCD2.TotalDinero3[0]-z]=Buffer_LCD2.TotalDinero3[z+1]&0x0f;
    	}
    	minuendo[0]=Buffer_LCD2.TotalDinero3[0]&0x0f;
    	for(z=0;z<=buffer_i2c[0];z++){
    		sustraendo[buffer_i2c[0]-z]=buffer_i2c[z+1]&0x0f;
    	}
    	sustraendo[0]=buffer_i2c[0]&0x0f;
    	
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 3							
    		write_psoc1(PuertoImp,msn_Producto3V[x]);
    	}
    	leer_eeprom(492,14);
    	digito=0;
    	for(x=1;x<=buffer_i2c[0];x++){
    		if((buffer_i2c[x]=='0')&&(digito==0)){
                    
                }
            else{
                digito=1;
    			write_psoc1(PuertoImp,buffer_i2c[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	
    	for(x=0;x<=6;x++){									
    		write_psoc1(PuertoImp,msn_VPosteriores[x]);			//Valores Corte
    	}
    	write_psoc1(PuertoImp,10);
    	
    	comparar_manguera(lado.b.dir,3,PuertoImp);				//Manguera 3
    	digito=0;
    	for(x=1;x<=Buffer_LCD2.TotalDinero3[0];x++){
    		if((Buffer_LCD2.TotalDinero3[x]=='0')&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD2.TotalDinero3[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){										//Volumen 3							
    		write_psoc1(PuertoImp,msn_Producto3V[x]);
    	}
    	digito=0;
    	for(x=1;x<=Buffer_LCD2.TotalVolumen3[0];x++){
    		if((Buffer_LCD2.TotalVolumen3[x]=='0')&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,Buffer_LCD2.TotalVolumen3[x]);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	write_psoc1(PuertoImp,10);
    	for(x=0;x<=14;x++){									
    		write_psoc1(PuertoImp,msn_TOTAL[x]);			//TOTAL
    	}
    	
    	operacion(minuendo,sustraendo);
    	digito=0;
    	for(x=resultado[0];x>=1;x--){
    		if((resultado[x]==0)&&(digito==0)){
                    
            }
            else{
                digito=1;
    			write_psoc1(PuertoImp,resultado[x]+48);
            }
    	}
    	write_psoc1(PuertoImp,10);
    	
    	for(x=1;x<=30;x++){
    		write_psoc1(PuertoImp,'-');
    	}
    }
	write_psoc1(PuertoImp,10);
	write_psoc1(PuertoImp,10);
	write_psoc1(PuertoImp,10);
	write_psoc1(PuertoImp,10);
	write_psoc1(PuertoImp,0x1D);
    write_psoc1(PuertoImp,0x56);
	write_psoc1(PuertoImp,0x31);
}

/*
*********************************************************************************************************
*                                         void comparar_manguera()
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void comparar_manguera(uint8 pos,uint8 manguera,uint8 imp){
    uint32 x;
	if(pos==lado.a.dir){
		if(corriente==manguera){
			for(x=0;x<=14;x++){										//Corriente	1						
				write_psoc1(imp,msn_Producto1D[x]);
			}
		}else if(extra==manguera){
			for(x=0;x<=14;x++){										//Extra	1							
				write_psoc1(imp,msn_Producto2D[x]);
			}
		}else if(diesel==manguera){
			for(x=0;x<=14;x++){										//Diesel 1								
				write_psoc1(imp,msn_Producto3D[x]);
			}
		}else{
			for(x=0;x<=14;x++){										//Manguera ?								
				write_psoc1(imp,msn_Producto4D[x]);
			}
		}
	}else{
		if(corriente2==manguera){
			for(x=0;x<=14;x++){										//Corriente 2						
				write_psoc1(imp,msn_Producto1D[x]);
			}
		}else if(extra2==manguera){
			for(x=0;x<=14;x++){										//Extra	2							
				write_psoc1(imp,msn_Producto2D[x]);
			}
		}else if(diesel2==manguera){
			for(x=0;x<=14;x++){										//Diesel 2								
				write_psoc1(imp,msn_Producto3D[x]);
			}
		}else{
			for(x=0;x<=14;x++){										//Manguera ?								
				write_psoc1(imp,msn_Producto4D[x]);
			}
		}
	}
}

/*
*********************************************************************************************************
*                             void operacion(uint8 *valor1, uint8 *valor2)
*
* Description : Realiza una resta entre dos punteros y lo guarda en el vector global resultado
*               
*
* Argument(s) :
				uint8 *valor1 = Operador uno (En el caso de la resta es el mayor)
				uint8 *valor2 = Operador dos
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : Se usa para hacer operaciones entre la tramas enviadas por el surtidor.
*********************************************************************************************************
*/

void operacion(uint8 *valor1, uint8 *valor2){
	uint8 carrier;
    uint32 i;
	uint8 max_valor[12]={9,9,9,9,9,9,9,9,9,9,9,9};
	carrier=0;
	if(valor1[valor1[0]]<valor2[valor1[0]]){
		for(i=1;i<=valor1[0];i++){
			if((max_valor[i]-carrier)<valor2[i]){
				resultado[i]=((max_valor[i]+10)-carrier)-valor2[i];
				carrier=1;			
			}
			else{
				resultado[i]=(max_valor[i]-carrier)-valor2[i];
				carrier=0;
			}
		}
		resultado[0]=valor1[0];	
		for(i=1;i<=valor1[0];i++){
			resultado[i]=valor1[i]+resultado[i]+carrier;
			if(resultado[i]>9){
				resultado[i]=resultado[i]-10;
				carrier=1;
			}
			else{
				carrier=0;
			}
		}
		if(carrier==1){
			resultado[i+1]=1;
			resultado[0]=valor1[0]+1;
		}
		else{
			resultado[0]=valor1[0];
		}			
	}
	else{
		for(i=1;i<=valor1[0];i++){
			if((valor1[i]-carrier)<valor2[i]){
				resultado[i]=((valor1[i]+10)-carrier)-valor2[i];
				carrier=1;			
			}
			else{
				resultado[i]=(valor1[i]-carrier)-valor2[i];
				carrier=0;
			}
		}
		resultado[0]=valor1[0];
	}
}

/* [] END OF FILE */