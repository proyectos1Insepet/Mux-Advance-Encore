/*
*********************************************************************************************************
*
*                                            MUX ADVANCE CODE
*
*                                             CYPRESS PSoC5LP
*                                                with the
*                                            CY8C5969AXI-LP035
*
* Filename      : codebar.c
* Version       : V1.00
* Programmer(s) : 
                  
*********************************************************************************************************
*/

#ifndef CODEBAR_H
#define CODEBAR_H
#include <device.h>
	
uint8 serial_codebar();

#endif

//[] END OF FILE
