/*
*********************************************************************************************************
*                                           GRP550M CODE
*
*                             (c) Copyright 2013; Sistemas Insepet LTDA
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                               GRP550M CODE
*
*                                             CYPRESS PSoC5LP
*                                                with the
*                                            CY8C5969AXI-LP035
*
* Filename      : EstructuraProtocolo.h
* Version       : V1.00
* Programmer(s) : 
                  
*********************************************************************************************************
*/

#ifndef ESTRUCTURAPROTOCOLO_H
#define ESTRUCTURAPROTOCOLO_H
#include <device.h>


void checksum(uint16 Tamano);
uint8 codigodebarras();
void envioventa(uint8 producto, uint8 posicion);
void RecuperarVentas(uint8 posicion, uint8 memoria);
void envioid(uint8 posicion, uint8 id);
void envioturno(uint8 posicion);
void programarPPUID(uint8 lado_LCD);
void programarPPUContado(uint8 lado_LCD);
void programarEquipo();
void DatosTurno();
void AbrirTurno();
void DatosEquipo(uint8 posicion);
void DatosUltimoTurno(uint8 posicion);
void DatosTotalesTurno(uint8 posicion);
void DatosTotalesActuales(uint8 posicion);
void DatosPPUActuales(uint8 posicion);
void resetvariables(uint8 lado_LCD);
void resetvariableslcd(uint8 lado_LCD);
void escribir_ram(uint16 page, uint8 *valor, uint8 pos);


#endif
/* [] END OF FILE */
