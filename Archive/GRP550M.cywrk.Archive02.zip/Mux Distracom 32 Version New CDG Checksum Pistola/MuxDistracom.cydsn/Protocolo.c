/*
*********************************************************************************************************
*                                           GRP550/700 CODE
*
*                             (c) Copyright 2013; Sistemas Insepet LTDA
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                             GRP550/700 CODE
*
*                                             CYPRESS PSoC5LP
*                                                with the
*                                            CY8C5969AXI-LP035
*
* Filename      : Protocolo.c
* Version       : V1.00
* Programmer(s) : 
                  
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/
#include <device.h>
#include "VariablesG.h"
#include "i2c.h"
#include "Print.h"
#include "EstructuraProtocolo.h"

/*
*********************************************************************************************************
*                                         ver_pos( void )
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
uint8 ver_pos (void){
uint32 x;
lado.a.dir=0xff;
lado.b.dir=0xff;
    for(x=0;x<=15;x++){
        Surtidor_PutChar(x);
        CyDelay(100);
        if((Surtidor_GetRxBufferSize()>=1)&&(lado.a.dir==0xff)){
           lado.a.dir=x;	
           Surtidor_ClearRxBuffer();
        }
        if((Surtidor_GetRxBufferSize()>=1)&&(x!=lado.a.dir)){
           lado.b.dir=x;
           Surtidor_ClearRxBuffer();
        }
    }
    if((lado.a.dir!=0xff)&&(lado.b.dir!=0xff)){
        return 2;
    }
    else{
        if((lado.a.dir!=0xff)||(lado.b.dir!=0xff)){
            return 1;
        }
        else{
            return 0;
        }
    }
}

/*
*********************************************************************************************************
*                                         ver_estado( void )
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

uint8 get_estado(uint8 dir){
    uint8 estado;
    Surtidor_PutChar(dir);
    CyDelay(55);
    if(Surtidor_GetRxBufferSize()>=1){
       estado=(Surtidor_ReadRxData()&0xF0)>>4;
       Surtidor_ClearRxBuffer();
       return estado;
    }
    else{
        return 0;
    }
}

/*
*********************************************************************************************************
*                                         void ver_error(uint8 val)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void ver_error(uint8 val){
    uint8 estado;
    Surtidor_PutChar(val);
    CyDelay(200);
    if(Surtidor_GetRxBufferSize()>=1){
       estado=(Surtidor_ReadRxData()&0xF0)>>4;
       Surtidor_ClearRxBuffer();
       if(estado==0){

       }
    }    
}

/*
*********************************************************************************************************
*                                         estado_ex(uint8 val)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
uint8 estado_ex(uint8 val){
    uint8 rx_extend[19],x,comand_exten[9]={0xFF,0xE9,0xFE,0xE0,0xE1,0xE0,0xFB,0xEE,0xF0};
    Surtidor_PutChar(0x20|val);
    producto=0xff;
    CyDelay(100);
    if(Surtidor_GetRxBufferSize()>=1){
        if(Surtidor_ReadRxData()==(0xD0|val)){
            Surtidor_ClearRxBuffer();
            for(x=0;x<=8;x++){
               Surtidor_PutChar(comand_exten[x]); 
            }
            CyDelay(200);
            if(Surtidor_GetRxBufferSize()>=19){
                for(x=0;x<=18;x++){
                   rx_extend[x]=Surtidor_ReadRxData(); 
                }
                Surtidor_ClearRxBuffer();
                if((rx_extend[0]==0xBA)&&(rx_extend[17]==0x8D)&&(rx_extend[18]==0x8A)&&(rx_extend[12]==0xB1)){
                    switch(rx_extend[14]){
                        case 0xB1:
                            return 1;
                            break;
                        case 0xB2:
                            return 2;
                            break;
                        case 0xB3:
                            return 3;
                            break;
                        default:
                            return 0;
                    }
                }
                else{
                    return 0;
                }
            }
            else{
                return 0;
            }
        }
        else{
            return 0;
        }
    }
    else{
        return 0;
    }
}

/*
*********************************************************************************************************
*                                         void detener(uint8 val)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void detener(uint8 val){
    Surtidor_PutChar(0x30|val);
    CyDelay(200);
}

/*
*********************************************************************************************************
*                                         void venta(uint8 val)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
uint8 venta(uint8 val, uint8 producto){
    uint8 rx_venta[39],pos,DatosVenta[2];
    uint32 j,x=0,y;
    Surtidor_PutChar(0x40|val);
    CyDelay(250);
    if(Surtidor_GetRxBufferSize()<=39){
        while(Surtidor_GetRxBufferSize()>0){
            rx_venta[x]=Surtidor_ReadRxData();
            x++;
        }
        Surtidor_ClearRxBuffer();
        if(val==0){
            pos=0x10;
            rventa.posicion=pos;
        }
        else{
            pos=val;
            rventa.posicion=pos;
        }
        if((rx_venta[0]==0xFF)&&(rx_venta[2]==0xF8)&&((rx_venta[4]&0x0F)==(pos-1))){
            x=0;
            while((rx_venta[x]!=0xF6)||(x>=39)){
                x++;
            }
            x++;
            rventa.producto=(rx_venta[x]&0x0F)+1;
            while((rx_venta[x]!=0xF7)||(x>=39)){
                x++;
            }
            x++;
            y=1;
            while((rx_venta[x]!=0xF9)||(x>=39)){    
                rventa.ppu[y]=(rx_venta[x]&0x0F);
                x++;
                y++;
            }
			rventa.ppu[0]=y-1;
            x++;
            y=1;
            while((rx_venta[x]!=0xFA)||(x>=39)){
                rventa.volumen[y]=(rx_venta[x]&0x0F);
                x++;
                y++;
            }
			rventa.volumen[0]=y-1;
            x++;
            y=1;
            while((rx_venta[x]!=0xFB)||(x>=39)){
                rventa.dinero[y]=(rx_venta[x]&0x0F);
                x++;
                y++;    
            }
			rventa.dinero[0]=y-1;
            x+=2;
			
			if(val==lado.a.dir){
				for(j=0;j<=rventa.dinero[0];j++){
					Buffer_LCD1.VentaDinero[j]=rventa.dinero[j];
				}
				for(j=0;j<=rventa.volumen[0];j++){
					Buffer_LCD1.VentaVolumen[j]=rventa.volumen[j];
				}
				for(j=0;j<=rventa.ppu[0];j++){
					Buffer_LCD1.VentaPPU[j]=rventa.ppu[j];
				}	
			}else{
				for(j=0;j<=rventa.dinero[0];j++){
					Buffer_LCD2.VentaDinero[j]=rventa.dinero[j];
				}
				for(j=0;j<=rventa.volumen[0];j++){
					Buffer_LCD2.VentaVolumen[j]=rventa.volumen[j];
				}
				for(j=0;j<=rventa.ppu[0];j++){
					Buffer_LCD2.VentaPPU[j]=rventa.ppu[j];
				}
			}
            if((rx_venta[x]==0xF0)&&(x<=38)){
				if(val==lado.a.dir){
                    if(leer_fecha()==1){						//Lectura de Fecha Final
						Buffer_LCD1.FechaFinalVenta[0]=14;
						Buffer_LCD1.FechaFinalVenta[1]=0x32;
						Buffer_LCD1.FechaFinalVenta[2]=0x30;
						Buffer_LCD1.FechaFinalVenta[3]=(((rventa.fecha[2]&0xF0)>>4)+48);
						Buffer_LCD1.FechaFinalVenta[4]=((rventa.fecha[2]&0x0F)+48);
						Buffer_LCD1.FechaFinalVenta[5]=(((rventa.fecha[1]&0x10)>>4)+48);
						Buffer_LCD1.FechaFinalVenta[6]=((rventa.fecha[1]&0x0F)+48);
						Buffer_LCD1.FechaFinalVenta[7]=(((rventa.fecha[0]&0x30)>>4)+48);
						Buffer_LCD1.FechaFinalVenta[8]=((rventa.fecha[0]&0x0F)+48);
					}
					if(leer_hora()==1){							//Lectura de Hora Final	
						Buffer_LCD1.FechaFinalVenta[9]=(((rventa.hora[2]&0xF0)>>4)+48);	
						Buffer_LCD1.FechaFinalVenta[10]=((rventa.hora[2]&0x0F)+48);
						Buffer_LCD1.FechaFinalVenta[11]=(((rventa.hora[1]&0xF0)>>4)+48);
						Buffer_LCD1.FechaFinalVenta[12]=((rventa.hora[1]&0x0F)+48);
						Buffer_LCD1.FechaFinalVenta[13]=(((rventa.hora[0]&0xF0)>>4)+48);
						Buffer_LCD1.FechaFinalVenta[14]=((rventa.hora[0]&0x0F)+48);
					}
                    if(Buffer_LCD1.VentasPendientesR<3){
    					DatosVenta[0]=1;
    					DatosVenta[1]=producto;
                        escribir_ram(0+(186*(Buffer_LCD1.VentasPendientesR)),DatosVenta,1);				//Manguera Surtidor
                        escribir_ram(2+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.VentaDinero,1);	//Dinero
                        escribir_ram(11+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.VentaVolumen,1);//Volumen
                        escribir_ram(20+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.VentaPPU,1);	//PPU
                        escribir_ram(27+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.placa,1);  	//Placa
                        escribir_ram(36+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.cedula,1);		//Cedula
                        escribir_ram(47+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.Nit,1);		//Nit
                        escribir_ram(58+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.km,1);			//Kilometraje
    					escribir_ram(69+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.FechaInicialVenta,1);//Fecha Surtiendo
    					escribir_ram(84+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.FechaFinalVenta,1);//Fecha Fin venta
    					DatosVenta[0]=1;
    					DatosVenta[1]=Buffer_LCD1.PresetProgramado;
                        escribir_ram(99+(186*(Buffer_LCD1.VentasPendientesR)),DatosVenta,1);				//Tipo de Preset Programado
    					escribir_ram(101+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.ValorPreset,1);//Cantidad Programada
    					DatosVenta[0]=1;
    					DatosVenta[1]=Buffer_LCD1.TipodeVenta;
                        escribir_ram(109+(186*(Buffer_LCD1.VentasPendientesR)),DatosVenta,1);			//Tipo de Venta
    					escribir_ram(111+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.IdentCliente,1);//Identificacion de cliente
    					escribir_ram(129+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.TotalDineroAnterior,1);//Total Manguera Dinero antes
    					escribir_ram(142+(186*(Buffer_LCD1.VentasPendientesR)),Buffer_LCD1.TotalVolumenAnterior,1);//Total Manguera Volumen antes
    					escribir_ram(156+(186*(Buffer_LCD1.VentasPendientesR)),IdentVendedor,1);         //Identificacion Vendedor
                        Buffer_LCD1.VentasPendientesR++;
                    }else{
                        DatosVenta[0]=1;
    					DatosVenta[1]=val;
    					write_eeprom(512+(512*Buffer_LCD1.VentasPendientesE),DatosVenta);				//Posicion Surtidor
    					DatosVenta[0]=1;
    					DatosVenta[1]=producto;
    					write_eeprom(514+(512*Buffer_LCD1.VentasPendientesE),DatosVenta);				//Manguera Surtidor
    					write_eeprom(516+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.VentaDinero);	//Dinero
    					write_eeprom(525+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.VentaVolumen);	//Volumen
    					write_eeprom(534+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.VentaPPU);		//PPU
    					write_eeprom(576+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.placa);		//Placa
    					write_eeprom(585+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.cedula);		//Cedula
    					write_eeprom(596+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.Nit);			//Nit
    					write_eeprom(640+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.km);			//Kilometraje
    					write_eeprom(704+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.FechaInicialVenta);//Fecha Surtiendo
    					write_eeprom(719+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.FechaFinalVenta);		//Fecha Fin venta
    					DatosVenta[0]=1;
    					DatosVenta[1]=Buffer_LCD1.PresetProgramado;
    					write_eeprom(768+(512*Buffer_LCD1.VentasPendientesE),DatosVenta);						//Tipo de Preset Programado
    					write_eeprom(770+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.ValorPreset);			//Cantidad Programada
    					DatosVenta[0]=1;
    					DatosVenta[1]=Buffer_LCD1.TipodeVenta;
    					write_eeprom(778+(512*Buffer_LCD1.VentasPendientesE),DatosVenta);						//Tipo de Venta
    					write_eeprom(780+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.IdentCliente);			//Identificacion de cliente
    					write_eeprom(832+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.TotalDineroAnterior);	//Total Manguera Dinero antes
    					write_eeprom(896+(512*Buffer_LCD1.VentasPendientesE),Buffer_LCD1.TotalVolumenAnterior);	//Total Manguera Volumen antes
    					write_eeprom(960+(512*Buffer_LCD1.VentasPendientesE),IdentVendedor);						//Identificacion Vendedor
    					Buffer_LCD1.VentasPendientesE++;
                        if(Buffer_LCD1.VentasPendientesE > 50){
            				Buffer_LCD1.VentasPendientesE=50;
            			}
    					DatosVenta[0]=1;
    					DatosVenta[1]=Buffer_LCD1.VentasPendientesE;
    					write_eeprom(214,DatosVenta);
                    }
				}else{
                    if(leer_fecha()==1){						//Lectura de Fecha Final
						Buffer_LCD2.FechaFinalVenta[0]=14;
						Buffer_LCD2.FechaFinalVenta[1]=0x32;
						Buffer_LCD2.FechaFinalVenta[2]=0x30;
						Buffer_LCD2.FechaFinalVenta[3]=(((rventa.fecha[2]&0xF0)>>4)+48);
						Buffer_LCD2.FechaFinalVenta[4]=((rventa.fecha[2]&0x0F)+48);
						Buffer_LCD2.FechaFinalVenta[5]=(((rventa.fecha[1]&0x10)>>4)+48);
						Buffer_LCD2.FechaFinalVenta[6]=((rventa.fecha[1]&0x0F)+48);
						Buffer_LCD2.FechaFinalVenta[7]=(((rventa.fecha[0]&0x30)>>4)+48);
						Buffer_LCD2.FechaFinalVenta[8]=((rventa.fecha[0]&0x0F)+48);
					}
					if(leer_hora()==1){							//Lectura de Hora Final	
						Buffer_LCD2.FechaFinalVenta[9]=(((rventa.hora[2]&0xF0)>>4)+48);	
						Buffer_LCD2.FechaFinalVenta[10]=((rventa.hora[2]&0x0F)+48);
						Buffer_LCD2.FechaFinalVenta[11]=(((rventa.hora[1]&0xF0)>>4)+48);
						Buffer_LCD2.FechaFinalVenta[12]=((rventa.hora[1]&0x0F)+48);
						Buffer_LCD2.FechaFinalVenta[13]=(((rventa.hora[0]&0xF0)>>4)+48);
						Buffer_LCD2.FechaFinalVenta[14]=((rventa.hora[0]&0x0F)+48);
					}
                    if(Buffer_LCD2.VentasPendientesR<3){
    					DatosVenta[0]=1;
    					DatosVenta[1]=producto;
                        escribir_ram(0+(186*(Buffer_LCD2.VentasPendientesR)),DatosVenta,2);				//Manguera Surtidor
                        escribir_ram(2+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.VentaDinero,2);	//Dinero
                        escribir_ram(11+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.VentaVolumen,2);//Volumen
                        escribir_ram(20+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.VentaPPU,2);	//PPU
                        escribir_ram(27+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.placa,2);  	//Placa
                        escribir_ram(36+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.cedula,2);		//Cedula
                        escribir_ram(47+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.Nit,2);		//Nit
                        escribir_ram(58+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.km,2);			//Kilometraje
    					escribir_ram(69+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.FechaInicialVenta,2);//Fecha Surtiendo
    					escribir_ram(84+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.FechaFinalVenta,2);//Fecha Fin venta
    					DatosVenta[0]=1;
    					DatosVenta[1]=Buffer_LCD2.PresetProgramado;
                        escribir_ram(99+(186*(Buffer_LCD2.VentasPendientesR)),DatosVenta,2);				//Tipo de Preset Programado
    					escribir_ram(101+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.ValorPreset,2);//Cantidad Programada
    					DatosVenta[0]=1;
    					DatosVenta[1]=Buffer_LCD2.TipodeVenta;
                        escribir_ram(109+(186*(Buffer_LCD2.VentasPendientesR)),DatosVenta,2);			//Tipo de Venta
    					escribir_ram(111+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.IdentCliente,2);//Identificacion de cliente
    					escribir_ram(129+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.TotalDineroAnterior,2);//Total Manguera Dinero antes
    					escribir_ram(142+(186*(Buffer_LCD2.VentasPendientesR)),Buffer_LCD2.TotalVolumenAnterior,2);//Total Manguera Volumen antes
    					escribir_ram(156+(186*(Buffer_LCD2.VentasPendientesR)),IdentVendedor,2);         //Identificacion Vendedor
                        Buffer_LCD2.VentasPendientesR++;
                    }else{
                        DatosVenta[0]=1;
    					DatosVenta[1]=val;
    					write_eeprom(543+(512*Buffer_LCD2.VentasPendientesE),DatosVenta);				//Posicion Surtidor
    					DatosVenta[0]=1;
    					DatosVenta[1]=producto;
    					write_eeprom(545+(512*Buffer_LCD2.VentasPendientesE),DatosVenta);				//Manguera Surtidor
    					write_eeprom(547+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.VentaDinero);	//Dinero
    					write_eeprom(556+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.VentaVolumen);	//Volumen
    					write_eeprom(565+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.VentaPPU);		//PPU
    					write_eeprom(607+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.placa);		//Placa
    					write_eeprom(616+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.cedula);		//Cedula
    					write_eeprom(627+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.Nit);			//Nit
    					write_eeprom(671+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.km);			//Kilometraje
    					write_eeprom(735+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.FechaInicialVenta);//Fecha Surtiendo
    					write_eeprom(750+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.FechaFinalVenta);		//Fecha Fin venta
    					DatosVenta[0]=1;
    					DatosVenta[1]=Buffer_LCD2.PresetProgramado;
    					write_eeprom(799+(512*Buffer_LCD2.VentasPendientesE),DatosVenta);						//Tipo de Preset Programado
    					write_eeprom(801+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.ValorPreset);			//Cantidad Programada
    					DatosVenta[0]=1;
    					DatosVenta[1]=Buffer_LCD2.TipodeVenta;
    					write_eeprom(809+(512*Buffer_LCD2.VentasPendientesE),DatosVenta);						//Tipo de Venta
    					write_eeprom(811+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.IdentCliente);			//Identificacion de cliente
    					write_eeprom(863+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.TotalDineroAnterior);	//Total Manguera Dinero antes
    					write_eeprom(927+(512*Buffer_LCD2.VentasPendientesE),Buffer_LCD2.TotalVolumenAnterior);	//Total Manguera Volumen antes
    					write_eeprom(991+(512*Buffer_LCD2.VentasPendientesE),IdentVendedor);						//Identificacion Vendedor
    					Buffer_LCD2.VentasPendientesE++;
                        if(Buffer_LCD2.VentasPendientesE > 50){
            				Buffer_LCD2.VentasPendientesE=50;
            			}
    					DatosVenta[0]=1;
    					DatosVenta[1]=Buffer_LCD2.VentasPendientesE;
    					write_eeprom(216,DatosVenta);
                    }
				}
				PC_ClearRxBuffer();
                return 1;
            }
            else{
                return 0;
            }
        }
        else{
            return 0;
        }
    }
    else{
        return 0;
    }
}

/*
*********************************************************************************************************
*                                         uint8 get_totales(uint8 dir)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
uint8 get_totales(uint8 dir){
    uint32 j,x;
    Surtidor_PutChar(0x50|dir);
    CyDelay(700);
	if(dir==lado.a.dir){
		switch(Surtidor_GetRxBufferSize()){
			case 34://5 digitos una manguera
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[33]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){			
					Buffer_LCD1.TotalVolumen1[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[x+4]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[x+4]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero1[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD1.TotalDinero1[j]=(Surtidor_rxBuffer[x+13]&0x0F)+0x30;
						j--;
					}
					Surtidor_ClearRxBuffer();
					return 1;
				}
				else{
					return 0;
				}
			break;
			
			case 64://5 digitos dos mangueras
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[63]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){
					Buffer_LCD1.TotalVolumen1[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero1[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD1.TotalDinero1[j]=(Surtidor_rxBuffer[13+x]&0x0F)+0x30;
						j--;
					}	
					Buffer_LCD1.TotalVolumen2[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen2[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen2[j]=(Surtidor_rxBuffer[34+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen2[j]=(Surtidor_rxBuffer[34+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero2[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD1.TotalDinero2[j]=(Surtidor_rxBuffer[43+x]&0x0F)+0x30;
						j--;
					}
					Surtidor_ClearRxBuffer();
					return 2;
				}			
				else{
					return 0;
				}
			break;
				
			case 94://5 digitos tres mangueras
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[93]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){
					Buffer_LCD1.TotalVolumen1[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero1[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD1.TotalDinero1[j]=(Surtidor_rxBuffer[13+x]&0x0F)+0x30;
						j--;
					}
					Buffer_LCD1.TotalVolumen2[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen2[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen2[j]=(Surtidor_rxBuffer[34+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen2[j]=(Surtidor_rxBuffer[34+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero2[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD1.TotalDinero2[j]=(Surtidor_rxBuffer[43+x]&0x0F)+0x30;
						j--;
					}
					Buffer_LCD1.TotalVolumen3[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen3[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen3[j]=(Surtidor_rxBuffer[64+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen3[j]=(Surtidor_rxBuffer[64+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero3[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD1.TotalDinero3[j]=(Surtidor_rxBuffer[73+x]&0x0F)+0x30;
						j--;
					}
					Surtidor_ClearRxBuffer();
					return 3;					
				}			
				else{
					return 0;
				}			
			break;
				
			case 46://7 digitos una manguera
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[45]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){
					Buffer_LCD1.TotalVolumen1[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[x+4]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[x+4]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero1[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD1.TotalDinero1[j]=(Surtidor_rxBuffer[x+17]&0x0F)+0x30;
						j--;
					}				
					Surtidor_ClearRxBuffer();
					return 1;
				}
				else{
					return 0;
				}			
			break;
				
			case 88://7 digitos dos mangueras
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[87]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){
					Buffer_LCD1.TotalVolumen1[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero1[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD1.TotalDinero1[j]=(Surtidor_rxBuffer[17+x]&0x0F)+0x30;
						j--;
					}
					Buffer_LCD1.TotalVolumen2[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen2[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen2[j]=(Surtidor_rxBuffer[46+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen2[j]=(Surtidor_rxBuffer[46+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero2[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD1.TotalDinero2[j]=(Surtidor_rxBuffer[59]&0x0F)+0x30;
						j--;
					}
					Surtidor_ClearRxBuffer();
					return 2;					
				}			
				else{
					return 0;
				}			
			break;
		
			case 130://7 digitos tres mangueras
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[129]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){
					Buffer_LCD1.TotalVolumen1[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero1[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD1.TotalDinero1[j]=(Surtidor_rxBuffer[17+x]&0x0F)+0x30;
						j--;
					}
					Buffer_LCD1.TotalVolumen2[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen2[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen2[j]=(Surtidor_rxBuffer[46+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen2[j]=(Surtidor_rxBuffer[46+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero2[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD1.TotalDinero2[j]=(Surtidor_rxBuffer[59+x]&0x0F)+0x30;
						j--;
					}
					Buffer_LCD1.TotalVolumen3[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD1.TotalVolumen3[j]=',';
							j--;
							Buffer_LCD1.TotalVolumen3[j]=(Surtidor_rxBuffer[88+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD1.TotalVolumen3[j]=(Surtidor_rxBuffer[88+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD1.TotalDinero3[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD1.TotalDinero3[j]=(Surtidor_rxBuffer[101+x]&0x0F)+0x30;
						j--;
					}
					Surtidor_ClearRxBuffer();
					return 3;
				}
				else{
					return 0;
				}
			break;
				
			default:
				return 0;	
			break;		
		}
	}else if(dir==lado.b.dir){
		switch(Surtidor_GetRxBufferSize()){
			case 34://5 digitos una manguera
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[33]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){			
					Buffer_LCD2.TotalVolumen1[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[x+4]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[x+4]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero1[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD2.TotalDinero1[j]=(Surtidor_rxBuffer[x+13]&0x0F)+0x30;
						j--;
					}
					Surtidor_ClearRxBuffer();
					return 1;
				}
				else{
					return 0;
				}
			break;
			
			case 64://5 digitos dos mangueras
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[63]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){
					Buffer_LCD2.TotalVolumen1[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero1[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD2.TotalDinero1[j]=(Surtidor_rxBuffer[13+x]&0x0F)+0x30;
						j--;
					}	
					Buffer_LCD2.TotalVolumen2[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen2[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen2[j]=(Surtidor_rxBuffer[34+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen2[j]=(Surtidor_rxBuffer[34+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero2[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD2.TotalDinero2[j]=(Surtidor_rxBuffer[43+x]&0x0F)+0x30;
						j--;
					}
					Surtidor_ClearRxBuffer();
					return 2;
				}			
				else{
					return 0;
				}
			break;
				
			case 94://5 digitos tres mangueras
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[93]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){
					Buffer_LCD2.TotalVolumen1[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero1[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD2.TotalDinero1[j]=(Surtidor_rxBuffer[13+x]&0x0F)+0x30;
						j--;
					}
					Buffer_LCD2.TotalVolumen2[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen2[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen2[j]=(Surtidor_rxBuffer[34+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen2[j]=(Surtidor_rxBuffer[34+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero2[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD2.TotalDinero2[j]=(Surtidor_rxBuffer[43+x]&0x0F)+0x30;
						j--;
					}
					Buffer_LCD2.TotalVolumen3[0]=9;
					j=9;
					for(x=0;x<=7;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen3[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen3[j]=(Surtidor_rxBuffer[64+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen3[j]=(Surtidor_rxBuffer[64+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero3[0]=8;
					j=8;
					for(x=0;x<=7;x++){
						Buffer_LCD2.TotalDinero3[j]=(Surtidor_rxBuffer[73+x]&0x0F)+0x30;
						j--;
					}
					Surtidor_ClearRxBuffer();
					return 3;					
				}			
				else{
					return 0;
				}			
			break;
				
			case 46://7 digitos una manguera
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[45]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){
					Buffer_LCD2.TotalVolumen1[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[x+4]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[x+4]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero1[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD2.TotalDinero1[j]=(Surtidor_rxBuffer[x+17]&0x0F)+0x30;
						j--;
					}				
					Surtidor_ClearRxBuffer();
					return 1;
				}
				else{
					return 0;
				}			
			break;
				
			case 88://7 digitos dos mangueras
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[87]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){
					Buffer_LCD2.TotalVolumen1[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero1[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD2.TotalDinero1[j]=(Surtidor_rxBuffer[17+x]&0x0F)+0x30;
						j--;
					}
					Buffer_LCD2.TotalVolumen2[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen2[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen2[j]=(Surtidor_rxBuffer[46+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen2[j]=(Surtidor_rxBuffer[46+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero2[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD2.TotalDinero2[j]=(Surtidor_rxBuffer[59]&0x0F)+0x30;
						j--;
					}
					Surtidor_ClearRxBuffer();
					return 2;					
				}			
				else{
					return 0;
				}			
			break;
		
			case 130://7 digitos tres mangueras
				if((Surtidor_rxBuffer[0]==0xFF)&&(Surtidor_rxBuffer[1]==0xF6)&&(Surtidor_rxBuffer[129]==0xF0)&&(Surtidor_rxBuffer[3]==0xF9)){
					Buffer_LCD2.TotalVolumen1[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen1[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen1[j]=(Surtidor_rxBuffer[4+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero1[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD2.TotalDinero1[j]=(Surtidor_rxBuffer[17+x]&0x0F)+0x30;
						j--;
					}
					Buffer_LCD2.TotalVolumen2[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen2[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen2[j]=(Surtidor_rxBuffer[46+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen2[j]=(Surtidor_rxBuffer[46+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero2[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD2.TotalDinero2[j]=(Surtidor_rxBuffer[59+x]&0x0F)+0x30;
						j--;
					}
					Buffer_LCD2.TotalVolumen3[0]=13;
					j=13;
					for(x=0;x<=11;x++){
						if(x==2){
							Buffer_LCD2.TotalVolumen3[j]=',';
							j--;
							Buffer_LCD2.TotalVolumen3[j]=(Surtidor_rxBuffer[88+x]&0x0F)+0x30;
							j--;
						}else{
							Buffer_LCD2.TotalVolumen3[j]=(Surtidor_rxBuffer[88+x]&0x0F)+0x30;
							j--;
						}
					}
					Buffer_LCD2.TotalDinero3[0]=12;
					j=12;
					for(x=0;x<=11;x++){
						Buffer_LCD2.TotalDinero3[j]=(Surtidor_rxBuffer[101+x]&0x0F)+0x30;
						j--;
					}
					Surtidor_ClearRxBuffer();
					return 3;
				}
				else{
					return 0;
				}
			break;
				
			default:
				return 0;	
			break;	
		}
	}else{
		return 0;
	}
}

/*
*********************************************************************************************************
*                                         uint8 programar(uint8 dir)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
uint8 programar(uint8 dir, uint8 grado, uint8 *valor, uint8 preset){
	uint8 buffer[18]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},size,temp,decimal=0;
    uint32 i,j;
	temp=4;
	if(((lado.c.versdig==5)||(lado.c.versdig==6))&&(preset==1)){
		temp=3;
	}
	if((lado.c.versdig==5)&&(preset==2)){
		temp=5;
	}
	if((lado.c.versdig==7)&&(preset==1)){
		temp=0;
	}
	if((lado.c.versdig==7)&&(preset==2)){
		temp=2;
	}	
	decimal=0;
	for(i=1;i<=valor[0];i++){
		if(decimal>=1){
			decimal++;
			valor[i]=valor[i+1];
		}				
		if(valor[i]==','){
			decimal++;
			valor[i]=valor[i+1];
		}
	}
	if(decimal>=1){
		decimal=decimal-1;
		valor[0]=valor[0]-1;
	}	
	if(decimal>=4){
		return 0;
	}	
	if(lado.c.versdig!=7){		
		buffer[0]=0xFF;
		buffer[1]=(0xE0|temp);
		buffer[2]=(0xF0|preset);
		buffer[3]=0xF4;
		buffer[4]=0xF8;	
		for(i=5;i<((5+decimalD)-decimal);i++){
			buffer[i]=0xE0;
		}
		for(j=i;j<(i+valor[0]);j++){
			buffer[j]=(0xE0|(valor[valor[0]-(j-i)]&0x0F));	
		}
		for(i=j;i<=10;i++){
			buffer[i]=0xE0;
		}
		buffer[11]=0xFB;
		buffer[12]=0;
		for(i=0;i<=11;i++){
			buffer[12]+=(buffer[i]&0x0F);	
		}
		buffer[12]=(((~buffer[12])+1)&0x0F)|0xE0;
		buffer[13]=0xF0;
		size=13;
		if(lado.c.versdig==5){
			buffer[10]=0xFB;
			buffer[11]=0;
			for(i=0;i<=10;i++){
				buffer[11]+=(buffer[i]&0x0F);	
			}
			buffer[11]=(((~buffer[11])+1)&0x0F)|0xE0;
			buffer[12]=0xF0;
			size=12;		
		}
		if(preset==1){
			if(decimal==3){
				valor[0]=valor[0]-1;
				decimal=decimal-1;
			}
			buffer[4]=0xF6;
			buffer[5]=(0xE0|(grado-1));
			buffer[6]=0xF8;
			for(i=7;i<((7+(decimalV-1))-decimal);i++){
				buffer[i]=0xE0;
			}
			for(j=i;j<(i+valor[0]);j++){
				buffer[j]=(0xE0|(valor[valor[0]-(j-i)]&0x0F));	
			}
			for(i=j;i<=11;i++){
				buffer[i]=0xE0;
			}			
			buffer[12]=0xFB;
			buffer[13]=0;
			for(i=0;i<=12;i++){
				buffer[13]+=(buffer[i]&0x0F);	
			}
			buffer[13]=(((~buffer[13])+1)&0x0F)|0xE0;			
			buffer[14]=0xF0;
			size=14;
		}	
	}	
	if(lado.c.versdig==7){
		buffer[0]=0xFF;
		buffer[1]=(0xE0|temp);
		buffer[2]=(0xF0|preset);
		buffer[3]=0xF4;
		buffer[4]=0xF8;	
		for(i=5;i<((5+decimalD)-decimal);i++){
			buffer[i]=0xE0;
		}
		for(j=i;j<(i+valor[0]);j++){
			buffer[j]=(0xE0|(valor[valor[0]-(j-i)]&0x0F));	
		}
		for(i=j;i<=12;i++){
			buffer[i]=0xE0;
		}
		buffer[13]=0xFB;
		buffer[14]=0;
		for(i=0;i<=13;i++){
			buffer[14]+=(buffer[i]&0x0F);	
		}
		buffer[14]=(((~buffer[14])+1)&0x0F)|0xE0;
		buffer[15]=0xF0;
		size=15;
		if(preset==1){
			buffer[4]=0xF6;
			buffer[5]=(0xE0|(grado-1));
			buffer[6]=0xF8;
			for(i=7;i<((7+decimalV)-decimal);i++){
				buffer[i]=0xE0;
			}
			for(j=i;j<(i+valor[0]);j++){
				buffer[j]=(0xE0|(valor[valor[0]-(j-i)]&0x0F));	
			}
			for(i=j;i<=14;i++){
				buffer[i]=0xE0;
			}			
			buffer[15]=0xFB;
			buffer[16]=0;
			for(i=0;i<=15;i++){
				buffer[16]+=(buffer[i]&0x0F);	
			}
			buffer[16]=(((~buffer[16])+1)&0x0F)|0xE0;			
			buffer[17]=0xF0;
			size=17;
		}		
	}	
	Surtidor_PutChar(0x20|dir);	
    CyDelay(50);
    if(Surtidor_GetRxBufferSize()>=1){
		if(Surtidor_ReadRxData()==(0xD0|dir)){
            Surtidor_ClearRxBuffer();
            for(i=0;i<=size;i++){
               	Surtidor_PutChar(buffer[i]);
            }
			CyDelay(50);
			if(get_estado(dir)==0){
				return 0;
			}
			else{
				return 1;
			}
		}
		else{
			return 0;
		}
	}
	else{
		return 0;	
	}
}

/*
*********************************************************************************************************
*                                         uint8 cambiar_precio(uint8 dir)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
uint8 cambiar_precio(uint8 dir){
	uint8 buffer[15]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},size;
    uint32 x,y;
	if(lado.c.versdig!=7){
		buffer[0]=0xFF;
		buffer[1]=0xE5;
		buffer[2]=0xF4;
		buffer[3]=0xF6;
		buffer[4]=(0xE0|((rventa.producto&0x0f)-1));
		buffer[5]=0xF7;	
		if(ppux10==0){
			for(x=6;x<(6+Digitosppu);x++){
				buffer[x]=(0xE0|(ValorPPU[Digitosppu-(x-6)]&0x0F));
			}
		}
		else{
			Digitosppu=Digitosppu-1;
			for(x=6;x<(6+Digitosppu);x++){
				buffer[x]=(0xE0|(ValorPPU[Digitosppu-(x-6)]&0x0F));
			}	
		}
		for(y=x;y<=9;y++){
			buffer[y]=0xE0;	
		}
		buffer[10]=0xFB;
		for(x=0;x<=10;x++){
			buffer[11]+=(buffer[x]&0x0F);	
		}
		buffer[11]=(((~buffer[11])+1)&0x0F)|0xE0;
		buffer[12]=0xF0;
		size=12;
	}
	if(lado.c.versdig==7){
		buffer[0]=0xFF;
		buffer[1]=0xE3;
		buffer[2]=0xF4;
		buffer[3]=0xF6;
		buffer[4]=(0xE0|((rventa.producto&0x0f)-1));
		buffer[5]=0xF7;		
		for(x=6;x<(6+Digitosppu);x++){
			buffer[x]=(0xE0|(ValorPPU[Digitosppu-(x-6)]&0x0F));
		}	
		for(y=x;y<=11;y++){
			buffer[y]=0xE0;	
		}		
		buffer[12]=0xFB;
		for(x=0;x<=12;x++){
			buffer[13]+=(buffer[x]&0x0F);	
		}
		buffer[13]=(((~buffer[13])+1)&0x0F)|0xE0;
		buffer[14]=0xF0;
		size=14;
	}	
	Surtidor_PutChar(0x20|dir);	
    CyDelay(100);
    if(Surtidor_GetRxBufferSize()>=1){
		if(Surtidor_ReadRxData()==(0xD0|dir)){
            Surtidor_ClearRxBuffer();
            for(x=0;x<=size;x++){
               	Surtidor_PutChar(buffer[x]); 	
            }
			CyDelay(50);
			if(get_estado(dir)==0){
				return 0;
			}
			else{
				return 1;
			}
		}
		else{
			return 0;
		}
	}
	else{
		return 0;	
	}
}

/* [] END OF FILE */
